﻿namespace Sample.CrossCutting.Core;

public static class Errors
{
    public static class General
    {
        public static Error Null() => new("400", $"Object is null.");

        public static Error NullTo(string to) => new Error("String.NullTo", $"Email to {to} must have a value");

        public static Error NullSubject(string subject) =>
            new Error("String.NullSubject", $"Email subject {subject} must have a value");
    }

    public static class Customer
    {
        public static Error CustomerNotFound(Guid id) =>
            new Error("Customer.CustomerId", $"Customer with customerId:{id} not found .");

        public static Error NoSearchPreferenceFound(Guid customerId) =>
            new Error("Customer.UserPreference", $"No user preference found with customerId: {customerId}.");
    }

    public static class Email
    {
        public static Error EmailSendingFailed(string errorMessage) =>
            new Error("Email.SendingFailed", $"Email sending failed. Error: {errorMessage}");
    }

    public static class Order
    {
        public static Error OrderNotFound(Guid orderId) =>
            new Error("Order.OrderNotFound", $"Order not found for OrderId: {orderId}");

        public static Error OrderProductNotFound(Guid storeProductId) =>
            new Error("Order.OrderNotFound", $"Order not found for OrderId: {storeProductId}");
    }

    public static class Store
    {
        public static Error StoreNotFoundByTrackingId(Guid trackingId) =>
            new Error("Store.StoreNotFoundByTrackingId", $"Store not found for TrackingId: {trackingId}");
    }

    public static class Affiliate
    {
        public static Error NotFoundByCode(string code) =>
            new Error("Affiliate.NotFoundByCode", $"Affiliate not found for code: {code}");
    }
}
