﻿namespace Sample.CrossCutting.Infrastructure.Exceptions;

[Serializable]
public class LongTransientException : Exception
{
    public LongTransientException() { }

    public LongTransientException(string message)
        : base(message) { }
}
