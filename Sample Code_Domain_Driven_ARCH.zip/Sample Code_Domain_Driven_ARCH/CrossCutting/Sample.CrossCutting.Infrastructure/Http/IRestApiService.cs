﻿using RestSharp;

namespace Sample.CrossCutting.Infrastructure.Http;

public interface IRestApiService
{
    T MakeJsonRequest<T>(
        Method verb,
        string basePath,
        string route,
        object body = null,
        Dictionary<string, object> queryStringParams = null,
        StatusCodeFlags statusCodesToReturn = StatusCodeFlags.Ok | StatusCodeFlags.NoContent,
        Dictionary<string, string> headers = null
    )
        where T : new();
    void MakeRestApiCommand(Method verb, string basePath, string route, string json);
    T MakeRestApiRequest<T>(
        Method verb,
        string basePath,
        string route,
        Dictionary<string, object> args,
        Dictionary<string, string> headers = null,
        object body = null,
        StatusCodeFlags statusCodesToReturn = StatusCodeFlags.Ok | StatusCodeFlags.NoContent
    )
        where T : new();
    T MakeUrlEncodedCall<T>(
        Method verb,
        string basePath,
        string route,
        Dictionary<string, object> queryStringParams = null,
        Dictionary<string, object> formParams = null,
        StatusCodeFlags statusCodesToReturn = StatusCodeFlags.Ok | StatusCodeFlags.NoContent
    )
        where T : new();
}
