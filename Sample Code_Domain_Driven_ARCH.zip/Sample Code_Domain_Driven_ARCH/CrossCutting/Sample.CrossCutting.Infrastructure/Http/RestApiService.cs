﻿using System.Net;
using System.Text.Json;
using Microsoft.Extensions.Logging;
using RestSharp;

namespace Sample.CrossCutting.Infrastructure.Http;

public class RestApiService : IRestApiService
{
    private readonly ILogger<RestApiService> _logger;

    public RestApiService(ILogger<RestApiService> logger)
    {
        _logger = logger;
    }

    public T MakeRestApiRequest<T>(
        Method verb,
        string basePath,
        string route,
        Dictionary<string, object> args,
        Dictionary<string, string> headers = null,
        object body = null,
        StatusCodeFlags statusCodesToReturn = StatusCodeFlags.Ok | StatusCodeFlags.NoContent
    )
        where T : new()
    {
        var client = new RestClient(basePath);
        var request = new RestRequest(route, verb);

        if (headers != null)
        {
            foreach (var header in headers)
            {
                request.AddHeader(header.Key, header.Value);
            }
        }

        if (body == null && args != null)
        {
            foreach (var arg in args)
            {
                request.AddParameter(arg.Key, arg.Value, ParameterType.QueryString);
            }
        }
        else if (body != null)
        {
            request.AddJsonBody(body);
        }

        try
        {
            var response = client.Execute<T>(request);

            if (!statusCodesToReturn.Contains(response.StatusCode))
            {
                throw new ApplicationException(
                    "Error completing request: " + response.StatusCode + " " + response.StatusDescription
                );
            }

            return response.Data;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex.Message, ex);
            throw;
        }
    }

    public T MakeJsonRequest<T>(
        Method verb,
        string basePath,
        string route,
        object body = null,
        Dictionary<string, object> queryStringParams = null,
        StatusCodeFlags statusCodesToReturn = StatusCodeFlags.Ok | StatusCodeFlags.NoContent,
        Dictionary<string, string> headers = null
    )
        where T : new()
    {
        var client = new RestClient(basePath);
        var request = new RestRequest(route, verb);

        if (body != null)
        {
            request.AddJsonBody(body);
        }

        request.AddHeader("Content-Type", "application/json");

        if (headers != null)
        {
            foreach (var header in headers)
            {
                request.AddHeader(header.Key, header.Value);
            }
        }

        if (queryStringParams != null)
        {
            foreach (var arg in queryStringParams)
            {
                request.AddParameter(arg.Key, arg.Value, ParameterType.QueryString);
            }
        }

        try
        {
            var response = client.Execute<T>(request);

            if (!statusCodesToReturn.Contains(response.StatusCode))
            {
                throw new ApplicationException(
                    "Error completing request: " + response.StatusCode + " " + response.StatusDescription
                );
            }

            return JsonSerializer.Deserialize<T>(response.Content);
        }
        catch (Exception ex)
        {
            // caused by id 8 and page = 154, page size = 200 => check product catalog id
            _logger.LogError(ex.Message, ex);
            throw;
        }
    }

    public T MakeUrlEncodedCall<T>(
        Method verb,
        string basePath,
        string route,
        Dictionary<string, object> queryStringParams = null,
        Dictionary<string, object> formParams = null,
        StatusCodeFlags statusCodesToReturn = StatusCodeFlags.Ok | StatusCodeFlags.NoContent
    )
        where T : new()
    {
        var client = new RestClient(basePath);
        var request = new RestRequest(route, verb);
        request.AddHeader("Content-Type", "application/x-www-form-urlencoded");

        if (queryStringParams != null)
        {
            foreach (var arg in queryStringParams)
            {
                request.AddParameter(arg.Key, arg.Value, ParameterType.QueryString);
            }
        }

        if (formParams != null)
        {
            foreach (var arg in formParams)
            {
                request.AddParameter(arg.Key, arg.Value, ParameterType.GetOrPost);
            }
        }

        try
        {
            var response = client.Execute<T>(request);

            if (!statusCodesToReturn.Contains(response.StatusCode))
            {
                throw new ApplicationException(
                    "Error completing request: " + response.StatusCode + " " + response.StatusDescription
                );
            }

            return response.Data;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex.Message, ex);

            return default(T);
        }
    }

    public void MakeRestApiCommand(Method verb, string basePath, string route, string json)
    {
        var client = new RestClient(basePath);
        var request = new RestRequest(route, verb);

        if (!string.IsNullOrEmpty(json))
        {
            request.AddJsonBody(json);
        }

        var response = client.Execute(request);

        if (response.StatusCode != HttpStatusCode.OK && response.StatusCode != HttpStatusCode.NoContent)
        {
            throw new ApplicationException("Error completing request: " + response.StatusCode + " " + response.StatusDescription);
        }
    }
}
