﻿using System.Net;

namespace Sample.CrossCutting.Infrastructure.Http;

// For bitwise flags, each subsequent enum value needs to be the next power of 2.
// Here, the bitwise left shift operator is increasing the value by the next power of 2.
[Flags]
public enum StatusCodeFlags
{ // Binary       Decimal
    None = 0, // 0000000      0
    Ok = 1 << 0, // 0000001      1
    NoContent = 1 << 1, // 0000010      2
    Created = 1 << 2, // 0000100      4
    Accepted = 1 << 3, // 0001000      8
    Continue = 1 << 4, // 0010000      16
    Unauthorized = 1 << 5, // 0100000      32
    Forbidden = 1 << 6, // 1000000      64
    NotFound = 1 << 7,
    InternalServerError = 1 << 8,
}

public static class StatusCodeFlagExtensions
{
    public static bool Contains(this StatusCodeFlags codes, HttpStatusCode statusCode)
    {
        if (codes == StatusCodeFlags.None)
        {
            return false;
        }

        switch (statusCode)
        {
            case HttpStatusCode.OK:
                return (codes & StatusCodeFlags.Ok) != 0;
            case HttpStatusCode.NoContent:
                return (codes & StatusCodeFlags.NoContent) != 0;
            case HttpStatusCode.Created:
                return (codes & StatusCodeFlags.Created) != 0;
            case HttpStatusCode.Accepted:
                return (codes & StatusCodeFlags.Accepted) != 0;
            case HttpStatusCode.Continue:
                return (codes & StatusCodeFlags.Continue) != 0;
            case HttpStatusCode.Unauthorized:
                return (codes & StatusCodeFlags.Unauthorized) != 0;
            case HttpStatusCode.Forbidden:
                return (codes & StatusCodeFlags.Forbidden) != 0;
            case HttpStatusCode.NotFound:
                return (codes & StatusCodeFlags.NotFound) != 0;
            case HttpStatusCode.InternalServerError:
                return (codes & StatusCodeFlags.InternalServerError) != 0;
            default:
                return false;
        }
    }
}
