﻿namespace Sample.CrossCutting.Infrastructure.Models;

public class PaypalConfiguration
{
    public string ClientId { get; set; }
    public string ClientSecret { get; set; }
    public string BaseUrl { get; set; }
    public string BrandName { get; set; }
    public string ReturnUrl { get; set; }
    public string CancelUrl { get; set; }
    public string Id { get; set; }
    public string MerchantCustomerId { get; set; }
    public decimal SampleFee { get; set; }
    public string BN_Code { get; set; }
}
