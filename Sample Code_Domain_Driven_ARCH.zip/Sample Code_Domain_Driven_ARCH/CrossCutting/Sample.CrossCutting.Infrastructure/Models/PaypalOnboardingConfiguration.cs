﻿namespace Sample.CrossCutting.Infrastructure.Models;

public class PaypalOnboardingConfiguration
{
    public string ClientId { get; set; }
    public string ClientSecret { get; set; }
    public string BaseUrl { get; set; }
    public string MerchantOnboardingWebhookId { get; set; }
    public string PartnerMerchantId { get; set; }
}
