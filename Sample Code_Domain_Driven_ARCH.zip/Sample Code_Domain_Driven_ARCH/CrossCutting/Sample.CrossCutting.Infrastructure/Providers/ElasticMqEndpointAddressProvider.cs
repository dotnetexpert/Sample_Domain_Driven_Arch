﻿using MassTransit;

namespace Sample.CrossCutting.Infrastructure.Providers;

public class ElasticMqEndpointAddressProvider : IEndpointAddressProvider
{
    readonly IEndpointNameFormatter _formatter;

    public ElasticMqEndpointAddressProvider(IEndpointNameFormatter formatter)
    {
        _formatter = formatter;
    }

    public Uri GetExecuteEndpoint<T, TArguments>()
        where T : class, IExecuteActivity<TArguments>
        where TArguments : class
    {
        return new Uri($"queue:{_formatter.ExecuteActivity<T, TArguments>()}");
    }
}
