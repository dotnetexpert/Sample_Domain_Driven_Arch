﻿using MediatR;
using Sample.Payments.Domain;
using Sample.Payments.Domain.Core;

namespace Sample.CrossDomain.Application.Payments.CreatePaypalOrder;

public record CreatePaypalOrderCommand(CustomerId CustomerId, OrderCreationRequest OrderRequest) : IRequest<Result>;
