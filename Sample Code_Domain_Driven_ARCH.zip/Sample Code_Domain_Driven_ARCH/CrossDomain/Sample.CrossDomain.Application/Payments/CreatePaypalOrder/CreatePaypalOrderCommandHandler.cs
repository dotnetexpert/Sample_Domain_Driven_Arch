﻿using MediatR;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Sample.CrossCutting.Infrastructure.Models;
using Sample.Customers.Infrastructure.Repository;
using Sample.Payments.Domain;
using Sample.Payments.Domain.Core;
using Sample.Payments.Infrastructure.CrystalCommerce.Services;
using Sample.Payments.Infrastructure.Paypal;
using Sample.Stores.Domain.Stores;
using Address = Sample.Payments.Infrastructure.Paypal.Address;
using Money = Sample.Payments.Domain.Core.Money;
using StoreId = Sample.Payments.Domain.StoreId;

namespace Sample.CrossDomain.Application.Payments.CreatePaypalOrder;

public class CreatePaypalOrderCommandHandler : IRequestHandler<CreatePaypalOrderCommand, Result>
{
    private readonly ICustomerRepository _customerRepository;
    private readonly IMerchantRepository _merchantRepository;
    private readonly IPayorRepository _payorRepository;
    private readonly IPaypalService _paypalService;
    private readonly IStoreRepository _storeRepository;
    private readonly ICrystalCommerceV1Service _crystalCommerceV1Service;
    private readonly CountryCodesConfiguration _countryCodes;
    private readonly SampleUrlConfiguration _urlConfiguration;
    private readonly ILogger<CreatePaypalOrderCommandHandler> _logger;

    public CreatePaypalOrderCommandHandler(
        ICustomerRepository customerRepository,
        IPayorRepository payorRepository,
        IMerchantRepository merchantRepository,
        IPaypalService paypalService,
        IStoreRepository storeRepository,
        ICrystalCommerceV1Service crystalCommerceV1Service,
        IOptions<CountryCodesConfiguration> countryCodes,
        IOptions<SampleUrlConfiguration> urlConfiguration,
        ILogger<CreatePaypalOrderCommandHandler> logger
    )
    {
        _customerRepository = customerRepository;
        _payorRepository = payorRepository;
        _merchantRepository = merchantRepository;
        _paypalService = paypalService;
        _storeRepository = storeRepository;
        _crystalCommerceV1Service = crystalCommerceV1Service;
        _countryCodes = countryCodes.Value;
        _urlConfiguration = urlConfiguration.Value;
        _logger = logger;
    }

    public async Task<Result> Handle(CreatePaypalOrderCommand request, CancellationToken cancellationToken)
    {
        var customer = await _customerRepository.GetCartAsync(
            new Sample.Customers.Domain.Core.CustomerId(request.CustomerId.Value)
        );

        if (!customer.Cart.Packages.Any())
        {
            return Result.Failure(Errors.General.NotFound());
        }

        decimal salesTax = 0.0m;
        decimal discount = 0m;
        decimal remainingStoreCredit = 0.00m;
        var purchaseUnitsList = new List<PurchaseUnit>();
        PaymentSystem paymentSystem = PaymentSystem.PayPal;

        if (request.OrderRequest.Country == _countryCodes.Canada)
        {
            salesTax = CanadianTaxRates.GetTaxRateByState(request.OrderRequest.State);
        }
        else
        {
            var shippingAddress = Sample.Payments.Domain.Core.Address.Create(
                request.OrderRequest.Address1,
                request.OrderRequest.Address2,
                request.OrderRequest.City,
                request.OrderRequest.State,
                request.OrderRequest.ZipCode,
                request.OrderRequest.Country
            );

            salesTax = await _crystalCommerceV1Service.RetrieveTaxRateAsync(shippingAddress);
        }

        if (request.OrderRequest.IsStoreCreditUsed)
        {
            remainingStoreCredit = customer.AvailableStoreCredit.Amount;
        }

        List<StoreId> storeIdList = customer.Cart.Packages.Select(cartPackage => new StoreId(cartPackage.StoreId.Value)).ToList();

        var merchants = await _merchantRepository.GetMerchantsByStoreIdsAndPaymentSystemAsync(storeIdList, paymentSystem);

        var payor = _payorRepository.GetByCustomerIdAsync(request.CustomerId);

        if (payor == null)
        {
            _payorRepository.Register(Payor.Create(new(customer.Id.Value)).Value);
        }

        foreach (var cartPackage in customer.Cart.Packages.OrderBy(p => p.PackageNumber).Take(10))
        {
            var merchant = merchants.FirstOrDefault(merchant => merchant.StoreId.Value == cartPackage.StoreId.Value);

            var storeShippingOptions = await _storeRepository.GetShippingOptions(
                new(cartPackage.StoreId.Value),
                request.OrderRequest.Country
            );

            if (merchant == null)
            {
                _logger.LogWarning($"Merchant not found for StoreId: {cartPackage.StoreId.Value}. Skipping package.");
                continue;
            }
            else
            {
                decimal totalProductPrice = cartPackage.CalculateTotalCostWithTax(
                    salesTax,
                    storeShippingOptions.FreeShippingThreshold.Amount
                );

                decimal totalBeforeStoreCredit = cartPackage.CalculateTotalCostWithTax(
                    salesTax,
                    storeShippingOptions.FreeShippingThreshold.Amount
                );

                decimal totalTax = cartPackage.CalculateProductsTax(salesTax) + cartPackage.ShippingTax(salesTax);

                if (remainingStoreCredit > 0)
                {
                    if (remainingStoreCredit >= totalProductPrice)
                    {
                        discount = totalProductPrice;

                        remainingStoreCredit -= totalProductPrice;
                        totalProductPrice = 0;
                    }
                    else
                    {
                        discount = remainingStoreCredit;

                        totalProductPrice -= remainingStoreCredit;
                        remainingStoreCredit = 0;
                    }
                }

                var packageCurrency = cartPackage.CartProducts.First().Price.Currency;

                var purchaseUnit = new PurchaseUnit
                {
                    ReferenceId = cartPackage.ReferenceId.ToString(),
                    Amount = new Sample.Payments.Infrastructure.Paypal.Money
                    {
                        Value = Math.Round(totalProductPrice, 2).ToString(),
                        CurrencyCode = cartPackage.ShippingCost.Currency,
                        Breakdown = new Breakdown
                        {
                            ItemTotal = new Sample.Payments.Infrastructure.Paypal.Money
                            {
                                Value = cartPackage.Subtotal().ToString(),
                                CurrencyCode = packageCurrency,
                            },
                            TaxTotal = new Sample.Payments.Infrastructure.Paypal.Money
                            {
                                Value = totalTax.ToString(),
                                CurrencyCode = packageCurrency,
                            },
                            Shipping = new Sample.Payments.Infrastructure.Paypal.Money
                            {
                                Value = cartPackage.ShippingCost.Amount.ToString(),
                                CurrencyCode = packageCurrency,
                            },
                            Discount = new Sample.Payments.Infrastructure.Paypal.Money
                            {
                                Value = discount.ToString(),
                                CurrencyCode = packageCurrency,
                            },
                        },
                    },
                    SoftDescriptor = "Heavily Played",
                    Payee = new Payee { MerchantId = merchant.MerchantAccounts.First().MerchantConfiguration.AccountId },
                    Shipping = new Shipping
                    {
                        Name = new Name { GivenName = customer.FirstName, Surname = customer.LastName },
                        PhoneNumber = new Phone
                        {
                            PhoneNumber = new PhoneNumber { NationalNumber = $"1{request.OrderRequest.Phone}" },
                        },
                        Address = new Address
                        {
                            AddressLine1 = request.OrderRequest.Address1,
                            AddressLine2 = request.OrderRequest.Address2,
                            AdminArea1 = request.OrderRequest.State,
                            AdminArea2 = request.OrderRequest.City,
                            PostalCode = request.OrderRequest.ZipCode,
                            CountryCode = request.OrderRequest.Country,
                        },
                    },
                    Items = cartPackage
                        .CartProducts.Select(cartProduct => new Items
                        {
                            ProductName = cartProduct.ProductName,
                            Quantity = cartProduct.ProductQuantity,
                            Url =
                                $"{_urlConfiguration.BaseUrl}{_urlConfiguration.ProductUrl}{cartProduct.ProductCatalogId.Value}",
                            ImageUrl = cartProduct.ProductImage,
                            UnitAmount = Money.Of(cartProduct.Price.Amount, cartProduct.Price.Currency),
                        })
                        .ToList(),
                };

                merchant.AddPaypalOrderReferenceIdToPackage(merchant.Id, new ReferenceId(Guid.Parse(purchaseUnit.ReferenceId)));

                if (totalProductPrice > 0)
                {
                    purchaseUnitsList.Add(purchaseUnit);
                }
            }
        }

        var createOrderRequest = new CreateOrderRequest { Intent = Intent.Capture.Name, PurchaseUnits = purchaseUnitsList };

        var createdOrder = await _paypalService.CreateOrderAsync(createOrderRequest);

        if (createdOrder == null)
        {
            return Result.Failure(Errors.Paypal.FailedToCreateOrder());
        }

        await _merchantRepository.SaveChangesAsync();

        return Result.Success(createdOrder);
    }
}
