﻿using MediatR;
using Sample.Customers.Domain.Core;

namespace Sample.Customers.Application.Customers.Cart.GetCart;

public record GetCartItemsQuery(CustomerId CustomerId) : IRequest<Result>;
