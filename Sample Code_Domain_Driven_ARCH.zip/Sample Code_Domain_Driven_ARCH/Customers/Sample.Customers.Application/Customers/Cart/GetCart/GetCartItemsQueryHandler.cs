﻿using MediatR;
using Sample.Customers.Domain.Core;
using Sample.Customers.Domain.Interfaces;

namespace Sample.Customers.Application.Customers.Cart.GetCart;

public class GetCartItemsQueryHandler : IRequestHandler<GetCartItemsQuery, Result>
{
    private readonly ICartRetrievalService _cartRetrievalService;

    public GetCartItemsQueryHandler(ICartRetrievalService cartRetrievalService)
    {
        _cartRetrievalService = cartRetrievalService;
    }

    public async Task<Result> Handle(GetCartItemsQuery request, CancellationToken cancellationToken)
    {
        var cartSummary = await _cartRetrievalService.GetCartSummaries(request.CustomerId);

        if (cartSummary.IsFailure)
        {
            return Result.Failure(Errors.Cart.CartDetailsNotFound());
        }

        return Result.Success(cartSummary.Value);
    }
}
