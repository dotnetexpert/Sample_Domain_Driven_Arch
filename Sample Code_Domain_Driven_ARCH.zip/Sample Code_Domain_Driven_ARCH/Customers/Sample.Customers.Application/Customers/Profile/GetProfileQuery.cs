﻿using MediatR;
using Sample.Customers.Domain.Core;
using Sample.Customers.Domain.Customers;

namespace Sample.Customers.Application.Customers.Profile;

public record GetProfileQuery(Guid Id) : IRequest<Result<ProfileData>>;
