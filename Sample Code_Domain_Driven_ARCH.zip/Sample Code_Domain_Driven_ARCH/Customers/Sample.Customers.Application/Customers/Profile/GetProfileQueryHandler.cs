﻿using MediatR;
using Sample.Customers.Domain.Core;
using Sample.Customers.Domain.Customers;
using Sample.Customers.Infrastructure.Repository;

namespace Sample.Customers.Application.Customers.Profile;

public class GetProfileQueryHandler : IRequestHandler<GetProfileQuery, Result<ProfileData>>
{
    private readonly ICustomerRepository _customerRepository;

    public GetProfileQueryHandler(ICustomerRepository customerRepository)
    {
        _customerRepository = customerRepository;
    }

    public async Task<Result<ProfileData>> Handle(GetProfileQuery request, CancellationToken cancellationToken)
    {
        var customer = await _customerRepository.GetByIdAsync(new(request.Id));

        if (customer == null)
        {
            return Result.Failure<ProfileData>(Errors.General.NotFound());
        }

        return new ProfileData(
            customer.EmailAddress,
            customer.FirstName,
            customer.LastName,
            customer.PhoneNumber,
            customer.ShippingAddress,
            customer.BillingAddress
        );
    }
}
