﻿using MediatR;
using Sample.Customers.Domain.Core;

namespace Sample.Customers.Application.OrderHandler;

public record CustomerWithOrderQuery(CustomerId CustomerId) : IRequest<Result>;
