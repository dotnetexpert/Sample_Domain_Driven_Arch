﻿using MediatR;
using Sample.Customers.Domain.Core;
using Sample.Customers.Infrastructure.Repository;

namespace Sample.Customers.Application.OrderHandler;

public class CustomerWithOrderQueryHandler : IRequestHandler<CustomerWithOrderQuery, Result>
{
    private readonly ICustomerRepository _customerOrderRepository;

    public CustomerWithOrderQueryHandler(ICustomerRepository customerOrderRepository)
    {
        _customerOrderRepository = customerOrderRepository;
    }

    public async Task<Result> Handle(CustomerWithOrderQuery request, CancellationToken cancellationToken)
    {
        var customer = await _customerOrderRepository.GetWithInbox(request.CustomerId);

        return customer.GetInboxDetails();
    }
}
