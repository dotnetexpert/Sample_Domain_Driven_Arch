﻿using MediatR;
using Microsoft.Extensions.Logging;
using Sample.Customers.Domain.Core;
using Sample.Customers.Domain.Customers;
using Sample.Customers.Domain.Interfaces;
using Sample.Customers.Infrastructure.Repository;

namespace Sample.Customers.Application.Services;

public class CartRetrievalService : ICartRetrievalService
{
    private readonly ICustomerRepository _customerRepository;
    private readonly ILogger<CartRetrievalService> _logger;
    private readonly IMediator _mediator;

    public CartRetrievalService(ICustomerRepository customerRepository, ILogger<CartRetrievalService> logger, IMediator mediator)
    {
        _customerRepository = customerRepository;
        _logger = logger;
        _mediator = mediator;
    }

    public async Task<Result<CartSummary>> GetCartSummaries(CustomerId customerId)
    {
        var customerResult = await _customerRepository.GetCartAsync(customerId);

        var storeIdList = customerResult.Cart.Packages.Select(p => p.StoreId).ToList();

        var packageFreeShippingThresholdMapping = await _mediator.Send(
            new CrossCutting.Infrastructure.Events.Stores.Shipping.GetFreeShippingThresholdEvent(
                storeIdList.Select(id => id.Value).ToList()
            )
        );

        return customerResult.Cart.GetSummary(packageFreeShippingThresholdMapping.Value);
    }
}
