﻿using Sample.Customers.Domain.Core;
using Sample.Customers.Domain.Customers;
using Sample.Customers.Domain.OutOfStockProducts;

namespace Sample.Customers.Domain.Carts;

public class Cart : Entity<CartId>
{
    public CustomerId CustomerId { get; private set; }

    private readonly List<Package> _packages = new List<Package>();
    public IReadOnlyCollection<Package> Packages => _packages;

    private readonly List<OutOfStockProduct> _outOfStockProducts = new List<OutOfStockProduct>();
    public IReadOnlyCollection<OutOfStockProduct> OutOfStockProducts => _outOfStockProducts;

    public Result RemovePackage(StoreId storeId)
    {
        int indexToRemove = _packages.FindIndex(i => i.StoreId == storeId);

        _packages.RemoveAt(indexToRemove);

        for (int i = 0; i < _packages.Count; i++)
        {
            _packages[i].SetPackageNumber(i + 1);
        }

        return Result.Success();
    }

    public void RemoveOrderedPackages()
    {
        for (var i = _packages.Count - 1; i >= 0; i--)
        {
            if (_packages[i].OnHold)
            {
                _packages.RemoveAt(i);
            }
        }

        for (var i = _packages.Count; i < _packages.Count; i++)
        {
            _packages[i].SetPackageNumber(i + 1);
        }
    }

    public Result<CartSummary> GetSummary(Dictionary<Guid, decimal> freeShippingThresholdMapping)
    {
        var storeSummaries = _packages
            .Where(package => !package.OnHold)
            .OrderBy(package => package.PackageNumber)
            .GroupBy(package => new
            {
                package.StoreId,
                package.StoreName,
                package.DomainName,
                package.PackageNumber,
                package.MinimumShippingDate,
            })
            .Select(group =>
            {
                var cartProducts = group
                    .SelectMany(package =>
                        package.CartProducts.Select(cartProduct =>
                        {
                            var summaryResult = CartProduct.Create(
                                storeProductId: cartProduct.StoreProductId,
                                storeQuantity: cartProduct.StoreQuantity,
                                productCatalogId: cartProduct.ProductCatalogId,
                                productName: cartProduct.ProductName,
                                productImage: cartProduct.ProductImage,
                                price: cartProduct.Price,
                                productQuantity: cartProduct.ProductQuantity,
                                productWeight: cartProduct.ProductWeight,
                                variantTypes: cartProduct.VariantTypes,
                                saveForLater: cartProduct.SaveForLater,
                                packageId: package.Id,
                                productCategoryId: cartProduct.ProductCategoryId,
                                productCategoryName: cartProduct.ProductCategoryName,
                                externalProductId: cartProduct.ExternalProductId,
                                externalVariantId: cartProduct.ExternalVariantId,
                                productVariantId: cartProduct.ProductVariantId,
                                releaseDate: cartProduct.ReleaseDate
                            );
                            return summaryResult.IsSuccess
                                ? summaryResult.Value
                                : throw new Exception("Failed to create cart product summary.");
                        })
                    )
                    .ToList();

                var packageIds = group.Select(package => package.Id).ToList();
                var storePackage = _packages
                    .Where(package => packageIds.Contains(package.Id) && package.StoreId == group.Key.StoreId)
                    .FirstOrDefault();

                var shippingCost =
                    storePackage != null
                        ? Money.Of(storePackage.ShippingCost.Amount, storePackage.ShippingCost.Currency)
                        : Money.Of(0, Currency.USDollar.Code);
                decimal totalWeight = cartProducts.Sum(cartProduct => cartProduct.ProductWeight);

                decimal freeShippingThresholdAmount;

                if (freeShippingThresholdMapping.TryGetValue(group.Key.StoreId.Value, out freeShippingThresholdAmount))
                {
                    var cartAmount = cartProducts.Sum(cp => cp.Price.Amount * cp.ProductQuantity);
                    bool isFreeShippingThresholdMet = cartAmount >= freeShippingThresholdAmount;

                    var subTotalAmount = isFreeShippingThresholdMet ? 0 : Math.Abs(cartAmount - freeShippingThresholdAmount);

                    var differenceAmount = Money.Of(subTotalAmount, Currency.USDollar.Code);
                    var storeSummaryResult = StoreSummary.Create(
                        storeId: group.Key.StoreId,
                        storeName: group.Key.StoreName,
                        domainName: group.Key.DomainName,
                        shippingCost: isFreeShippingThresholdMet ? Money.Of(0, Currency.USDollar.Code) : shippingCost,
                        packageNumber: group.Key.PackageNumber,
                        cartProducts: cartProducts,
                        isFreeShippingThresholdMet: isFreeShippingThresholdMet,
                        requiredAmountForFreeShipping: differenceAmount,
                        freeShippingThresholdAmount: Money.Of(freeShippingThresholdAmount, Currency.USDollar.Code),
                        minimumShippingDate: group.Key.MinimumShippingDate
                    );

                    return storeSummaryResult.IsSuccess
                        ? storeSummaryResult.Value
                        : throw new Exception("Failed to create store summary.");
                }
                else
                {
                    throw new Exception($"Free shipping threshold not found for store ID: {group.Key.StoreId}");
                }
            })
            .ToList();

        decimal subTotal = storeSummaries.Sum(storeSummary =>
            storeSummary.CartProducts.Sum(product => product.Price.Amount * product.ProductQuantity)
        );
        decimal total = storeSummaries.Sum(storeSummary => storeSummary.ShippingCost.Amount) + subTotal;

        var cartResult = CartSummary.Create(
            Money.Of(subTotal, Currency.USDollar.Code),
            Money.Of(total, Currency.USDollar.Code),
            storeSummaries,
            _outOfStockProducts.ToList()
        );

        if (cartResult.IsFailure)
        {
            return Result.Failure<CartSummary>(Errors.Cart.CartSummaryCreationFailed());
        }

        return cartResult.Value;
    }

    public static Result<Cart> Create(CartId cartId, CustomerId customerId)
    {
        if (cartId == null || cartId.Value == Guid.Empty)
            return Result.Failure<Cart>(Errors.Cart.CartIdNullOrEmpty());

        if (customerId == null || customerId.Value == Guid.Empty)
            return Result.Failure<Cart>(Errors.Cart.CustomerIdNullOrEmpty());

        return new Cart(cartId, customerId);
    }

    public Result<Package> SaveNewPackage(PackageData packageData)
    {
        var result = Package.Create(
            packageData.StoreId,
            packageData.CartId,
            packageData.StoreName,
            packageData.DomainName,
            packageData.StoreEmailAddress,
            packageData.ShippingOptionId,
            packageData.ShippingCost,
            packageData.PackageNumber,
            packageData.IsOrdered,
            packageData.ReferenceId,
            packageData.MinimumShippingDate
        );

        if (result.IsFailure)
        {
            return Result.Failure<Package>(Errors.Cart.PackageCreationFailed());
        }

        _packages.Add(result.Value);

        return result;
    }

    public Result<CartProduct> FindProductByStoreProductId(StoreProductId storeProductId)
    {
        var cartProduct = _packages
            .SelectMany(package => package.CartProducts)
            .FirstOrDefault(cartProduct => cartProduct.StoreProductId == storeProductId);

        if (cartProduct == null)
        {
            return Result.Failure<CartProduct>(Errors.Cart.ProductNotFound(storeProductId.Value));
        }

        return cartProduct;
    }

    public Result<Package> GetStorePackage(StoreId storeId)
    {
        var packages = _packages.FirstOrDefault(package => package.StoreId == storeId);

        if (packages == null)
        {
            return Result.Failure<Package>(Errors.Cart.PackageNotFound(storeId.Value));
        }

        return packages;
    }

    public Cart(CartId cartId, CustomerId customerId)
    {
        Id = cartId;
        CustomerId = customerId;
    }

    private Cart() { }
}
