﻿using Sample.Customers.Domain.Core;

namespace Sample.Customers.Domain.Carts;

public record CartId(Guid Value) : StronglyTypedId<Guid>(Value);
