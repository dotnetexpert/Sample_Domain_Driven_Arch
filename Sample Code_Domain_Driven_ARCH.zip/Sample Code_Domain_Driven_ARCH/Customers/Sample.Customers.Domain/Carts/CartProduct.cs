using Sample.Customers.Domain.Carts;
using Sample.Customers.Domain.Core;

namespace Sample.Customers.Domain.Customers;

public class CartProduct : Entity<CartProductId>
{
    public StoreProductId StoreProductId { get; private set; }
    public string ProductName { get; private set; }
    public Money Price { get; private set; }
    public string ProductImage { get; private set; }
    public int ProductQuantity { get; private set; }
    public Dictionary<string, string> VariantTypes { get; private set; }
    public int StoreQuantity { get; private set; }
    public bool SaveForLater { get; private set; }
    public ProductCatalogId ProductCatalogId { get; private set; }
    public decimal ProductWeight { get; private set; }
    public PackageId PackageId { get; private set; }
    public ProductCategoryId ProductCategoryId { get; private set; }
    public string ProductCategoryName { get; private set; }
    public ExternalProductId ExternalProductId { get; private set; }
    public ExternalVariantId ExternalVariantId { get; private set; }
    public ProductVariantId ProductVariantId { get; private set; }
    public DateTime? ReleaseDate { get; private set; }

    public static Result<CartProduct> Create(
        StoreProductId storeProductId,
        int storeQuantity,
        ProductCatalogId productCatalogId,
        string productName,
        string productImage,
        Money price,
        int productQuantity,
        decimal productWeight,
        Dictionary<string, string> variantTypes,
        bool saveForLater,
        PackageId packageId,
        ProductCategoryId productCategoryId,
        string productCategoryName,
        ExternalProductId externalProductId,
        ExternalVariantId externalVariantId,
        ProductVariantId productVariantId,
        DateTime? releaseDate
    )
    {
        return new CartProduct(
            storeQuantity,
            storeProductId,
            productCatalogId,
            productName,
            productImage,
            price,
            productQuantity,
            productWeight,
            variantTypes,
            saveForLater,
            packageId,
            productCategoryId,
            productCategoryName,
            externalProductId,
            externalVariantId,
            productVariantId,
            releaseDate
        );
    }

    public Result SetProductQuantity(int productQuantity)
    {
        if (productQuantity < 0)
        {
            return Result.Failure(Errors.Quantity.CannotBeNegative());
        }

        ProductQuantity = productQuantity;
        return Result.Success();
    }

    public void SetStoreQuantity(int storeQuantity)
    {
        StoreQuantity = storeQuantity;
    }

    public Result SetProductPrice(Money productPrice)
    {
        if (productPrice.Amount < 0)
        {
            return Result.Failure(Errors.Price.CannotBeZeroOrNegative());
        }

        Price = productPrice;

        return Result.Success();
    }

    private CartProduct(
        int storeQuantity,
        StoreProductId storeProductId,
        ProductCatalogId productCatalogId,
        string productName,
        string productImage,
        Money price,
        int productQuantity,
        decimal productWeight,
        Dictionary<string, string> variantTypes,
        bool saveForLater,
        PackageId packageId,
        ProductCategoryId productCategoryId,
        string productCategoryName,
        ExternalProductId externalProductId,
        ExternalVariantId externalVariantId,
        ProductVariantId productVariantId,
        DateTime? releaseDate
    )
    {
        Id = new(Guid.NewGuid());
        StoreQuantity = storeQuantity;
        StoreProductId = storeProductId;
        ProductCatalogId = productCatalogId;
        ProductName = productName;
        ProductImage = productImage;
        Price = price;
        ProductQuantity = productQuantity;
        ProductWeight = productWeight;
        VariantTypes = variantTypes;
        SaveForLater = saveForLater;
        PackageId = packageId;
        ProductCategoryId = productCategoryId;
        ProductCategoryName = productCategoryName;
        ExternalProductId = externalProductId;
        ExternalVariantId = externalVariantId;
        ProductVariantId = productVariantId;
        ReleaseDate = releaseDate;
    }

    private CartProduct() { }
}
