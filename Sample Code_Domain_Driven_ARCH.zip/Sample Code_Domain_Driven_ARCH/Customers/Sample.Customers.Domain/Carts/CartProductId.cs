﻿using Sample.Customers.Domain.Core;

namespace Sample.Customers.Domain.Carts;

public record CartProductId(Guid Value) : StronglyTypedId<Guid>(Value);
