﻿namespace Sample.Customers.Domain.Core;

public record CustomerId(Guid Value) : StronglyTypedId<Guid>(Value);
