﻿namespace Sample.Customers.Domain.Core;

public record ExternalOrderId(int Value) : StronglyTypedId<int>(Value);
