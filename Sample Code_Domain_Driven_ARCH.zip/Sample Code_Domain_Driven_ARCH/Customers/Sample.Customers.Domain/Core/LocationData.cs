﻿using System.Text.Json.Serialization;

namespace Sample.Customers.Domain.Core;

public class LocationData
{
    [JsonPropertyName("country_name")]
    public string CountryName { get; set; }

    [JsonPropertyName("country_code")]
    public string CountryCode { get; set; }
}
