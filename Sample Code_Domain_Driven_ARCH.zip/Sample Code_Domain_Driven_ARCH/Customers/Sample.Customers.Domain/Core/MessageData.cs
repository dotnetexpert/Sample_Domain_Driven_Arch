﻿namespace Sample.Customers.Domain.Core;

public record MessageData(Guid FromId, string FromName, string Subject, string Body);
