﻿namespace Sample.Customers.Domain.Core;

public class PackageType : Enumeration<PackageType>
{
    public static readonly PackageType Letter = new PackageType(1, "Letter");
    public static readonly PackageType Box = new PackageType(2, "Box");
    public static readonly PackageType LargePackage = new PackageType(3, "Large Package");

    private PackageType(int value, string name)
        : base(value, name) { }
}
