﻿using Sample.Customers.Domain.Carts;
using Sample.Customers.Domain.Core;
using Sample.Customers.Domain.Orders;
using Sample.Customers.Domain.Preferences;
using Sample.Customers.Domain.Refunds;
using Sample.Customers.Domain.TradeInCarts;
using Address = Sample.CrossCutting.Infrastructure.Events.Customers.Address;

namespace Sample.Customers.Domain.Customers;

public class Customer : AggregateRoot<CustomerId>
{
    public string? FirstName { get; private set; }
    public string? LastName { get; private set; }
    public string EmailAddress { get; private set; }
    public string? PhoneNumber { get; private set; }
    public Address? ShippingAddress { get; private set; }
    public Address? BillingAddress { get; private set; }
    public Money AvailableStoreCredit { get; private set; }

    public Cart Cart { get; private set; }
    public UserPreference UserPreference { get; private set; }
    public TradeInCart TradeInCart { get; private set; }

    private readonly List<Order> _orders = new List<Order>();
    public IReadOnlyCollection<Order> Orders => _orders.AsReadOnly();

    public static Result<Customer> Create(
        CustomerId customerId,
        string? firstName,
        string? lastName,
        string emailAddress,
        string? phoneNumber,
        Address? shippingAddress,
        Address? billingAddress
    )
    {
        if (string.IsNullOrWhiteSpace(emailAddress))
            return Result.Failure<Customer>(Errors.General.NullOrWhiteSpaceString(emailAddress));

        var customer = new Customer(customerId, firstName, lastName, emailAddress, phoneNumber, shippingAddress, billingAddress);

        return Result.Success(customer);
    }

    private Customer(
        CustomerId id,
        string? firstName,
        string? lastName,
        string emailAddress,
        string? phoneNumber,
        Address? shippingAddress,
        Address? billingAddress
    )
    {
        Id = id;
        FirstName = firstName;
        LastName = lastName;
        EmailAddress = emailAddress;
        PhoneNumber = phoneNumber;
        ShippingAddress = shippingAddress;
        BillingAddress = billingAddress;
        Cart = new Cart(new CartId(Guid.NewGuid()), id);
        TradeInCart = new TradeInCart(new TradeInCartId(Guid.NewGuid()), id);
    }

    public void CreateUserPreference(
        CustomerId customerId,
        List<CategoryId> favoriteCategoryIds,
        List<CategoryId> excludedCategoryIds
    )
    {
        UserPreference = UserPreference.Create(customerId, favoriteCategoryIds, excludedCategoryIds).Value;
    }

    public void SetName(string firstName, string lastName)
    {
        FirstName = firstName;
        LastName = lastName;
    }

    public void UpdateAvailableStoreCredit(Money updatedStoreCredit)
    {
        AvailableStoreCredit = updatedStoreCredit;
    }

    public void SetEmailAddress(string emailAddress)
    {
        EmailAddress = emailAddress;
    }

    public void SetPhoneNumber(string phoneNumber)
    {
        PhoneNumber = phoneNumber;
    }

    public void SetShippingAddress(Address shippingAddress)
    {
        ShippingAddress = shippingAddress;
    }

    public void SetBillingAddress(Address billingAddress)
    {
        BillingAddress = billingAddress;
    }

    public Result<List<InboxItem>> GetInboxDetails()
    {
        var storeOrders = _orders.SelectMany(o => o.StoreOrders);

        var inboxData = storeOrders
            .Where(o => o.Messages.Any())
            .Select(o =>
            {
                var mostRecentMessage = o.Messages.OrderByDescending(c => c.Date).First();

                return InboxItem.Create(mostRecentMessage, o.StoreName, o.OrderId.Value, o.Id.Value).Value;
            });

        var result = inboxData.OrderByDescending(item => item.Message.Date).ToList();

        return Result.Success(result);
    }

    public Result UpdateCustomerProfile(ProfileData profileData, Customer existingCustomer)
    {
        if (string.IsNullOrWhiteSpace(profileData.FirstName))
            return Result.Failure<Customer>(Errors.General.NullOrWhiteSpaceString(profileData.FirstName));

        if (string.IsNullOrWhiteSpace(profileData.LastName))
            return Result.Failure<Customer>(Errors.General.NullOrWhiteSpaceString(profileData.LastName));

        if (string.IsNullOrWhiteSpace(profileData.PhoneNumber))
            return Result.Failure<Customer>(Errors.General.NullOrWhiteSpaceString(profileData.PhoneNumber));

        if (profileData.ShippingAddress == null)
            return Result.Failure<Customer>(Errors.SaveProfile.NullShippingAddress());

        if (profileData.BillingAddress == null)
            return Result.Failure<Customer>(Errors.SaveProfile.NullBillingAddress());

        existingCustomer.SetName(profileData.FirstName, profileData.LastName);
        existingCustomer.SetPhoneNumber(profileData.PhoneNumber);
        existingCustomer.SetShippingAddress(profileData.ShippingAddress);
        existingCustomer.SetBillingAddress(profileData.BillingAddress);

        return Result.Success();
    }

    public Result<IEnumerable<SummaryItem>> GetOrderDetails(OrderId orderId)
    {
        var orderSummaryData = _orders
            .Where(o => o.Id.Value == orderId.Value)
            .SelectMany(o =>
            {
                var summaryResults = o.StoreOrders.Select(store =>
                {
                    var summaryResult = SummaryItem.Create(
                        subtotal: store.SubTotal,
                        shipping: store.ShippingCost,
                        tax: store.Tax,
                        summaryTotal: store.Total,
                        orderDate: o.Date,
                        storeName: store.StoreName,
                        orderNumber: o.Id.Value,
                        orderProducts: store.Products.ToList(),
                        storeId: store.StoreId.Value,
                        minimumShippingDate: store.MinimumShippingDate
                    );
                    return summaryResult.IsSuccess ? summaryResult.Value : null;
                });
                return summaryResults.Where(summaryItem => summaryItem != null);
            });

        return Result.Success(orderSummaryData);
    }

    public CustomerOrderItem GetOrderHistory(string searchText, int page = 1, int pageSize = 25)
    {
        var query = _orders.AsQueryable();

        if (!string.IsNullOrEmpty(searchText))
        {
            searchText = searchText.ToLower();
            query = query.Where(o =>
                o.Id.ToString().Contains(searchText)
                || o.StoreOrders.Any(storeOrder => storeOrder.StoreName.ToLower().Contains(searchText))
                || o.StoreOrders.Any(storeOrder =>
                    storeOrder.Products.Any(product => product.ProductName.ToLower().Contains(searchText))
                )
            );
        }

        var orderIds = query.Select(orderDetail => orderDetail.Id.Value).ToList();

        var storeOrderSummariesQuery = query.SelectMany(orderDetail =>
            orderDetail.StoreOrders.Select(storeOrder => new
            {
                Subtotal = storeOrder.SubTotal,
                Shipping = storeOrder.ShippingCost,
                ExternalShippingOptionId = storeOrder.ExternalShippingOptionId,
                Tax = storeOrder.Tax,
                PackageId = storeOrder.Id,
                Total = storeOrder.Total,
                OrderDate = orderDetail.Date,
                DateShipped = storeOrder.ShippedAt,
                OrderNumber = orderDetail.Id.Value,
                StoreId = storeOrder.StoreId,
                StoreName = storeOrder.StoreName,
                BillingAddress = orderDetail.BillingAddress,
                ShippingAddress = orderDetail.ShippingAddress,
                CustomerId = orderDetail.CustomerId,
                CustomerName = $"{orderDetail.Customer.FirstName} {orderDetail.Customer.LastName}",
                PhoneNumber = orderDetail.Customer.PhoneNumber,
                Review = storeOrder.Review,
                TrackingNumber = storeOrder.TrackingNumber,
                MinimumShippingDate = storeOrder.MinimumShippingDate,
                OrderItems = storeOrder.Products.Select(product => new
                {
                    ProductId = product.StoreProductId,
                    ProductCatalogId = product.ProductCatalogId,
                    Image = product.ImageUrl,
                    ProductName = product.ProductName,
                    Quantity = product.Quantity,
                    CostPerItem = product.Price,
                    Tax = product.Tax,
                    VariantType = product.VariantType,
                    IsPreOrder = product.IsPreOrder,
                    ReleaseDate = product.ReleaseDate,
                }),
                Refunds = orderDetail.Refunds.Where(r => r.OrderId == orderDetail.Id),
            })
        );

        var orderTotal = storeOrderSummariesQuery.Count();

        var storeOrderSummaries = storeOrderSummariesQuery
            .OrderByDescending(orderSummary => orderSummary.OrderDate)
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToList();

        var storeOrderSummariesWithValues = storeOrderSummaries
            .Select(orderSummary =>
            {
                var orderRefunds = query
                    .Where(orderDetail => orderDetail.Id.Value == orderSummary.OrderNumber)
                    .SelectMany(orderDetail => orderDetail.Refunds)
                    .ToList();

                var amountPreviouslyRefunded = orderRefunds.Sum(refund => refund.Amount.Amount);

                var amountRefunds = new List<AmountRefund>();

                if (orderRefunds.Any())
                {
                    var date = orderRefunds.Min(refund => refund.Date);
                    var totalAmount = orderRefunds.Sum(refund => refund.Amount.Amount);

                    amountRefunds.Add(new AmountRefund(Date: date, Amount: totalAmount));
                }
                else
                {
                    amountRefunds.Add(new AmountRefund(Date: default, Amount: 0));
                }

                return StoreOrderSummary
                    .Create(
                        orderSummary.Subtotal,
                        orderSummary.Shipping,
                        orderSummary.ExternalShippingOptionId,
                        orderSummary.Tax,
                        orderSummary.Total,
                        orderSummary.OrderDate,
                        orderSummary.DateShipped,
                        orderSummary.OrderNumber,
                        orderSummary.PackageId.Value,
                        orderSummary.StoreId.Value,
                        orderSummary.StoreName,
                        orderSummary.BillingAddress,
                        orderSummary.ShippingAddress,
                        orderSummary.CustomerId.Value,
                        orderSummary.CustomerName,
                        orderSummary.PhoneNumber,
                        orderSummary.OrderItems.Select(op =>
                            OrderItem
                                .Create(
                                    op.ProductId.Value,
                                    op.ProductCatalogId.Value,
                                    op.Image,
                                    op.ProductName,
                                    op.Quantity,
                                    op.CostPerItem,
                                    op.Tax,
                                    op.VariantType,
                                    op.IsPreOrder,
                                    op.ReleaseDate
                                )
                                .Value
                        ),
                        orderSummary.Review == null ? null : orderSummary.Review.Comment,
                        orderSummary.Review == null ? null : orderSummary.Review.Rating,
                        orderSummary.Review == null ? null : orderSummary.Review.Date,
                        orderSummary.TrackingNumber,
                        orderRefunds,
                        orderSummary.MinimumShippingDate,
                        amountPreviouslyRefunded,
                        amountRefunds
                    )
                    .Value;
            })
            .ToList();

        return CustomerOrderItem.Create(orderTotal, storeOrderSummariesWithValues.Select(result => result)).Value;
    }

    public Result RecordMessage(StoreOrderId packageId, StoreId storeId, MessageData messageData)
    {
        var order = _orders.Where(o => o.StoreOrders.Any(so => so.Id == packageId)).FirstOrDefault();

        var storeOrder = order.StoreOrders.FirstOrDefault();

        if (storeOrder == null)
            return Result.Failure(Errors.Order.StoreOrderNotFound());

        var result = Message.Create(messageData.FromId, messageData.FromName, messageData.Subject, messageData.Body);

        if (result.IsFailure)
            return result;

        storeOrder.RecordMessage(result.Value);

        return Result.Success();
    }

    public Result<CartProduct> UpdateCartQuantity(CartProduct cartProduct, int productQuantity)
    {
        cartProduct.SetProductQuantity(productQuantity);

        return Result.Success(cartProduct);
    }

    public Result<TradeInCartProduct> UpdateTradeInCartQuantity(TradeInCartProduct tradeInCartProduct, int productQuantity)
    {
        tradeInCartProduct.SetProductQuantity(productQuantity);

        return Result.Success(tradeInCartProduct);
    }

    public void UpdateStoreQuantity(CartProduct cartProduct, int quantity)
    {
        cartProduct.SetStoreQuantity(quantity);
    }

    public Result<IEnumerable<OrderMessageThreadItem>> GetOrderMessageDetails(StoreOrderId storeOrderId)
    {
        var orderMessageList = _orders
            .OrderByDescending(o => o.Date)
            .SelectMany(o =>
            {
                var orderMessageResults = o
                    .StoreOrders.Where(so => so.Id == storeOrderId)
                    .Select(storeOrder =>
                    {
                        var orderMessages = storeOrder.Messages.OrderByDescending(message => message.Date).ToList();
                        var orderMessageResult = OrderMessageThreadItem.Create(
                            messages: orderMessages,
                            storeName: storeOrder.StoreName,
                            orderId: o.Id.Value
                        );

                        return orderMessageResult.IsSuccess ? orderMessageResult.Value : null;
                    });

                return orderMessageResults.Where(orderMessageThreadItem => orderMessageThreadItem != null);
            });

        return Result.Success(orderMessageList);
    }

    private Customer() { }
}
