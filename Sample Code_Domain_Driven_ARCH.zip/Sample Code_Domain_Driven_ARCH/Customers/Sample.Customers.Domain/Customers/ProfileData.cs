﻿using Sample.CrossCutting.Infrastructure.Events.Customers;

namespace Sample.Customers.Domain.Customers;

public record ProfileData(
    string Email,
    string? FirstName,
    string? LastName,
    string? PhoneNumber,
    Address? ShippingAddress,
    Address? BillingAddress
);
