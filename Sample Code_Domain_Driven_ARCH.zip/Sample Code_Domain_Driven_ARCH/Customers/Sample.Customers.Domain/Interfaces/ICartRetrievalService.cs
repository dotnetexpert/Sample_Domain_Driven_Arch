﻿using Sample.Customers.Domain.Core;
using Sample.Customers.Domain.Customers;

namespace Sample.Customers.Domain.Interfaces;

public interface ICartRetrievalService
{
    Task<Result<CartSummary>> GetCartSummaries(CustomerId customerId);
}
