﻿using Sample.Customers.Domain.Carts;
using Sample.Customers.Domain.Core;
using Sample.Customers.Domain.Customers;
using Sample.Customers.Domain.Orders;
using Sample.Customers.Domain.OutOfStockProducts;
using Sample.Customers.Domain.TradeInCarts;

namespace Sample.Customers.Infrastructure.Repository;

public interface ICustomerRepository
{
    Task<Customer> GetWithInbox(CustomerId id);
    Task<Customer> GetWithOrdersAndMessages(CustomerId id);
    Task<Customer> GetWithOrders(CustomerId id);
    Task<Customer> GetWithOrdersAndStoreOrder(CustomerId id, StoreOrderId storeOrderId);
