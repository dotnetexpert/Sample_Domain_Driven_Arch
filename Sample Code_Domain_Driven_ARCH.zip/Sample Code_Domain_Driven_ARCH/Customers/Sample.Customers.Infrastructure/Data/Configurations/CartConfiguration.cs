﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sample.Customers.Domain.Carts;
using Sample.Customers.Domain.Core;

namespace Sample.Customers.Infrastructure.Data.Configurations;

public class CartConfiguration : IEntityTypeConfiguration<Cart>
{
    public void Configure(EntityTypeBuilder<Cart> builder)
    {
        builder.HasKey(p => p.Id);

        builder.Property(p => p.Id).HasConversion(id => id.Value, value => new CartId(value));

        builder.Property(p => p.CustomerId).IsRequired().HasConversion(id => id.Value, value => new CustomerId(value));

        builder.HasMany(p => p.Packages).WithOne().HasForeignKey(p => p.CartId);

        builder.HasMany(p => p.OutOfStockProducts).WithOne().HasForeignKey(p => p.CartId);
    }
}
