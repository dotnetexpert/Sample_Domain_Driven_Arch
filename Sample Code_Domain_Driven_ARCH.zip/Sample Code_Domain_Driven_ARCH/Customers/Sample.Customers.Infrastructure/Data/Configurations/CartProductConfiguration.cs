using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sample.Customers.Domain.Carts;
using Sample.Customers.Domain.Core;
using Sample.Customers.Domain.Customers;

namespace Sample.Customers.Infrastructure.Data.Configurations;

public class CartProductConfiguration : IEntityTypeConfiguration<CartProduct>
{
    public void Configure(EntityTypeBuilder<CartProduct> builder)
    {
        builder.HasKey(p => p.Id);

        builder.Property(p => p.Id).HasConversion(id => id.Value, value => new CartProductId(value));

        builder.Property(p => p.ProductName).HasMaxLength(255).IsRequired();

        builder.Property(p => p.StoreProductId).HasConversion(id => id.Value, value => new StoreProductId(value));

        builder.Property(p => p.ProductCatalogId).HasConversion(id => id.Value, value => new ProductCatalogId(value));

        builder.Property(p => p.ProductCategoryId).HasConversion(id => id.Value, value => new ProductCategoryId(value));

        builder.Property(p => p.ExternalProductId).HasConversion(id => id.Value, value => new ExternalProductId(value));

        builder.Property(p => p.ExternalVariantId).HasConversion(id => id.Value, value => new ExternalVariantId(value));

        builder.Property(p => p.ProductVariantId).HasConversion(id => id.Value, value => new ProductVariantId(value));

        builder.OwnsOne(
            p => p.Price,
            price =>
            {
                price.Property(p => p.Amount).HasColumnName("Price").HasColumnType("decimal(11, 2)").IsRequired();
                price.Property(p => p.Currency).HasColumnName("PriceCurrencyCode").HasMaxLength(3).IsRequired();
            }
        );

        builder.Property(p => p.ProductImage).HasMaxLength(255);

        builder.Property(p => p.ProductQuantity).IsRequired();

        builder.Property(p => p.StoreQuantity).IsRequired();

        builder.Property(p => p.SaveForLater).IsRequired();

        builder.Property(p => p.ProductWeight).IsRequired();
    }
}
