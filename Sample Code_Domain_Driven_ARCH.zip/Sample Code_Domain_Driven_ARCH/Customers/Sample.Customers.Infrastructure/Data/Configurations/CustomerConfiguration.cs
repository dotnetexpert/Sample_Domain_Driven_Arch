﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sample.Customers.Domain.Carts;
using Sample.Customers.Domain.Core;
using Sample.Customers.Domain.Customers;
using Sample.Customers.Domain.Preferences;
using Sample.Customers.Domain.TradeInCarts;

namespace Sample.Customers.Infrastructure.Data.Configurations;

public class CustomerConfiguration : IEntityTypeConfiguration<Customer>
{
    public void Configure(EntityTypeBuilder<Customer> builder)
    {
        builder.HasKey(p => p.Id);

        builder.Property(p => p.Id).HasConversion(id => id.Value, value => new CustomerId(value));

        builder.HasMany(p => p.Orders).WithOne().HasForeignKey(p => p.CustomerId);

        builder.HasOne(p => p.Cart).WithOne().HasForeignKey<Cart>(p => p.CustomerId);

        builder.HasOne(p => p.UserPreference).WithOne().HasForeignKey<UserPreference>(p => p.CustomerId);

        builder.HasOne(p => p.TradeInCart).WithOne().HasForeignKey<TradeInCart>(p => p.CustomerId);

        builder.Property(p => p.FirstName).IsRequired(false);

        builder.Property(p => p.LastName).IsRequired(false);

        builder.Property(p => p.PhoneNumber).IsRequired(false);

        builder.OwnsOne(
            p => p.ShippingAddress,
            p =>
            {
                p.Property(p => p.Address1).HasColumnName("ShippingAddress1").IsRequired(false);

                p.Property(p => p.Address2).HasColumnName("ShippingAddress2").IsRequired(false);

                p.Property(p => p.City).HasColumnName("ShippingCity").IsRequired(false);

                p.Property(p => p.State).HasColumnName("ShippingState").IsRequired(false);

                p.Property(p => p.ZipCode).HasColumnName("ShippingZipCode").IsRequired(false);

                p.Property(p => p.Country).HasColumnName("ShippingCountry").IsRequired(false);
            }
        );

        builder.OwnsOne(
            p => p.BillingAddress,
            p =>
            {
                p.Property(p => p.Address1).HasColumnName("BillingAddress1").IsRequired(false);

                p.Property(p => p.Address2).HasColumnName("BillingAddress2").IsRequired(false);

                p.Property(p => p.City).HasColumnName("BillingCity").IsRequired(false);

                p.Property(p => p.State).HasColumnName("BillingState").IsRequired(false);

                p.Property(p => p.ZipCode).HasColumnName("BillingZipCode").IsRequired(false);

                p.Property(p => p.Country).HasColumnName("BillingCountry").IsRequired(false);
            }
        );

        builder.OwnsOne(
            p => p.AvailableStoreCredit,
            p =>
            {
                p.Property(p => p.Amount).HasColumnName("AvailableStoreCreditAmount").HasPrecision(11, 2).IsRequired();

                p.Property(p => p.Currency).HasColumnName("AvailableStoreCreditCurrencyCode").HasMaxLength(3).IsRequired();
            }
        );
    }
}
