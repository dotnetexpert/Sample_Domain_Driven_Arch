﻿using System.Reflection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Sample.Customers.Domain.Customers;
using Sample.Customers.Domain.GiftCards;

namespace Sample.Customers.Infrastructure.Data;

public class CustomerContext : DbContext
{
    private readonly IConfiguration _configuration;

    public CustomerContext(DbContextOptions<CustomerContext> options)
        : base(options) { }

    public CustomerContext(DbContextOptions<CustomerContext> options, IConfiguration configuration)
        : base(options)
    {
        _configuration = configuration;
    }

    public DbSet<Customer> Customers { get; set; }
    public DbSet<GiftCard> GiftCards { get; set; }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        builder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseNpgsql(_configuration.GetConnectionString("CustomersConnectionString"));
    }
}
