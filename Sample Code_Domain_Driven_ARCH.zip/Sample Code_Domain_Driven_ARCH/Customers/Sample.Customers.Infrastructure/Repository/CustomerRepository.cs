﻿using Microsoft.EntityFrameworkCore;
using Sample.Customers.Domain.Carts;
using Sample.Customers.Domain.Core;
using Sample.Customers.Domain.Customers;
using Sample.Customers.Domain.Orders;
using Sample.Customers.Domain.OutOfStockProducts;
using Sample.Customers.Domain.TradeInCarts;
using Sample.Customers.Infrastructure.Data;

namespace Sample.Customers.Infrastructure.Repository;

public class CustomerRepository : ICustomerRepository
{
    private readonly CustomerContext _context;

    public CustomerRepository(CustomerContext context)
    {
        _context = context;
    }

    public async Task<Customer> GetWithOrdersAndStoreOrder(CustomerId id, StoreOrderId storeOrderId)
    {
        return await _context
            .Customers.Include(o => o.Orders)
            .ThenInclude(s => s.StoreOrders.Where(so => so.Id == storeOrderId))
            .FirstOrDefaultAsync(c => c.Id == id);
    }

    public async Task<Customer> GetWithInbox(CustomerId id)
    {
        var customer = await _context
            .Customers.Include(o => o.Orders)
            .ThenInclude(s => s.StoreOrders)
            .FirstOrDefaultAsync(c => c.Id == id);

        if (customer == null)
        {
            throw new Exception($"Customer with id {id} not found");
        }

        return customer;
    }

    public async Task<Customer> GetWithOrdersAndMessages(CustomerId customerId)
    {
        var customerWithOrdersAndMessages = await _context
            .Customers.Where(customer => customer.Id == customerId)
            .Include(customer => customer.Orders)
            .ThenInclude(order => order.StoreOrders)
            .ThenInclude(storeOrder => storeOrder.Messages)
            .FirstOrDefaultAsync();

        if (customerWithOrdersAndMessages == null)
        {
            throw new Exception($"Customer with CustomerId {customerId} not found");
        }
        return customerWithOrdersAndMessages;
    }
}
