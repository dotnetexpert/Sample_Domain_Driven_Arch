﻿namespace Sample.Orders.Application.Consumers;

public struct ConsumersNamespace { }
