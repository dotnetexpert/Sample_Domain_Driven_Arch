﻿namespace Sample.Orders.Domain.Core;

public record AffiliateId(Guid Value) : StronglyTypedId<Guid>(Value);
