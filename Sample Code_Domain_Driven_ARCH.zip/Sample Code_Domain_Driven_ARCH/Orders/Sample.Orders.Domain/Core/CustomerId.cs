﻿namespace Sample.Orders.Domain.Core;

public record CustomerId(Guid Value) : StronglyTypedId<Guid>(Value);
