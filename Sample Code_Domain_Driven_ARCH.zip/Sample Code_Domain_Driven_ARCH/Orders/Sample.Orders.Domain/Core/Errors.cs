﻿namespace Sample.Orders.Domain.Core;

public static class Errors
{
    public static class General
    {
        public static Error MoneyAmountMustBeGreaterThanZero(decimal amount) =>
            new("Money.Amount", $"'{amount}' must be greater than zero");

        public static Error QuantityGreaterThanZero(int quantity) =>
            new("Quantity.Positive", $"'{quantity}' must be greater than zero");

        public static Error NullOrWhiteSpaceString(string propertyName) =>
            new("String.NullOrWhiteSpace", $"'{propertyName}' cannot be null or white space");

        public static Error DateTimeMin() => new("DateTime.MinValue", $"DateTime cannot equal DateTime.MinValue.");

        public static Error EmptyGuid() => new("Guid.Empty", $"Guid value cannot equal Guid.Empty().");

        public static Error Null() => new("Null", $"Object is null.");

        public static Error NotFound(Guid id = new Guid()) => new("Id.NotFound", $"Id {id} not found.");

        public static Error ObjectAlreadyExists() => new("Id.AlreadyExists", $"Cannot create object, it already exists.");
    }

    public static class OrderPaymentMethod
    {
        public static Error PaymentMethodNameNullOrWhiteSpace() =>
            new Error("OrderPaymentMethod.Create", $"Payment method name cannot be null or white space.");

        public static Error MaskNullOrWhiteSpace() =>
            new Error("OrderPaymentMethod.Create", $"Mask cannot be null or white space.");

        public static Error PaymentTokenNullOrWhiteSpace() =>
            new Error("OrderPaymentMethod.Create", $"Payment token cannot be null or white space.");

        public static Error PaymentMethodIdNullOrMissing(Guid? id) =>
            new Error("OrderPaymentMethod.Create", $"Payment method id {id} cannot be null or an empty Guid.");
    }

    public static class StoreOrder
    {
        public static Error ProductNotFound(Guid id) =>
            new Error("Order.ReturnProduct", $"Product {id} not found in store order.");

        public static Error StoreOrdersNullOrMissing() => new Error("StoreOrder.Create", $"StoreOrders cannot be empty.");

        public static Error StoreNameNullOrWhiteSpace() =>
            new Error("StoreOrder.Create", $"Store name cannot be null or white space.");

        public static Error StoreEmaillNulLOrWhiteSpace() =>
            new Error("StoreOrder.Create", $"Store email cannot be null or white space.");

        public static Error StoreIdNullOrEmpty(Guid? id) =>
            new Error("StoreOrder.Create", $"Store id cannot be null or an empty Guid.");

        public static Error ShippingMethodIdNullOrEmpty(Guid? id) =>
            new Error("StoreOrder.Create", $"Shipping method id {id} cannot be null or an empty Guid.");

        public static Error ShippingCostCannotBeNullOrNegative(Money shippingCost) =>
            new Error("StoreOrder.Create", $"Shipping cost {shippingCost?.Amount} cannot be null or have a negative amount.");
    }

    public static class OrderSummary
    {
        public static Error StoreOrdersMissing() => new Error("OrderSummary.Create", $"StoreOrders cannot be empty.");

        public static Error StoreOrdersNull() => new Error("OrderSummary.Create", $"StoreOrders cannot be null.");
    }

    public static class Order
    {
        public static Error StoreOrderWithStoreProductIdNotFound(Guid id) =>
            new Error("Order.ReturnProduct", $"Store product {id} not found in store order.");

        public static Error PaymentMethodMissing() => new Error("Order.Create", $"Payment method missing.");

        public static Error OrderNotFound(Guid orderId) =>
            new Error("Order.OrderNotFound", $"Order not found for OrderId: {orderId}");

        public static Error ReturnQuantityExceedsOrderQuantity(Guid productId) =>
            new Error(
                "Order.ReturnProduct",
                $"Cannot return a quantity greater than the remaining quantity of product {productId}."
            );

        public static Error ProductNotFound(Guid id) => new Error("Order.ReturnProduct", $"Order product {id} is not found.");

        public static Error FullRefundIssued(Guid id) =>
            new Error("Order.IssueFullRefund", $"A full refund has been issued for order {id} previously.");

        public static Error RefundAmountExceedsLimit(decimal amount, decimal threshold) =>
            new Error("Order.IssuePartialRefund", $"Refund of {amount:C} exceeds the refund threshold of {threshold:C}.");

        public static Error OrderMissingProducts(Guid orderId) =>
            new Error("Order.IssuePartialRefund", $"Order {orderId} is missing products and cannot be created.");

        public static Error OrderMissingStoreOrders() =>
            new Error("Order.Create", $"Order is missing products and cannot be created.");

        public static Error BillingAddressMissing() =>
            new Error("Order.Create", $"Order is missing billing address and cannot be created.");

        public static Error ShippingAddressMissing() =>
            new Error("Order.Create", $"Order is missing shipping address and cannot be created.");

        public static Error NegativeOrMissingShippingCost() =>
            new Error("Order.Create", $"Order has a missing or negative shipping cost and cannot be created.");
    }

    public static class Customer
    {
        public static Error CustomerNotFound(Guid customerId) =>
            new Error("Order.CustomerNotFound", $"Customer with ID {customerId} not found.");
    }
}
