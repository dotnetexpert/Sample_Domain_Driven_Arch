﻿namespace Sample.Orders.Domain.Core;

public class Money : ValueObject<Money>
{
    public decimal Amount { get; }
    public string Currency { get; }

    public static Money Of(decimal value, string currencyCode)
    {
        if (string.IsNullOrEmpty(currencyCode))
        {
            throw new Exception("Money must have currency.");
        }

        if (value < 0)
        {
            throw new Exception("Money amount value cannot be negative.");
        }

        return new Money(value, currencyCode);
    }

    public static Money operator *(decimal number, Money rightValue)
    {
        return new Money(number * rightValue.Amount, rightValue.Currency);
    }

    public static Money operator +(Money money1, Money money2)
    {
        if (!money1.Currency.Equals(money2.Currency))
        {
            throw new Exception("You cannot sum different currencies.");
        }

        return Of(money1.Amount + money2.Amount, money1.Currency);
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Amount;
        yield return Currency;
    }

    private Money(decimal amount, string currencyCode)
    {
        Amount = amount;
        Currency = currencyCode;
    }

    private Money() { }
}
