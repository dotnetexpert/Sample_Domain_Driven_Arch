﻿namespace Sample.Orders.Domain.Core;

public class OrderStatus : Enumeration<OrderStatus>
{
    public static readonly OrderStatus Pending = new OrderStatus(1, "Pending");
    public static readonly OrderStatus Complete = new OrderStatus(2, "Complete");
    public static readonly OrderStatus Failed = new OrderStatus(3, "Failed");
    public static readonly OrderStatus Processing = new OrderStatus(4, "Processing");
    public static readonly OrderStatus Shipped = new OrderStatus(5, "Shipped");

    private OrderStatus(int value, string name)
        : base(value, name) { }

    public static OrderStatus FromValue(int value)
    {
        switch (value)
        {
            case 1:
                return Pending;
            case 2:
                return Complete;
            case 3:
                return Failed;
            case 4:
                return Processing;
            case 5:
                return Shipped;
            default:
                throw new Exception($"Invalid value for OrderStatus: {value}");
        }
    }
}
