﻿namespace Sample.Orders.Domain.Core
{
    public enum OrderStatusUpdate
    {
        Pending,
        Complete,
        Failed,
        Processing,
        Shipped,
        Unknown,
    }
}
