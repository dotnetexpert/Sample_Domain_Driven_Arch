﻿namespace Sample.Orders.Domain.Core;

public class PaymentAttributeStatus : Enumeration<PaymentAttributeStatus>
{
    public static readonly PaymentAttributeStatus Received = new PaymentAttributeStatus(1, "Received");
    public static readonly PaymentAttributeStatus Pending = new PaymentAttributeStatus(2, "Pending");
    public static readonly PaymentAttributeStatus Authorized = new PaymentAttributeStatus(3, "Authorized");
    public static readonly PaymentAttributeStatus Refunded = new PaymentAttributeStatus(4, "Refunded");
    public static readonly PaymentAttributeStatus Removed = new PaymentAttributeStatus(5, "Removed");

    private PaymentAttributeStatus(int value, string name)
        : base(value, name) { }
}
