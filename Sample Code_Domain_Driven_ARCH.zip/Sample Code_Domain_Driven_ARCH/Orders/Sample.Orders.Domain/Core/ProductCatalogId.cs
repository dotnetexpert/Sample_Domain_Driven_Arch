﻿namespace Sample.Orders.Domain.Core;

public record ProductCatalogId(Guid Value) : StronglyTypedId<Guid>(Value);
