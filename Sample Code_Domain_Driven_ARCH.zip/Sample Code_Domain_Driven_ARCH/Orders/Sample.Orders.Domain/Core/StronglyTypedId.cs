﻿namespace Sample.Orders.Domain.Core;

public abstract record StronglyTypedId<TValue>(TValue Value)
{
    public override string ToString() => Value.ToString();
}
