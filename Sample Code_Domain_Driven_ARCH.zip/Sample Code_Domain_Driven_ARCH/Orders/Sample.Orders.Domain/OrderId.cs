﻿using Sample.Orders.Domain.Core;

namespace Sample.Orders.Domain;

public record OrderId(Guid Value) : StronglyTypedId<Guid>(Value);
