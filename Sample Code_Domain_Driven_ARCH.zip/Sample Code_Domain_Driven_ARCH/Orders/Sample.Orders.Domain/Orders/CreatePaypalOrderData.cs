﻿namespace Sample.Orders.Domain.Orders;

public record CreatePaypalOrderData(decimal Amount);
