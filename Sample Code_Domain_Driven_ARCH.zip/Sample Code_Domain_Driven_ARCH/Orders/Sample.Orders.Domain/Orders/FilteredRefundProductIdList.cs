﻿namespace Sample.Orders.Domain.Orders;

public record FilteredRefundProductIdList(List<Guid> RefundProductIds, List<Guid> PendingRefundProductIds);
