﻿namespace Sample.Orders.Domain.Orders
{
    public interface IOrderRepository
    {
        void Add(Order order);
    }
}
