﻿using Sample.Orders.Domain.Core;

namespace Sample.Orders.Domain.Orders;

public class Order : AggregateRoot<OrderId>
{
    public OrderCustomer Customer { get; private set; }
    public OrderPaymentMethod PaymentMethod { get; private set; }
    public Address BillingAddress { get; private set; }
    public Address ShippingAddress { get; private set; }
    public OrderStatus Status { get; private set; } = OrderStatus.Processing;
    public DateTime CreatedAt { get; private set; }
    public DateTime? CompletedAt { get; private set; }
    public AffiliateId? AffiliateId { get; private set; }

    public Money Subtotal
    {
        get { return Money.Of(_storeOrders.Sum(t => t.Subtotal.Amount), Currency.USDollar.Code); }
    }

    public Money Tax
    {
        get { return Money.Of(_storeOrders.Sum(t => t.Tax.Amount), Currency.USDollar.Code); }
    }

    public Money ShippingCost
    {
        get { return Money.Of(_storeOrders.Sum(t => t.ShippingCost.Amount), Currency.USDollar.Code); }
    }

    public Money Total
    {
        get { return Money.Of(_storeOrders.Sum(t => t.Total.Amount), Currency.USDollar.Code); }
    }

    public DateTime Date { get; set; } = DateTime.UtcNow;

    private readonly List<StoreOrder> _storeOrders = new List<StoreOrder>();
    public IReadOnlyCollection<StoreOrder> StoreOrders => _storeOrders.AsReadOnly();

    private readonly List<Refund> _refunds = new List<Refund>();
    public IReadOnlyCollection<Refund> Refunds => _refunds.AsReadOnly();

    public static Result<Order> Create(OrderId orderId, OrderData orderData)
    {
        if (orderData.ShippingAddress == null)
            return Result.Failure<Order>(Errors.Order.ShippingAddressMissing());

        if (orderData.BillingAddress == null)
            return Result.Failure<Order>(Errors.Order.BillingAddressMissing());

        if (orderData.PaymentMethod == null)
            return Result.Failure<Order>(Errors.Order.PaymentMethodMissing());

        if (orderData.StoreOrderData == null || !orderData.StoreOrderData.Any())
            return Result.Failure<Order>(Errors.Order.OrderMissingStoreOrders());

        if (orderData.Customer == null)
            throw new Exception("Customer is required");

        var storeOrders = orderData
            .StoreOrderData.Select(d =>
            {
                var orderProducts = d
                    .OrderProductData.Select(o =>
                        OrderProduct
                            .Create(
                                o.StoreProductId,
                                o.ProductCatalogId,
                                o.ProductName,
                                o.UnitPrice,
                                o.Quantity,
                                o.UnitTax,
                                o.PackageType,
                                o.ProductImageUrl,
                                o.Variant
                            )
                            .Value
                    )
                    .ToList();

                return StoreOrder.Create(
                    d.StoreName,
                    d.StoreId,
                    d.PackageId,
                    d.StoreEmail,
                    orderProducts,
                    d.StoreShippingMethodId,
                    d.ShippingCost,
                    d.ShippingTax,
                    d.ReferenceId
                );
            })
            .ToList();

        if (storeOrders.Any(o => o.IsFailure))
            return Result.Failure<Order>(storeOrders.First(o => o.IsFailure).Error);

        return new Order(
            orderId,
            orderData.AffiliateId,
            orderData.Customer,
            orderData.PaymentMethod,
            orderData.BillingAddress,
            orderData.ShippingAddress,
            storeOrders.Select(o => o.Value).ToList(),
            orderData.CreatedAt
        );
    }

    public void Complete()
    {
        CompletedAt = DateTime.UtcNow;
        Status = OrderStatus.Complete;
    }

    public void SetStatus(OrderStatus status)
    {
        Status = status;
    }

    public Result ReturnProduct(ProductReturn productReturn)
    {
        var storeOrder = _storeOrders.FirstOrDefault(l =>
            l.Products.Select(l => l.StoreProductId).Contains(productReturn.ProductId)
        );

        if (storeOrder == null)
            return Result.Failure(Errors.Order.StoreOrderWithStoreProductIdNotFound(productReturn.ProductId.Value));

        var orderItem = storeOrder.Products.FirstOrDefault(s => s.StoreProductId == productReturn.ProductId);

        if (orderItem == null)
            return Result.Failure(Errors.StoreOrder.ProductNotFound(productReturn.ProductId.Value));

        var returnResult = orderItem.ReturnProduct(productReturn.Quantity);

        if (returnResult.IsFailure)
            return returnResult;

        var refund = Refund.Create(
            Id,
            Money.Of(orderItem.Price.Amount * productReturn.Quantity, Currency.USDollar.Code),
            Money.Of(orderItem.Tax.Amount * productReturn.Quantity, Currency.USDollar.Code),
            storeOrder.StoreId,
            new List<RefundDetails> { RefundDetails.Create(new(Guid.NewGuid()), 1) },
            Guid.Empty,
            null
        );

        if (refund.IsFailure)
            return refund;

        _refunds.Add(refund.Value);

        return refund;
    }

    public Result IssueFullRefund()
    {
        if (Refunds.Sum(a => a.Amount.Amount + a.Tax.Amount) == Total.Amount)
        {
            return Result.Failure(Errors.Order.FullRefundIssued(Id.Value));
        }

        var refund = Refund.Create(
            Id,
            Subtotal,
            Tax,
            new(Guid.NewGuid()),
            new List<RefundDetails> { RefundDetails.Create(new(Guid.NewGuid()), 1) },
            Guid.Empty,
            null
        );

        if (refund.IsFailure)
        {
            return Result.Failure(refund.Error);
        }

        _refunds.Add(refund.Value);

        return Result.Success();
    }

    public Result IssuePartialRefund(Money amount, Money tax, StoreId storeId, List<RefundDetails> refundDetails)
    {
        var previousRefunds = Refunds.Sum(a => a.Amount.Amount + a.Tax.Amount);

        if (previousRefunds + amount.Amount > Total.Amount)
        {
            return Result.Failure(
                Errors.Order.RefundAmountExceedsLimit(amount.Amount + tax.Amount, Total.Amount - previousRefunds)
            );
        }

        var refund = Refund.Create(Id, amount, tax, storeId, refundDetails, Guid.Empty, null);

        if (refund.IsFailure)
        {
            return Result.Failure(refund.Error);
        }

        _refunds.Add(refund.Value);

        return Result.Success();
    }

    public void AddRefund(Refund refund)
    {
        _refunds.Add(refund);
    }

    private Order(
        OrderId orderId,
        AffiliateId? affiliateId,
        OrderCustomer customer,
        OrderPaymentMethod paymentMethod,
        Address billingAddress,
        Address shippingAddress,
        List<StoreOrder> storeOrders,
        DateTime createdAt
    )
    {
        Id = orderId;
        AffiliateId = affiliateId;
        PaymentMethod = paymentMethod;
        Customer = customer;
        BillingAddress = billingAddress;
        ShippingAddress = shippingAddress;
        _storeOrders = storeOrders;
        CreatedAt = createdAt;
        _storeOrders.ForEach(o => o.SetOrderId(Id));
    }

    private Order() { }
}
