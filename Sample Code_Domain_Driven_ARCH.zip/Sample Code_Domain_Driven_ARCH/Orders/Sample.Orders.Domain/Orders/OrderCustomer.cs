﻿using Sample.Orders.Domain.Core;

namespace Sample.Orders.Domain.Orders;

public class OrderCustomer : ValueObject<OrderCustomer>
{
    public string FirstName { get; set; }
    public string LastName { get; set; }
    public string? PhoneNumber { get; set; }
    public string Email { get; set; }
    public CustomerId CustomerId { get; set; }

    public static Result<OrderCustomer> Create(
        string firstName,
        string lastName,
        string phoneNumber,
        string email,
        CustomerId customerId
    )
    {
        if (string.IsNullOrWhiteSpace(firstName))
            return Result.Failure<OrderCustomer>(Errors.General.NullOrWhiteSpaceString(nameof(firstName)));

        if (string.IsNullOrWhiteSpace(email))
            return Result.Failure<OrderCustomer>(Errors.General.NullOrWhiteSpaceString(nameof(email)));

        if (customerId == null || customerId.Value == Guid.Empty)
            return Result.Failure<OrderCustomer>(Errors.General.NotFound(customerId.Value));

        return new OrderCustomer(firstName, lastName, phoneNumber, email, customerId);
    }

    private OrderCustomer(string firstName, string lastName, string phoneNumber, string email, CustomerId customerId)
    {
        FirstName = firstName;
        LastName = lastName;
        PhoneNumber = phoneNumber;
        Email = email;
        CustomerId = customerId;
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return CustomerId;
        yield return Email;
        yield return FirstName;
        yield return LastName;
        yield return PhoneNumber;
    }

    private OrderCustomer() { }
}
