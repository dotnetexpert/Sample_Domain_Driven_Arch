﻿using MediatR;
using Sample.Orders.Domain.Core;

namespace Sample.Orders.Domain.Orders;

public record OrderData(
    AffiliateId? AffiliateId,
    DateTime CreatedAt,
    OrderCustomer Customer,
    OrderPaymentMethod PaymentMethod,
    List<StoreOrderData> StoreOrderData,
    Address BillingAddress,
    Address ShippingAddress
) : IRequest<Result>;
