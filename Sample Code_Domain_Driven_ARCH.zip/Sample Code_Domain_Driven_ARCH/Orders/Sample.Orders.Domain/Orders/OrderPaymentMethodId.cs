﻿using Sample.Orders.Domain.Core;

namespace Sample.Orders.Domain.Orders;

public record OrderPaymentMethodId(Guid Value) : StronglyTypedId<Guid>(Value);
