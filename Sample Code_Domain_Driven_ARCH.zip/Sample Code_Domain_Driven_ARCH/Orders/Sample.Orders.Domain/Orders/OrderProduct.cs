﻿using Sample.Orders.Domain.Core;

namespace Sample.Orders.Domain.Orders;

public class OrderProduct : ValueObject<OrderProduct>
{
    public StoreProductId StoreProductId { get; private set; }
    public ProductCatalogId ProductCatalogId { get; private set; }
    public string ProductName { get; private set; }
    public Money Price { get; private set; }
    public Money Tax { get; private set; }
    public int Quantity { get; private set; }
    public int ReturnedQuantity { get; private set; }
    public PackageType PackageType { get; private set; }
    public string ProductImageUrl { get; private set; }
    public Dictionary<string, string> Variant { get; private set; }

    public static Result<OrderProduct> Create(
        StoreProductId storeProductId,
        ProductCatalogId productCatalogId,
        string productName,
        Money price,
        int quantity,
        Money tax,
        PackageType packageType,
        string productImageUrl,
        Dictionary<string, string> variant
    )
    {
        if (quantity <= 0)
            return Result.Failure<OrderProduct>(Errors.General.QuantityGreaterThanZero(quantity));

        if (price == null)
            return Result.Failure<OrderProduct>(Errors.General.Null());

        if (price != null && price.Amount <= 0)
            return Result.Failure<OrderProduct>(Errors.General.MoneyAmountMustBeGreaterThanZero(price.Amount));

        if (tax == null)
            return Result.Failure<OrderProduct>(Errors.General.Null());

        if (tax != null && tax.Amount <= 0)
            return Result.Failure<OrderProduct>(Errors.General.MoneyAmountMustBeGreaterThanZero(tax.Amount));

        if (string.IsNullOrWhiteSpace(productName))
            return Result.Failure<OrderProduct>(Errors.General.NullOrWhiteSpaceString(productName));

        return new OrderProduct(
            storeProductId,
            productCatalogId,
            productName,
            price,
            quantity,
            tax,
            packageType,
            productImageUrl,
            variant
        );
    }

    public void SetTax(Money tax)
    {
        Tax = tax;
    }

    public Result ReturnProduct(int quantity)
    {
        if (quantity <= 0)
            return Result.Failure(Errors.General.QuantityGreaterThanZero(quantity));

        if (quantity > (Quantity - ReturnedQuantity))
            return Result.Failure(Errors.Order.ReturnQuantityExceedsOrderQuantity(StoreProductId.Value));

        ReturnedQuantity += quantity;

        return Result.Success();
    }

    private OrderProduct(
        StoreProductId storeProductId,
        ProductCatalogId productCatalogId,
        string productName,
        Money price,
        int quantity,
        Money tax,
        PackageType packageType,
        string productImageUrl,
        Dictionary<string, string> variant
    )
    {
        StoreProductId = storeProductId;
        ProductCatalogId = productCatalogId;
        ProductName = productName;
        Price = price;
        Quantity = quantity;
        Tax = tax;
        PackageType = packageType;
        ProductImageUrl = productImageUrl;
        Variant = variant;
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return StoreProductId;
        yield return ProductCatalogId;
        yield return ProductName;
        yield return Price;
        yield return Tax;
        yield return Quantity;
        yield return ReturnedQuantity;
        yield return PackageType;
        yield return ProductImageUrl;
        yield return Variant;
    }

    private OrderProduct() { }
}
