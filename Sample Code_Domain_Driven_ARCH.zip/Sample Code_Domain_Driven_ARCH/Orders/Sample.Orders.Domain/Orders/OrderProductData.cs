﻿using MediatR;
using Sample.Orders.Domain.Core;

namespace Sample.Orders.Domain.Orders;

public record OrderProductData(
    StoreProductId StoreProductId,
    ProductCatalogId ProductCatalogId,
    string ProductName,
    Money UnitPrice,
    Money UnitTax,
    int Quantity,
    PackageType PackageType,
    string ProductImageUrl,
    Dictionary<string, string> Variant,
    bool isPreOrder,
    DateTime? releaseDate
) : IRequest<Result>;
