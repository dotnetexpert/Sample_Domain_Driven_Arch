﻿using MassTransit;

namespace Sample.Orders.Domain.Orders;

public class OrderState : SagaStateMachineInstance
{
    public Guid CorrelationId { get; set; }
    public int CurrentState { get; set; }
    public CrossCutting.Infrastructure.Models.OrderData OrderData { get; set; }

    public Guid? ScheduleRetryToken { get; set; }
    public int RetryAttempt { get; set; }
    public string? Reason { get; set; }
}
