﻿using Sample.Orders.Domain.Core;

namespace Sample.Orders.Domain.Orders;

public class OrderSummary
{
    public Money Subtotal
    {
        get { return Money.Of(_storeOrders.Sum(t => t.Subtotal.Amount), Currency.USDollar.Code); }
    }

    public Money ShippingCost
    {
        get { return Money.Of(_storeOrders.Sum(t => t.ShippingCost.Amount), Currency.USDollar.Code); }
    }

    public Money Total
    {
        get { return Money.Of(_storeOrders.Sum(t => t.Total.Amount), Currency.USDollar.Code); }
    }

    public Money Tax
    {
        get { return Money.Of(_storeOrders.Sum(t => t.Tax.Amount), Currency.USDollar.Code); }
    }

    private readonly List<StoreOrder> _storeOrders = new List<StoreOrder>();
    public IReadOnlyCollection<StoreOrder> StoreOrders => _storeOrders.AsReadOnly();

    public static Result<OrderSummary> Create(List<StoreOrder> storeOrders)
    {
        if (storeOrders == null)
            return Result.Failure<OrderSummary>(Errors.OrderSummary.StoreOrdersNull());

        if (!storeOrders.Any())
            return Result.Failure<OrderSummary>(Errors.OrderSummary.StoreOrdersMissing());

        return new OrderSummary(storeOrders);
    }

    private OrderSummary(List<StoreOrder> storeOrders)
    {
        _storeOrders = storeOrders;
    }
}
