﻿using Sample.Orders.Domain.Core;

namespace Sample.Orders.Domain.Orders;

public record class ProductData(
    StoreProductId ProductId,
    ProductCatalogId ProductCatalogId,
    string ProductName,
    int Quantity,
    Money UnitPrice,
    Money? UnitTax = null
);
