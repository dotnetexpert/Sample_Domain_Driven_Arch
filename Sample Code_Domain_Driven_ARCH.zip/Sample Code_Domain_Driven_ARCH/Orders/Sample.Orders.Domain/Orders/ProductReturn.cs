﻿using Sample.Orders.Domain.Core;

namespace Sample.Orders.Domain.Orders;

public record ProductReturn(StoreProductId ProductId, int Quantity, PaymentSystem PaymentSystem);
