﻿using Sample.Orders.Domain.Core;

namespace Sample.Orders.Domain.Orders;

public class Refund : Entity<RefundId>
{
    public OrderId OrderId { get; private set; }
    public Money Amount { get; private set; }
    public Money Tax { get; private set; }
    public RefundStatus Status { get; private set; } = RefundStatus.Pending;
    public StoreId StoreId { get; private set; }
    public Guid ReferenceId { get; private set; }
    public PaymentSystem PaymentSystem { get; private set; }

    private readonly List<RefundDetails> _refundDetails = new List<RefundDetails>();
    public IReadOnlyCollection<RefundDetails> RefundDetails => _refundDetails.AsReadOnly();

    public Money Total
    {
        get { return Money.Of(Amount.Amount + Tax.Amount, Amount.Currency); }
    }

    public DateTime Date { get; private set; } = DateTime.UtcNow;

    public static Result<Refund> Create(
        OrderId orderId,
        Money amount,
        Money tax,
        StoreId storeId,
        List<RefundDetails> refundDetails,
        Guid referenceId,
        PaymentSystem paymentSystem
    )
    {
        if (amount == null || amount.Amount <= 0)
            return Result.Failure<Refund>(Errors.General.MoneyAmountMustBeGreaterThanZero(amount.Amount));

        if (tax == null || tax.Amount < 0)
            return Result.Failure<Refund>(Errors.General.MoneyAmountMustBeGreaterThanZero(amount.Amount));

        return new Refund(orderId, amount, tax, storeId, refundDetails, referenceId, paymentSystem);
    }

    private Refund(
        OrderId orderId,
        Money amount,
        Money tax,
        StoreId storeId,
        List<RefundDetails> refundDetails,
        Guid referenceId,
        PaymentSystem paymentSystem
    )
    {
        Id = new(Guid.NewGuid());
        OrderId = orderId;
        Amount = amount;
        Tax = tax;
        StoreId = storeId;
        Status = RefundStatus.Pending;
        _refundDetails = refundDetails;
        ReferenceId = referenceId;
        PaymentSystem = paymentSystem;
    }

    public void SetStatus(RefundStatus status)
    {
        Status = status;
    }

    public void Complete()
    {
        Status = RefundStatus.Completed;
    }

    private Refund() { }
}
