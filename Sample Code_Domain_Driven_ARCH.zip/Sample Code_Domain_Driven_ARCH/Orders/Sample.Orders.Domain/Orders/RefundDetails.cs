﻿using Sample.Orders.Domain.Core;

namespace Sample.Orders.Domain.Orders;

public class RefundDetails : ValueObject<RefundDetails>
{
    public StoreProductId StoreProductId { get; private set; }
    public int ReturnQuantity { get; private set; }

    public static RefundDetails Create(StoreProductId storeProductId, int returnQuantity)
    {
        return new RefundDetails(storeProductId, returnQuantity);
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return StoreProductId;
        yield return ReturnQuantity;
    }

    private RefundDetails(StoreProductId storeProductId, int returnQuantity)
    {
        StoreProductId = storeProductId;
        ReturnQuantity = returnQuantity;
    }
}
