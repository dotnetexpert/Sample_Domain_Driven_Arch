﻿using Sample.Orders.Domain.Core;

namespace Sample.Orders.Domain.Orders;

public record RefundId(Guid Value) : StronglyTypedId<Guid>(Value);
