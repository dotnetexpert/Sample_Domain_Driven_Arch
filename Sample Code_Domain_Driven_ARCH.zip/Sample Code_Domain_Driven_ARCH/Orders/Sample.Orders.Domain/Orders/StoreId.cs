﻿using Sample.Orders.Domain.Core;

namespace Sample.Orders.Domain.Orders;

public record StoreId(Guid Value) : StronglyTypedId<Guid>(Value);
