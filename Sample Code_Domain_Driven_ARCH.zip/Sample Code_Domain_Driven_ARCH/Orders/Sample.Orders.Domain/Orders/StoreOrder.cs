﻿using System.Text.Json;
using Sample.Orders.Domain.Core;

namespace Sample.Orders.Domain.Orders;

public class StoreOrder : Entity<StoreOrderId>
{
    public string StoreName { get; private set; }
    public string StoreEmail { get; private set; }
    public StoreId StoreId { get; private set; }
    public OrderId OrderId { get; private set; }
    public Guid ReferenceId { get; private set; }
    public PackageId PackageId { get; private set; }
    public int? ExternalOrderId { get; private set; }
    public OrderStatus Status { get; private set; } = OrderStatus.Processing;
    public DateTime ShippedAt { get; private set; }
    public DateTime LastModified { get; private set; }
    public JsonDocument CrystalCommerceOrderConfirmationDetails { get; private set; }
    public string? TrackingNumber { get; private set; }
    public Money Subtotal
    {
        get
        {
            return Money.Of(
                _products.Sum(t => t.Price.Amount * t.Quantity),
                Currency.USDollar.Code
            );
        }
    }

    public Money Tax
    {
        get
        {
            return Money.Of(_products.Sum(t => t.Tax.Amount * t.Quantity), Currency.USDollar.Code);
        }
    }

    public Money Total
    {
        get
        {
            return Money.Of(
                _products.Sum(t => t.Tax.Amount * t.Quantity + t.Price.Amount * t.Quantity)
                    + ShippingCost.Amount
                    + ShippingTax.Amount,
                Currency.USDollar.Code
            );
        }
    }

    public void SetTrackingNumber(string trackingNumber)
    {
        TrackingNumber = trackingNumber;
    }

    public void Ship(DateTime shippedOn)
    {
        Status = OrderStatus.Shipped;
        ShippedAt = shippedOn;
        LastModified = DateTime.UtcNow;
    }

    // Shipping costs and method selected in shopping cart
    public StoreShippingMethodId ShippingMethodId { get; private set; }
    public Money ShippingCost { get; private set; }
    public Money ShippingTax { get; private set; }

    public readonly List<OrderProduct> _products = new List<OrderProduct>();
    public IReadOnlyCollection<OrderProduct> Products => _products.AsReadOnly();

    public void SetOrderId(OrderId orderId)
    {
        OrderId = orderId;
    }

    public void SetReferenceId(Guid referenceId)
    {
        ReferenceId = referenceId;
    }

    public void SetExternalOrderId(int externalOrderId)
    {
        ExternalOrderId = externalOrderId;
    }

    public void SetStatus(OrderStatus status)
    {
        Status = status;
    }

    public void AddCrystalCommerceOrderData(JsonDocument orderData)
    {
        CrystalCommerceOrderConfirmationDetails = orderData;
    }

    public static Result<StoreOrder> Create(
        string storeName,
        StoreId storeId,
        PackageId packageId,
        string storeEmail,
        List<OrderProduct> products,
        StoreShippingMethodId shippingMethodId,
        Money shippingCost,
        Money shippingTax,
        Guid referenceId
    )
    {
        if (string.IsNullOrWhiteSpace(storeName))
            return Result.Failure<StoreOrder>(Errors.StoreOrder.StoreNameNullOrWhiteSpace());

        if (string.IsNullOrWhiteSpace(storeEmail))
            return Result.Failure<StoreOrder>(Errors.StoreOrder.StoreEmaillNulLOrWhiteSpace());

        if (storeId == null || storeId.Value == Guid.Empty)
            return Result.Failure<StoreOrder>(Errors.StoreOrder.StoreIdNullOrEmpty(storeId?.Value));

        if (products == null || !products.Any())
            return Result.Failure<StoreOrder>(Errors.StoreOrder.StoreOrdersNullOrMissing());

        if (shippingMethodId == null || shippingMethodId.Value == Guid.Empty)
            return Result.Failure<StoreOrder>(
                Errors.StoreOrder.ShippingMethodIdNullOrEmpty(shippingMethodId?.Value)
            );

        if (shippingCost == null || shippingCost.Amount < 0)
            return Result.Failure<StoreOrder>(
                Errors.StoreOrder.ShippingCostCannotBeNullOrNegative(shippingCost)
            );

        return new StoreOrder(
            storeName,
            storeId,
            packageId,
            storeEmail,
            products,
            shippingMethodId,
            shippingCost,
            shippingTax,
            referenceId
        );
    }

    private StoreOrder(
        string storeName,
        StoreId storeId,
        PackageId packageId,
        string storeEmail,
        List<OrderProduct> products,
        StoreShippingMethodId shippingMethodId,
        Money shippingCost,
        Money shippingTax,
        Guid referenceId
    )
    {
        Id = new StoreOrderId(Guid.NewGuid());
        StoreName = storeName;
        StoreId = storeId;
        StoreEmail = storeEmail;
        _products = products;
        ShippingCost = shippingCost;
        ShippingTax = shippingTax;
        ShippingMethodId = shippingMethodId;
        ReferenceId = referenceId;
        PackageId = packageId;
    }

    private StoreOrder() { }
}
