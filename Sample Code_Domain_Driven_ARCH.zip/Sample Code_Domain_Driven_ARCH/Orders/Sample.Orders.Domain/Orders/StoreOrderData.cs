﻿using MediatR;
using Sample.Orders.Domain.Core;
using Sample.Orders.Domain.Customer;

namespace Sample.Orders.Domain.Orders;

public record StoreOrderData(
    StoreId StoreId,
    PackageId PackageId,
    string StoreName,
    string StoreEmail,
    List<OrderProductData> OrderProductData,
    StoreShippingMethodId StoreShippingMethodId,
    Money ShippingCost,
    Money ShippingTax,
    Guid ReferenceId,
    DateTime? MinimumShippingDate
) : IRequest<Result>;
