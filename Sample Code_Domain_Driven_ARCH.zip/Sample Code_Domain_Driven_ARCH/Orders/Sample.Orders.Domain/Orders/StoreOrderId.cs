﻿using Sample.Orders.Domain.Core;

namespace Sample.Orders.Domain.Orders;

public record StoreOrderId(Guid Value) : StronglyTypedId<Guid>(Value);
