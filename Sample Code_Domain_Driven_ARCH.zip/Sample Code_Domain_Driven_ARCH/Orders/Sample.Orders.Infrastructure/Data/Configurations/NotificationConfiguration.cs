﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sample.Orders.Domain.Notifications;

namespace Sample.Orders.Infrastructure.Data.Configurations
{
    public class NotificationConfiguration : IEntityTypeConfiguration<Notification>
    {
        public void Configure(EntityTypeBuilder<Notification> builder)
        {
            builder.HasKey(p => p.Id);

            builder.Property(p => p.Id).HasConversion(id => id.Value, value => new NotificationId(value));

            builder.Property(p => p.RecipientEmail).IsRequired().HasMaxLength(255);

            builder.Property(p => p.Subject).IsRequired().HasMaxLength(255);

            builder.Property(p => p.EmailPayload).IsRequired(false);
        }
    }
}
