﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sample.Orders.Domain;
using Sample.Orders.Domain.Core;
using Sample.Orders.Domain.Orders;

namespace Sample.Orders.Infrastructure.Data.Configurations;

public class OrderConfiguration : IEntityTypeConfiguration<Order>
{
    public void Configure(EntityTypeBuilder<Order> builder)
    {
        builder.HasKey(p => p.Id);

        builder.Property(p => p.Id).HasConversion(id => id.Value, value => new OrderId(value));

        builder.Property(p => p.AffiliateId).HasConversion(id => id.Value, value => new AffiliateId(value));

        builder.Property(p => p.CompletedAt).IsRequired(false);

        builder.Property(p => p.Status).HasConversion(p => p.Value, p => OrderStatus.FromValue(p));

        builder.OwnsOne(
            p => p.Customer,
            p =>
            {
                p.Property(x => x.CustomerId).HasConversion(x => x.Value, x => new CustomerId(x));

                p.Property(x => x.Email).IsRequired().HasMaxLength(128);

                p.Property(x => x.FirstName).IsRequired().HasMaxLength(128);

                p.Property(x => x.LastName).IsRequired().HasMaxLength(128);

                p.Property(x => x.PhoneNumber).IsRequired(false).HasMaxLength(128);
            }
        );

        builder.OwnsOne(
            p => p.PaymentMethod,
            p =>
            {
                p.Property(x => x.PaymentMethodId).HasConversion(x => x.Value, x => new OrderPaymentMethodId(x));

                p.Property(x => x.Mask).IsRequired().HasMaxLength(32);

                p.Property(x => x.Name).IsRequired().HasMaxLength(128);

                p.Property(x => x.Token).IsRequired().HasMaxLength(128);
            }
        );

        builder.HasMany(p => p.Refunds).WithOne().HasForeignKey(p => p.OrderId);

        builder.HasMany(p => p.StoreOrders).WithOne().HasForeignKey(p => p.OrderId);

        builder.OwnsOne(
            p => p.ShippingAddress,
            p =>
            {
                p.Property(p => p.Address1).HasColumnName("ShippingAddress1").IsRequired();

                p.Property(p => p.Address2).HasColumnName("ShippingAddress2").IsRequired(false);

                p.Property(p => p.City).HasColumnName("ShippingCity").IsRequired();

                p.Property(p => p.State).HasColumnName("ShippingState").IsRequired();

                p.Property(p => p.ZipCode).HasColumnName("ShippingZipCode").IsRequired();

                p.Property(p => p.Country).HasColumnName("ShippingCountry").IsRequired();
            }
        );

        builder.OwnsOne(
            p => p.BillingAddress,
            p =>
            {
                p.Property(p => p.Address1).HasColumnName("BillingAddress1").IsRequired();

                p.Property(p => p.Address2).HasColumnName("BillingAddress2").IsRequired(false);

                p.Property(p => p.City).HasColumnName("BillingCity").IsRequired();

                p.Property(p => p.State).HasColumnName("BillingState").IsRequired();

                p.Property(p => p.ZipCode).HasColumnName("BillingZipCode").IsRequired();

                p.Property(p => p.Country).HasColumnName("BillingCountry").IsRequired();
            }
        );
    }
}
