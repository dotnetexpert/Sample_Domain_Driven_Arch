﻿using System.Text.Json;
using MassTransit;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sample.Orders.Domain.Orders;

namespace Sample.Orders.Infrastructure.Data.Configurations;

public class OrderStateMap : SagaClassMap<OrderState>
{
    protected override void Configure(EntityTypeBuilder<OrderState> entity, ModelBuilder model)
    {
        entity.Property(x => x.CurrentState).HasMaxLength(64);

        entity.Property(x => x.Reason).IsRequired(false);

        entity
            .Property(x => x.OrderData)
            .HasConversion(
                v => JsonSerializer.Serialize(v, JsonSerializerOptions.Default),
                v => JsonSerializer.Deserialize<CrossCutting.Infrastructure.Models.OrderData>(v, JsonSerializerOptions.Default)
            );
    }
}
