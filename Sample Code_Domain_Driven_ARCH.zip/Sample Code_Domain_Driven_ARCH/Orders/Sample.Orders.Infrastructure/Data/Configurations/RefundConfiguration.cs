﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sample.Orders.Domain;
using Sample.Orders.Domain.Core;
using Sample.Orders.Domain.Orders;

namespace Sample.Orders.Infrastructure.Data.Configurations;

public class RefundConfiguration : IEntityTypeConfiguration<Refund>
{
    public void Configure(EntityTypeBuilder<Refund> builder)
    {
        builder.HasKey(p => p.Id);

        builder.Property(p => p.Id).HasConversion(id => id.Value, value => new RefundId(value));

        builder.Property(p => p.OrderId).HasConversion(id => id.Value, value => new OrderId(value));

        builder.Property(p => p.StoreId).HasConversion(id => id.Value, value => new StoreId(value));

        builder.Property(p => p.Status).HasConversion(p => p.Value, value => RefundStatus.FromValue(value));

        builder.Property(p => p.PaymentSystem).HasConversion(p => p.Value, value => PaymentSystem.FromValue(value));

        builder.OwnsMany(
            p => p.RefundDetails,
            p =>
            {
                p.ToTable("RefundDetails");
                p.Property(v => v.StoreProductId).HasConversion(v => v.Value, value => new StoreProductId(value));
            }
        );
        builder.OwnsOne(
            p => p.Tax,
            p =>
            {
                p.Property(p => p.Amount).HasColumnName("TaxAmount").HasPrecision(11, 2).IsRequired();

                p.Property(p => p.Currency).HasColumnName("TaxCurrencyCode").HasMaxLength(3).IsRequired();
            }
        );

        builder.OwnsOne(
            p => p.Amount,
            p =>
            {
                p.Property(p => p.Amount).HasColumnName("SubtotalAmount").HasPrecision(11, 2).IsRequired();

                p.Property(p => p.Currency).HasColumnName("SubtotalCurrencyCode").HasMaxLength(3).IsRequired();
            }
        );
    }
}
