﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sample.Orders.Domain.Core;
using Sample.Orders.Domain.Customer;
using Sample.Orders.Domain.Orders;

namespace Sample.Orders.Infrastructure.Data.Configurations;

public class StoreOrderConfiguration : IEntityTypeConfiguration<StoreOrder>
{
    public void Configure(EntityTypeBuilder<StoreOrder> builder)
    {
        builder.HasKey(p => p.Id);

        builder.Property(p => p.Id).HasConversion(id => id.Value, value => new StoreOrderId(value));

        builder.Property(p => p.ShippingMethodId).HasConversion(id => id.Value, value => new StoreShippingMethodId(value));

        builder.Property(p => p.StoreId).HasConversion(id => id.Value, value => new StoreId(value));

        builder.Property(p => p.PackageId).HasConversion(id => id.Value, value => new PackageId(value));

        builder.Property(p => p.StoreName).IsRequired().HasMaxLength(128);

        builder.Property(p => p.StoreEmail).IsRequired().HasMaxLength(128);

        builder.Property(p => p.Status).HasConversion(p => p.Value, p => OrderStatus.FromValue(p));

        builder.Property(p => p.CrystalCommerceOrderConfirmationDetails).IsRequired(false);

        builder.OwnsOne(
            p => p.ShippingCost,
            p =>
            {
                p.Property(p => p.Amount).HasColumnName("ShippingCostAmount").HasPrecision(11, 2).IsRequired();

                p.Property(p => p.Currency).HasColumnName("ShippingCostCurrencyCode").HasMaxLength(3).IsRequired();
            }
        );

        builder.OwnsOne(
            p => p.ShippingTax,
            p =>
            {
                p.Property(p => p.Amount).HasColumnName("ShippingTaxAmount").HasPrecision(11, 2);

                p.Property(p => p.Currency).HasColumnName("ShippingTaxCurrencyCode").HasMaxLength(3);
            }
        );

        builder.OwnsMany(
            p => p.Products,
            p =>
            {
                p.Property(p => p.StoreProductId).HasConversion(id => id.Value, value => new StoreProductId(value));

                p.Property(p => p.ProductCatalogId)
                    .HasConversion(id => id.Value, value => new Domain.Core.ProductCatalogId(value));

                p.Property(p => p.ProductName).IsRequired().HasMaxLength(128);

                p.Property(p => p.PackageType).HasConversion(p => p.Value, p => PackageType.FromValue(p));

                p.OwnsOne(
                    p => p.Price,
                    p =>
                    {
                        p.Property(p => p.Amount).HasColumnName("Price").HasPrecision(11, 2).IsRequired();

                        p.Property(p => p.Currency).HasColumnName("PriceCurrencyCode").HasMaxLength(3).IsRequired();
                    }
                );

                p.OwnsOne(
                    p => p.Tax,
                    p =>
                    {
                        p.Property(p => p.Amount).HasColumnName("TaxAmount").HasPrecision(11, 2).IsRequired();

                        p.Property(p => p.Currency).HasColumnName("TaxCurrencyCode").HasMaxLength(3).IsRequired();
                    }
                );
            }
        );
    }
}
