﻿using System.Reflection;
using MassTransit.EntityFrameworkCoreIntegration;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Sample.Orders.Domain.Notifications;
using Sample.Orders.Domain.Orders;
using Sample.Orders.Infrastructure.Data.Configurations;

namespace Sample.Orders.Infrastructure.Data;

public class OrderContext : SagaDbContext
{
    private readonly IConfiguration _configuration;
#pragma warning disable CS8618 // Required by Entity Framework
    public OrderContext(DbContextOptions<OrderContext> options)
        : base(options) { }

    public OrderContext(DbContextOptions<OrderContext> options, IConfiguration configuration)
        : base(options)
    {
        _configuration = configuration;
    }

    public DbSet<Order> Orders { get; set; }
    public DbSet<Notification> Notifications { get; set; }

    protected override IEnumerable<ISagaClassMap> Configurations
    {
        get { yield return new OrderStateMap(); }
    }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        builder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseNpgsql(_configuration.GetConnectionString("OrdersConnectionString"));
    }
}
