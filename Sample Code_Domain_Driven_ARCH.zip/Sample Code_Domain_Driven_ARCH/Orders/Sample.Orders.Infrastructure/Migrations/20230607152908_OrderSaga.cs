﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Sample.Orders.Infrastructure.Migrations;

/// <inheritdoc />
public partial class OrderSaga : Migration
{
    /// <inheritdoc />
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "Orders",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                Customer_Name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                Customer_Email = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                Customer_CustomerId = table.Column<Guid>(type: "uuid", nullable: false),
                PaymentMethod_PaymentMethodId = table.Column<Guid>(type: "uuid", nullable: false),
                PaymentMethod_Mask = table.Column<string>(type: "character varying(32)", maxLength: 32, nullable: false),
                PaymentMethod_Name = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                PaymentMethod_Token = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                BillingAddress1 = table.Column<string>(type: "text", nullable: false),
                BillingAddress2 = table.Column<string>(type: "text", nullable: true),
                BillingCity = table.Column<string>(type: "text", nullable: false),
                BillingState = table.Column<string>(type: "text", nullable: false),
                BillingZipCode = table.Column<string>(type: "text", nullable: false),
                BillingCountry = table.Column<string>(type: "text", nullable: false),
                ShippingAddress1 = table.Column<string>(type: "text", nullable: false),
                ShippingAddress2 = table.Column<string>(type: "text", nullable: true),
                ShippingCity = table.Column<string>(type: "text", nullable: false),
                ShippingState = table.Column<string>(type: "text", nullable: false),
                ShippingZipCode = table.Column<string>(type: "text", nullable: false),
                ShippingCountry = table.Column<string>(type: "text", nullable: false),
                Status = table.Column<int>(type: "integer", nullable: false),
                CreatedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                CompletedAt = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                Date = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Orders", x => x.Id);
            }
        );

        migrationBuilder.CreateTable(
            name: "OrderState",
            columns: table => new
            {
                CorrelationId = table.Column<Guid>(type: "uuid", nullable: false),
                CurrentState = table.Column<int>(type: "integer", maxLength: 64, nullable: false),
                OrderData = table.Column<string>(type: "text", nullable: false),
                ScheduleRetryToken = table.Column<Guid>(type: "uuid", nullable: true),
                RetryAttempt = table.Column<int>(type: "integer", nullable: false),
                Reason = table.Column<string>(type: "text", nullable: false),
                RowVersion = table.Column<byte[]>(type: "bytea", rowVersion: true, nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_OrderState", x => x.CorrelationId);
            }
        );

        migrationBuilder.CreateTable(
            name: "Refund",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                OrderId = table.Column<Guid>(type: "uuid", nullable: false),
                SubtotalAmount = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: false),
                SubtotalCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                ShippingAmount = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: false),
                ShippingCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                TaxAmount = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: false),
                TaxCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                Date = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Refund", x => x.Id);
                table.ForeignKey(
                    name: "FK_Refund_Orders_OrderId",
                    column: x => x.OrderId,
                    principalTable: "Orders",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Cascade
                );
            }
        );

        migrationBuilder.CreateTable(
            name: "StoreOrder",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                StoreName = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                StoreEmail = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                StoreId = table.Column<Guid>(type: "uuid", nullable: false),
                OrderId = table.Column<Guid>(type: "uuid", nullable: false),
                ShippingMethodId = table.Column<Guid>(type: "uuid", nullable: false),
                ShippingCostAmount = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: false),
                ShippingCostCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_StoreOrder", x => x.Id);
                table.ForeignKey(
                    name: "FK_StoreOrder_Orders_OrderId",
                    column: x => x.OrderId,
                    principalTable: "Orders",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Cascade
                );
            }
        );

        migrationBuilder.CreateTable(
            name: "OrderProduct",
            columns: table => new
            {
                StoreOrderId = table.Column<Guid>(type: "uuid", nullable: false),
                Id = table
                    .Column<int>(type: "integer", nullable: false)
                    .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                StoreProductId = table.Column<Guid>(type: "uuid", nullable: false),
                ProductCatalogId = table.Column<Guid>(type: "uuid", nullable: false),
                ProductName = table.Column<string>(type: "character varying(128)", maxLength: 128, nullable: false),
                Price = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: false),
                PriceCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                TaxAmount = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: false),
                TaxCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                Quantity = table.Column<int>(type: "integer", nullable: false),
                ReturnedQuantity = table.Column<int>(type: "integer", nullable: false),
                PackageType = table.Column<int>(type: "integer", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_OrderProduct", x => new { x.StoreOrderId, x.Id });
                table.ForeignKey(
                    name: "FK_OrderProduct_StoreOrder_StoreOrderId",
                    column: x => x.StoreOrderId,
                    principalTable: "StoreOrder",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Cascade
                );
            }
        );

        migrationBuilder.CreateIndex(name: "IX_Refund_OrderId", table: "Refund", column: "OrderId");

        migrationBuilder.CreateIndex(name: "IX_StoreOrder_OrderId", table: "StoreOrder", column: "OrderId");
    }

    /// <inheritdoc />
    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(name: "OrderProduct");

        migrationBuilder.DropTable(name: "OrderState");

        migrationBuilder.DropTable(name: "Refund");

        migrationBuilder.DropTable(name: "StoreOrder");

        migrationBuilder.DropTable(name: "Orders");
    }
}
