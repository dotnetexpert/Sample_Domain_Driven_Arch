﻿using Microsoft.EntityFrameworkCore;
using Sample.Orders.Domain;
using Sample.Orders.Domain.Core;
using Sample.Orders.Domain.Notifications;
using Sample.Orders.Domain.Orders;
using Sample.Orders.Infrastructure.Data;

namespace Sample.Orders.Infrastructure.Repositories;

public sealed class OrderRepository : IOrderRepository
{
    private readonly OrderContext _context;

    public OrderRepository(OrderContext context)
    {
        _context = context;
    }

    public void Add(Order order)
    {
        _context.Orders.Add(order);
    }
}
