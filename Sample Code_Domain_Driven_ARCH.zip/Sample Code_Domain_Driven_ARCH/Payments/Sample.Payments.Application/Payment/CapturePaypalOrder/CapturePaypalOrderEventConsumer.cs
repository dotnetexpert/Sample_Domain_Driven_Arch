﻿using MassTransit;
using Microsoft.Extensions.Logging;
using Sample.CrossCutting.Infrastructure.Events.Orders.Orders;
using Sample.CrossCutting.Infrastructure.Events.Payments;
using Sample.Payments.Domain;
using Sample.Payments.Domain.Core;
using Sample.Payments.Infrastructure.Paypal;
using BillingAddress = Sample.Payments.Domain.BillingAddress;
using Money = Sample.Payments.Domain.Core.Money;

namespace Sample.Payments.Application.Payment.CapturePaypalOrder;

public class CapturePaypalOrderEventConsumer : IConsumer<CapturePaypalOrderEvent>
{
    private readonly ILogger<CapturePaypalOrderEventConsumer> _logger;
    private readonly IPaypalService _paypalService;
    private readonly IPayorRepository _payorRepository;
    private readonly IMerchantRepository _merchantRepository;

    public CapturePaypalOrderEventConsumer(
        ILogger<CapturePaypalOrderEventConsumer> logger,
        IPaypalService paypalService,
        IPayorRepository payorRepository,
        IMerchantRepository merchantRepository
    )
    {
        _logger = logger;
        _paypalService = paypalService;
        _payorRepository = payorRepository;
        _merchantRepository = merchantRepository;
    }

    public async Task Consume(ConsumeContext<CapturePaypalOrderEvent> context)
    {
        try
        {
            var customerId = new CustomerId(context.Message.CustomerId);
            var payer = await _payorRepository.GetPayorDetailsByCustomerIdAsync(customerId);

            if (payer == null)
            {
                _payorRepository.Register(Payor.Create(customerId).Value);
                await _payorRepository.SaveChangesAsync();

                payer = await _payorRepository.GetPayorDetailsByCustomerIdAsync(customerId);
            }

            var capturedOrder = await _paypalService.CapturePaymentAsync(context.Message.PaymentSystemOrderId);

            if (capturedOrder == null)
            {
                _logger.LogError($"Failed to capture payment for OrderId: {context.Message.PaymentSystemOrderId}");
                throw new Exception(capturedOrder.ErrorDescription);
            }

            var paymentMethod = payer.PaymentMethods.FirstOrDefault(p =>
                p.PayorAccountId == capturedOrder.PaymentSource.Paypal.AccountId
            );

            if (paymentMethod is null)
            {
                payer.AddPaymentMethod(
                    new Domain.Core.PaymentMethodData(
                        payer.Id,
                        PaymentSystem.PayPal,
                        BillingAddress
                            .Create(
                                capturedOrder.Payer.Name.GivenName,
                                capturedOrder.Payer.Name.Surname,
                                context.Message.BillingAddress.Address1,
                                context.Message.BillingAddress.Address2,
                                context.Message.BillingAddress.City,
                                context.Message.BillingAddress.State,
                                context.Message.BillingAddress.Country,
                                context.Message.BillingAddress.ZipCode
                            )
                            .Value,
                        null,
                        $"{capturedOrder.PaymentSource.Paypal.Name.GivenName} {capturedOrder.PaymentSource.Paypal.Name.Surname}",
                        capturedOrder.Payer.EmailAddress,
                        capturedOrder.PaymentSource.Paypal.AccountId
                    )
                );

                paymentMethod = payer.PaymentMethods.First();
            }

            foreach (var purchaseUnit in capturedOrder.PurchaseUnits)
            {
                var packageReferenceId = purchaseUnit.ReferenceId;

                var package = await _merchantRepository.GetByReferenceIdAsync(new(Guid.Parse(packageReferenceId)));

                if (package == null)
                {
                    _logger.LogWarning($"Package not found for ReferenceId: {packageReferenceId}");
                }

                payer.AddTransaction(
                    new TransactionItemData(
                        payer.Id,
                        paymentMethod.Id,
                        new MerchantAccountId(package.Id.Value),
                        Money.Of(
                            Convert.ToDecimal(purchaseUnit.Payments.Captures.First().SellerReceivableBreakdown.GrossAmount.Value),
                            purchaseUnit.Payments.Captures.First().SellerReceivableBreakdown.GrossAmount.CurrencyCode
                        ),
                        Money.Of(0, Currency.USDollar.Code), // Discount
                        Money.Of(
                            Convert.ToDecimal(purchaseUnit.Payments.Captures.First().SellerReceivableBreakdown.NetAmount.Value),
                            purchaseUnit.Payments.Captures.First().SellerReceivableBreakdown.NetAmount.CurrencyCode
                        ),
                        Money.Of(
                            Convert.ToDecimal(purchaseUnit.Payments.Captures.First().SellerReceivableBreakdown.GrossAmount.Value),
                            purchaseUnit.Payments.Captures.First().SellerReceivableBreakdown.GrossAmount.CurrencyCode
                        ),
                        Money.Of(0, Currency.USDollar.Code), // Tax
                        Money.Of(
                            Convert.ToDecimal(purchaseUnit.Payments.Captures.First().Amount.Value),
                            purchaseUnit.Payments.Captures.First().Amount.CurrencyCode
                        ),
                        Money.Of(
                            Convert.ToDecimal(
                                purchaseUnit.Payments.Captures.First()?.SellerReceivableBreakdown.PaypalFee?.Value ?? "0"
                            ),
                            purchaseUnit.Payments.Captures.First()?.SellerReceivableBreakdown.PaypalFee?.CurrencyCode
                                ?? Currency.USDollar.Code
                        ),
                        purchaseUnit.Payments.Captures.First().ExternalPaymentSystemTransactionId,
                        null,
                        capturedOrder.Status,
                        null,
                        new ReferenceId(Guid.Parse(purchaseUnit.ReferenceId)),
                        capturedOrder.Id,
                        purchaseUnit.Payments.Captures.First().FinalCapture,
                        new GiftCardId(Guid.Empty),
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        null,
                        PaymentSystem.PayPal,
                        Money.Of(0, Currency.USDollar.Code), //StoreCreditUsed
                        Money.Of(0, Currency.USDollar.Code), //SampleFee
                        capturedOrder.PaymentDebugId
                    )
                );
            }

            await _payorRepository.SaveChangesAsync();

            await context.RespondAsync(new PaymentCaptureResultEvent { Status = "CapturePaymentSuccessfully" });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An error occurred while processing CapturePaypalOrderEvent: {Message}", ex.Message);
            await context.RespondAsync(new PaymentCaptureResultEvent { Status = ex.Message });
            throw;
        }
    }
}
