﻿using MediatR;
using Sample.Payments.Domain;
using Sample.Payments.Domain.Core;

namespace Sample.Payments.Application.PaymentToken;

public record CreatePaymentTokenCommand(PaymentTokenRequest PaymentTokenRequest) : IRequest<Result>;
