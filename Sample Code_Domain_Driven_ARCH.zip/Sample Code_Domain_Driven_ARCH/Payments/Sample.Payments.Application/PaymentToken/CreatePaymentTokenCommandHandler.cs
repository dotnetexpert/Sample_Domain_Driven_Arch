﻿using MediatR;
using Microsoft.Extensions.Options;
using Sample.CrossCutting.Infrastructure.Models;
using Sample.Payments.Domain;
using Sample.Payments.Domain.Core;
using Sample.Payments.Infrastructure.GiftCards;
using Sample.Payments.Infrastructure.Paypal;
using Customer = Sample.Payments.Domain.Customer;

namespace Sample.Payments.Application.PaymentToken;

public class CreatePaymentTokenCommandHandler : IRequestHandler<CreatePaymentTokenCommand, Result>
{
    private readonly PaypalConfiguration _configuration;
    private readonly IPaypalService _paypalService;
    private readonly IPayorRepository _payorRepository;

    public CreatePaymentTokenCommandHandler(
        IOptions<PaypalConfiguration> configuration,
        IPaypalService paypalService,
        IPayorRepository payorRepository
    )
    {
        _configuration = configuration.Value;
        _paypalService = paypalService;
        _payorRepository = payorRepository;
    }

    public async Task<Result> Handle(CreatePaymentTokenCommand request, CancellationToken cancellationToken)
    {
        var vaultSetupRequest = new VaultSetupRequest
        {
            Customer = new Customer { MerchantCustomerId = _configuration.MerchantCustomerId, Id = _configuration.Id },
            PaymentSource = new PaymentSource
            {
                Card = new CardPayment
                {
                    LastDigits = request.PaymentTokenRequest.LastDigits,
                    Expiry = request.PaymentTokenRequest.Expiry,
                    Name = request.PaymentTokenRequest.Name,
                    BillingAddress = new VaultBillingAddress // this should be Heavily Played's Billing Address
                    {
                        Address1 = request.PaymentTokenRequest.BillingAddress1,
                        Address2 = request.PaymentTokenRequest.BillingAddress2,
                        City = request.PaymentTokenRequest.BillingCity,
                        State = request.PaymentTokenRequest.BillingState,
                        PostalCode = request.PaymentTokenRequest.BillingPostalCode,
                        CountryCode = request.PaymentTokenRequest.BillingCountryCode,
                    },
                    VerificationMethod = VerificationMethod.ScsWhenRequired.Name,
                    ExperienceContext = new ExperienceContext
                    {
                        BrandName = _configuration.BrandName,
                        ReturnUrl = _configuration.ReturnUrl,
                        CancelUrl = _configuration.CancelUrl,
                    },
                },
            },
        };

        var vaultToken = await _paypalService.VaultSetupToken(vaultSetupRequest);

        var paymentToken = await _payorRepository.GetTokenByEmailAsync(_configuration.MerchantCustomerId);

        if (paymentToken != null)
        {
            paymentToken.UpdatePaymentToken(vaultToken);
        }
        else
        {
            var newPaymentToken = Domain.PaymentToken.Create(_configuration.MerchantCustomerId, vaultToken).Value;

            _payorRepository.AddPaymentToken(newPaymentToken);
        }

        await _payorRepository.SaveChangesAsync();

        return Result.Success(vaultToken);
    }
}
