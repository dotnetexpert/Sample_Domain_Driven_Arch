﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Domain;

public class BillingAddress : ValueObject<BillingAddress>
{
    public string FirstName { get; private set; }
    public string LastName { get; private set; }
    public string Address1 { get; private set; }
    public string Address2 { get; private set; }
    public string City { get; private set; }
    public string State { get; private set; }
    public string Country { get; private set; }
    public string ZipCode { get; private set; }

    public static Result<BillingAddress> Create(
        string firstName,
        string lastName,
        string address1,
        string address2,
        string city,
        string state,
        string country,
        string zipCode
    )
    {
        if (
            string.IsNullOrEmpty(firstName)
            || string.IsNullOrEmpty(lastName)
            || string.IsNullOrEmpty(address1)
            || string.IsNullOrEmpty(city)
            || string.IsNullOrEmpty(state)
            || string.IsNullOrEmpty(country)
            || string.IsNullOrEmpty(zipCode)
        )
            return Result.Failure<BillingAddress>(Errors.General.Null());

        return new BillingAddress(firstName, lastName, address1, address2, city, state, country, zipCode);
    }

    private BillingAddress(
        string firstName,
        string lastName,
        string address1,
        string address2,
        string city,
        string state,
        string country,
        string zipCode
    )
    {
        FirstName = firstName;
        LastName = lastName;
        Address1 = address1;
        Address2 = address2;
        City = city;
        State = state;
        Country = country;
        ZipCode = zipCode;
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Address1;
        yield return Address2;
        yield return City;
        yield return State;
        yield return Country;
        yield return ZipCode;
        yield return FirstName;
        yield return LastName;
    }
}
