﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Domain;

public class CardInformation : ValueObject<CardInformation>
{
    public string CardType { get; private set; }
    public string LastFour { get; private set; }
    public int ExpirationMonth { get; private set; }
    public int ExpirationYear { get; private set; }

    public static Result<CardInformation> Create(string cardType, string lastFour, int expirationMonth, int expirationYear)
    {
        if (string.IsNullOrEmpty(cardType) || string.IsNullOrEmpty(lastFour))
            return Result.Failure<CardInformation>(Errors.General.Null());

        return new CardInformation(cardType, lastFour, expirationMonth, expirationYear);
    }

    private CardInformation(string cardType, string lastFour, int expirationMonth, int expirationYear)
    {
        LastFour = lastFour;
        CardType = cardType;
        ExpirationMonth = expirationMonth;
        ExpirationYear = expirationYear;
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return LastFour;
        yield return CardType;
        yield return ExpirationMonth;
        yield return ExpirationYear;
    }
}
