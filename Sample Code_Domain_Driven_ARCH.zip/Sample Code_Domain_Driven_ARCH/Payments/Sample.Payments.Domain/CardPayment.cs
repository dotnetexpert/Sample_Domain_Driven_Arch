﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Domain;

public class CardPayment
{
    [JsonPropertyName("number")]
    public string Number { get; set; }

    [JsonPropertyName("expiry")]
    public string Expiry { get; set; }

    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("last_digits")]
    public string? LastDigits { get; set; }

    [JsonPropertyName("brand")]
    public string? Brand { get; set; }

    [JsonPropertyName("billing_address")]
    public VaultBillingAddress BillingAddress { get; set; }

    [JsonPropertyName("verification_method")]
    public string? VerificationMethod { get; set; }

    [JsonPropertyName("verification_status")]
    public VerificationStatus? VerificationStatus { get; set; }

    [JsonPropertyName("experience_context")]
    public ExperienceContext ExperienceContext { get; set; }
}
