﻿namespace Sample.Payments.Domain.Core;

public class Address : ValueObject<Address>
{
    public string Address1 { get; private set; }
    public string Address2 { get; private set; }
    public string City { get; private set; }
    public string State { get; private set; }
    public string ZipCode { get; private set; }
    public string Country { get; private set; }

    public static Address Create(string address1, string address2, string city, string state, string zipCode, string country)
    {
        if (string.IsNullOrWhiteSpace(address1))
            throw new Exception("Address cannot be null or whitespace.");

        if (string.IsNullOrWhiteSpace(city))
            throw new Exception("City cannot be null or whitespace.");

        if (string.IsNullOrWhiteSpace(state))
            throw new Exception("State cannot be null or whitespace.");

        if (string.IsNullOrWhiteSpace(zipCode))
            throw new Exception("Zip Code cannot be null or whitespace.");

        if (string.IsNullOrWhiteSpace(country))
            throw new Exception("Country cannot be null or whitespace.");

        return new Address(address1, address2, city, state, zipCode, country);
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Address1;
        yield return Address2;
        yield return City;
        yield return State;
        yield return ZipCode;
        yield return Country;
    }

    private Address(string address1, string address2, string city, string state, string zipCode, string country)
    {
        Address1 = address1;
        Address2 = address2;
        City = city;
        State = state;
        ZipCode = zipCode;
        Country = country;
    }
}
