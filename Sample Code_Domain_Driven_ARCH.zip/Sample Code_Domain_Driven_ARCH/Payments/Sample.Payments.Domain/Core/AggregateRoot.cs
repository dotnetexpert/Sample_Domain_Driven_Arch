﻿namespace Sample.Payments.Domain.Core;

public abstract class AggregateRoot<TKey> : IAggregateRoot<TKey>
    where TKey : StronglyTypedId<Guid>
{
    public TKey Id { get; set; } = default!;
}
