﻿namespace Sample.Payments.Domain.Core;

public class CanadianTaxRate
{
    public string Province { get; set; }
    public decimal PST { get; set; }
    public decimal GST { get; set; }
    public decimal HST { get; set; }
}

public static class CanadianTaxRates
{
    public static readonly Dictionary<string, CanadianTaxRate> TaxRates =
        new()
        {
            {
                "AB",
                new CanadianTaxRate
                {
                    Province = "AB",
                    PST = 0.0m,
                    GST = 0.05m,
                    HST = 0.0m,
                }
            },
            {
                "BC",
                new CanadianTaxRate
                {
                    Province = "BC",
                    PST = 0.07m,
                    GST = 0.05m,
                    HST = 0.0m,
                }
            },
            {
                "MB",
                new CanadianTaxRate
                {
                    Province = "MB",
                    PST = 0.07m,
                    GST = 0.05m,
                    HST = 0.0m,
                }
            },
            {
                "NB",
                new CanadianTaxRate
                {
                    Province = "NB",
                    PST = 0.0m,
                    GST = 0.0m,
                    HST = 0.15m,
                }
            },
            {
                "NL",
                new CanadianTaxRate
                {
                    Province = "NL",
                    PST = 0.0m,
                    GST = 0.0m,
                    HST = 0.15m,
                }
            },
            {
                "NS",
                new CanadianTaxRate
                {
                    Province = "NS",
                    PST = 0.0m,
                    GST = 0.0m,
                    HST = 0.15m,
                }
            },
            {
                "NT",
                new CanadianTaxRate
                {
                    Province = "NT",
                    PST = 0.0m,
                    GST = 0.05m,
                    HST = 0.0m,
                }
            },
            {
                "NU",
                new CanadianTaxRate
                {
                    Province = "NU",
                    PST = 0.0m,
                    GST = 0.05m,
                    HST = 0.0m,
                }
            },
            {
                "ON",
                new CanadianTaxRate
                {
                    Province = "ON",
                    PST = 0.0m,
                    GST = 0.0m,
                    HST = 0.13m,
                }
            },
            {
                "PE",
                new CanadianTaxRate
                {
                    Province = "PE",
                    PST = 0.0m,
                    GST = 0.0m,
                    HST = 0.15m,
                }
            },
            {
                "QC",
                new CanadianTaxRate
                {
                    Province = "QC",
                    PST = 0.09975m,
                    GST = 0.05m,
                    HST = 0.0m,
                }
            },
            {
                "SK",
                new CanadianTaxRate
                {
                    Province = "SK",
                    PST = 0.06m,
                    GST = 0.05m,
                    HST = 0.0m,
                }
            },
            {
                "YT",
                new CanadianTaxRate
                {
                    Province = "YT",
                    PST = 0.0m,
                    GST = 0.05m,
                    HST = 0.0m,
                }
            },
        };

    public static decimal GetTaxRateByState(string state)
    {
        if (!TaxRates.TryGetValue(state, out var taxRate) || taxRate == null)
        {
            throw new Exception($"No tax rates found for state: {state}");
        }

        return taxRate.HST > 0 ? taxRate.HST : taxRate.GST + taxRate.PST;
    }
}
