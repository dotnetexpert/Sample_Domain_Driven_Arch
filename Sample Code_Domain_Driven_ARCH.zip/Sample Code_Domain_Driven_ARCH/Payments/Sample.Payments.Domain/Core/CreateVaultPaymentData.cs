﻿namespace Sample.Payments.Domain.Core;

public record CreateVaultPaymentData(string PaymentTokenId, Customer Customer, PaymentSource PaymentSource, List<Links> Links);
