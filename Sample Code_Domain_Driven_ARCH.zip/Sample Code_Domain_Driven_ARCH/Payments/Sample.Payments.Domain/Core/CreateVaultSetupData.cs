﻿namespace Sample.Payments.Domain.Core;

public record CreateVaultSetupData(
    string SetupTokenId,
    Customer Customer,
    string Status,
    PaymentSource PaymentSource,
    List<Links> Links
);
