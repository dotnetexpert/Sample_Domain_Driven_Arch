﻿namespace Sample.Payments.Domain.Core;

public record CustomerId(Guid Value) : StronglyTypedId<Guid>(Value);
