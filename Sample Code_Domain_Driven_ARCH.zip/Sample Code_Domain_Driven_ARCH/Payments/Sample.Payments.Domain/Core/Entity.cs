﻿namespace Sample.Payments.Domain.Core;

public abstract class Entity<T> : IEquatable<Entity<T>>
    where T : StronglyTypedId<Guid>
{
    public T Id { get; protected set; }

    public static bool operator ==(Entity<T>? first, Entity<T>? second)
    {
        return first is not null && second is not null && first.Equals(second) || first is null && second is null;
    }

    public static bool operator !=(Entity<T>? first, Entity<T>? second)
    {
        return !(first == second);
    }

    public override bool Equals(object? obj)
    {
        if (obj is null)
        {
            return false;
        }

        if (obj.GetType() != GetType())
        {
            return false;
        }

        if (obj is not Entity<T> entity)
        {
            return false;
        }

        return entity.Id == Id;
    }

    public override int GetHashCode()
    {
        return Id.GetHashCode() * 41;
    }

    bool IEquatable<Entity<T>>.Equals(Entity<T>? other)
    {
        if (other is null)
        {
            return false;
        }

        if (other.GetType() != GetType())
        {
            return false;
        }

        return other.Id == Id;
    }
}
