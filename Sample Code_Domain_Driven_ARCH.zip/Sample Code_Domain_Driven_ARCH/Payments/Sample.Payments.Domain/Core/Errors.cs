﻿namespace Sample.Payments.Domain.Core;

public static class Errors
{
    public static class General
    {
        public static Error MoneyAmountMustBeGreaterThanZero(decimal amount) =>
            new("Money.Amount", $"'{amount}' must be greater than zero");

        public static Error QuantityGreaterThanZero(int quantity) =>
            new("Quantity.Positive", $"'{quantity}' must be greater than zero");

        public static Error NullOrWhiteSpaceString(string propertyName) =>
            new("String.NullOrWhiteSpace", $"'{propertyName}' cannot be null or white space");

        public static Error DateTimeMin() => new("DateTime.MinValue", $"DateTime cannot equal DateTime.MinValue.");

        public static Error EmptyGuid() => new("Guid.Empty", $"Guid value cannot equal Guid.Empty().");

        public static Error Null() => new("Null", $"Object is null.");

        public static Error NotFound(Guid id = new Guid()) => new("Id.NotFound", $"Id {id} not found.");

        public static Error ObjectAlreadyExists() => new("Id.AlreadyExists", $"Cannot create object, it already exists.");
    }

    public static class Paypal
    {
        public static Error FailedToCreateOrder() =>
            new("Order.CreateFailed", "Failed to create the order. The created order is null.");
    }

    public static class Email
    {
        public static Error EmailSendingFailed(string errorMessage) =>
            new Error("Email.SendingFailed", $"Email sending failed. Error: {errorMessage}");
    }

    public static class Payor
    {
        public static Error FailedToCreatePayor() =>
            new("Payor.CreateFailed", "Failed to create the payor. The created payor is null.");
    }

    public static class CrystalCommerce
    {
        public static Error FailedToCreateCrystalCommerceOrder() =>
            new(
                "Order.CrystalCommerceCreateFailed",
                "Failed to create the crystalCommerce order. The created order is not successful."
            );
    }

    public static class User
    {
        public static Error UserNotFound(Guid userId) => new Error("Order.UserNotFound", $"User with ID {userId} not found.");
    }

    public static class Tax
    {
        public static Error NotFound() =>
            new Error("Tax.NotFound", $"Failed to retrieve tax information for the provided address.");

        public static Error ProvinceNotFound(string provinceName) =>
            new Error("Tax.ProvinceNotFound", $"Failed to retrieve tax information for the province: {provinceName}.");
    }

    public static class GiftCard
    {
        public static Error NotFound(string giftCardCode) =>
            new Error("GiftCard.Redeem", $"The gift card with code '{giftCardCode}' was not found.");

        public static Error AlreadyRedeemed(string giftCardCode) =>
            new Error("GiftCard.Redeem", $"The gift card with code '{giftCardCode}' has already been redeemed.");
    }

    public static class Customer
    {
        public static Error NotFound(Guid id) => new Error("Customer.CustomerId", $"Customer with customerId:{id} not found .");
    }
}
