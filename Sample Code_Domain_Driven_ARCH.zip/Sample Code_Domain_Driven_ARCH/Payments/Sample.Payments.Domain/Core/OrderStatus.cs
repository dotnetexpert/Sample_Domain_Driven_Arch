﻿namespace Sample.Payments.Domain.Core;

public class OrderStatus : Enumeration<OrderStatus>
{
    public static readonly OrderStatus Pending = new OrderStatus(1, "Pending");
    public static readonly OrderStatus Complete = new OrderStatus(2, "Complete");
    public static readonly OrderStatus Failed = new OrderStatus(3, "Failed");

    private OrderStatus(int value, string name)
        : base(value, name) { }
}
