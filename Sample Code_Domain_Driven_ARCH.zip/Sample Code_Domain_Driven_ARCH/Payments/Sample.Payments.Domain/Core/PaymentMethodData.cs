﻿namespace Sample.Payments.Domain.Core;

public record PaymentMethodData(
    PayorId PayorId,
    PaymentSystem PaymentSystem,
    BillingAddress? BillingAddress,
    CardInformation CardInformation,
    string PayorName,
    string PayorEmailAddress,
    string PayorAccountId
);
