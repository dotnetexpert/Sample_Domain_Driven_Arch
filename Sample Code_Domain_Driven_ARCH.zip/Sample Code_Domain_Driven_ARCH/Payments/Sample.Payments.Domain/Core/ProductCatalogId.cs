﻿namespace Sample.Payments.Domain.Core;

public record ProductCatalogId(Guid Value) : StronglyTypedId<Guid>(Value);
