﻿namespace Sample.Payments.Domain.Core;

public enum WebhookEventType
{
    MerchantOnboardingCompleted,
    MerchantPartnerConsentRevoked,
    Unknown,
}
