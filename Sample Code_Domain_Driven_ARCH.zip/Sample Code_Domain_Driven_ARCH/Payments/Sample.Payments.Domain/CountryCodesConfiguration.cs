﻿namespace Sample.Payments.Domain;

public class CountryCodesConfiguration
{
    public string Canada { get; set; }
    public string UnitedStates { get; set; }
}
