﻿namespace Sample.Payments.Domain;

public record CreateOrderResponse(string OrderId, string MerchantIds);
