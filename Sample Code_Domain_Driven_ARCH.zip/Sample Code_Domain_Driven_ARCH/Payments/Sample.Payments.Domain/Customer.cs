﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Domain;

public class Customer
{
    [JsonPropertyName("id")]
    public string? Id { get; set; }

    [JsonPropertyName("merchant_customer_id")]
    public string MerchantCustomerId { get; set; }
}
