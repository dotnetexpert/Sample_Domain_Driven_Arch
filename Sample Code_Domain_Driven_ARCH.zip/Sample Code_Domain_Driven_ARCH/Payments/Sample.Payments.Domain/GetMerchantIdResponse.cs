﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Domain;

public class GetMerchantIdResponse
{
    [JsonPropertyName("merchantIds")]
    public string MerchantIds { get; set; }
}
