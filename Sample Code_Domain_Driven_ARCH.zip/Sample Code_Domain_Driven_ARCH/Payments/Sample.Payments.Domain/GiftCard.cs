﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Domain;

public class GiftCard : Entity<GiftCardId>
{
    public CustomerId CustomerId { get; private set; }
    public RedeemerId? RedeemerId { get; private set; }
    public string Code { get; private set; }
    public Money Amount { get; private set; }
    public bool IsRedeemed { get; private set; }
    public DateTime PurchasedDate { get; private set; }
    public DateTime? RedeemedDate { get; private set; }

    public static Result<GiftCard> Create(CustomerId customerId, Money amount, string code)
    {
        if (customerId.Value == Guid.Empty)
            return Result.Failure<GiftCard>(Errors.General.EmptyGuid());

        if (amount.Amount <= 0)
            return Result.Failure<GiftCard>(Errors.General.MoneyAmountMustBeGreaterThanZero(amount.Amount));

        if (string.IsNullOrWhiteSpace(code))
            return Result.Failure<GiftCard>(Errors.General.NullOrWhiteSpaceString(code));

        return new GiftCard(customerId, amount, code);
    }

    public void Redeem(RedeemerId redeemerId, DateTime redeemedDate)
    {
        IsRedeemed = true;
        RedeemedDate = redeemedDate;
        RedeemerId = redeemerId;
    }

    private GiftCard(CustomerId customerId, Money amount, string code)
    {
        Id = new GiftCardId(Guid.NewGuid());
        CustomerId = customerId;
        Amount = amount;
        Code = code;
        IsRedeemed = false;
        PurchasedDate = DateTime.UtcNow;
    }

    private GiftCard() { }
}
