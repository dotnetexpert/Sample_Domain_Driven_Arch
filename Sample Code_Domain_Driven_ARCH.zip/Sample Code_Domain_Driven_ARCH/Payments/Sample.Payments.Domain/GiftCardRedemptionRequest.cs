﻿namespace Sample.Payments.Domain
{
    public class GiftCardRedemptionRequest
    {
        public string Code { get; set; }
    }
}
