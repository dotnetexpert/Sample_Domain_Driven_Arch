﻿namespace Sample.Payments.Domain;

public interface IMerchantRepository
{
    Task<List<Merchant>> GetMerchantsByStoreIdsAndPaymentSystemAsync(List<StoreId> storeIds, PaymentSystem paymentSystem);

    Task SaveChangesAsync();
}
