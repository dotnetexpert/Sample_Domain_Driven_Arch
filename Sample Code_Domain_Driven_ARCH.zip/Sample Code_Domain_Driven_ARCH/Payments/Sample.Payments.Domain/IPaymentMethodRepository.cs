﻿namespace Sample.Payments.Domain;

public interface IPaymentMethodRepository { }
