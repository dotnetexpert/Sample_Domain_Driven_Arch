﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Domain;

public class Links
{
    [JsonPropertyName("href")]
    public string href { get; set; }

    [JsonPropertyName("rel")]
    public string rel { get; set; }

    [JsonPropertyName("method")]
    public string method { get; set; }
}
