﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Domain;

public class Merchant : AggregateRoot<MerchantId>
{
    public string Name { get; private set; }
    public DateTime CreatedDate { get; private set; }
    public DateTime? DeletedDate { get; private set; }
    public bool Deleted { get; private set; }
    public StoreId StoreId { get; private set; }
    public string StoreName { get; private set; }
    public bool IsOnboarded { get; private set; }

    private readonly List<MerchantAccount> _merchantAccounts = new List<MerchantAccount>();
    public IReadOnlyCollection<MerchantAccount> MerchantAccounts => _merchantAccounts.AsReadOnly();

    private readonly List<PackageReference> _packageReferences = new List<PackageReference>();
    public IReadOnlyCollection<PackageReference> PackageReferences => _packageReferences.AsReadOnly();

    public static Result<Merchant> Create(string name, StoreId storeId, string storeName, bool isOnboarded)
    {
        return new Merchant(name, storeId, storeName, isOnboarded);
    }

    public void SetDeleted(bool deleted)
    {
        Deleted = deleted;
    }

    public void AddPaypalOrderReferenceIdToPackage(MerchantId merchantId, ReferenceId referenceId)
    {
        var packageReferenceData = PackageReference.Create(merchantId, referenceId);

        if (packageReferenceData == null)
        {
            throw new Exception("Failed to create a package reference. The provided merchantId or referenceId may be invalid.");
        }

        _packageReferences.Add(packageReferenceData.Value);
    }

    public void UpdateOnboardStatus(bool status)
    {
        IsOnboarded = status;
    }

    private Merchant(string name, StoreId storeId, string storeName, bool isOnboarded)
    {
        Id = new MerchantId(Guid.NewGuid());
        Name = name;
        CreatedDate = DateTime.UtcNow;
        StoreId = storeId;
        StoreName = storeName;
        IsOnboarded = isOnboarded;
    }

    public void AddMerchantAccount(MerchantAccount merchantAccount)
    {
        _merchantAccounts.Add(merchantAccount);
    }

    private Merchant() { }
}
