﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Domain;

public class MerchantAccount : Entity<MerchantAccountId>
{
    public PaymentSystem PaymentSystem { get; private set; }
    public DateTime CreatedDate { get; private set; }
    public DateTime? DeletedDate { get; private set; }
    public bool Deleted { get; private set; }
    public MerchantConfiguration MerchantConfiguration { get; set; }
    public MerchantId MerchantId { get; private set; }

    public static Result<MerchantAccount> Create(
        PaymentSystem paymentSystem,
        MerchantConfiguration merchantConfiguration,
        MerchantId merchantId
    )
    {
        if (paymentSystem?.Value is null || merchantConfiguration is null || merchantId is null)
            return Result.Failure<MerchantAccount>(Errors.General.Null());

        return new MerchantAccount(paymentSystem, merchantConfiguration, merchantId);
    }

    private MerchantAccount(PaymentSystem paymentSystem, MerchantConfiguration merchantConfiguration, MerchantId merchantId)
    {
        Id = new MerchantAccountId(Guid.NewGuid());
        PaymentSystem = paymentSystem;
        CreatedDate = DateTime.UtcNow;
        MerchantConfiguration = merchantConfiguration;
        MerchantId = merchantId;
    }

    private MerchantAccount() { }
}
