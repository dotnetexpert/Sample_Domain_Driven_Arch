﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Domain;

public record MerchantAccountId(Guid Value) : StronglyTypedId<Guid>(Value);
