﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Domain;

public class MerchantConfiguration : ValueObject<MerchantConfiguration>
{
    public string EmailAddress { get; private set; }
    public string AccountId { get; private set; }

    public static Result<MerchantConfiguration> Create(string emailAddress, string accountId)
    {
        if (string.IsNullOrWhiteSpace(emailAddress))
            Result.Failure<MerchantConfiguration>(Errors.General.NullOrWhiteSpaceString(emailAddress));

        if (string.IsNullOrWhiteSpace(accountId))
            Result.Failure<MerchantConfiguration>(Errors.General.NullOrWhiteSpaceString(accountId));

        return new MerchantConfiguration(emailAddress, accountId);
    }

    public MerchantConfiguration(string emailAddres, string accountId)
    {
        EmailAddress = emailAddres;
        AccountId = accountId;
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return EmailAddress;
        yield return AccountId;
    }

    private MerchantConfiguration() { }
}
