﻿namespace Sample.Payments.Domain;

public class OrderCreationRequest
{
    public string Address1 { get; set; }
    public string? Address2 { get; set; }
    public string City { get; set; }
    public string State { get; set; }
    public string ZipCode { get; set; }
    public string Country { get; set; }
    public string Phone { get; set; }
    public string BillingFirstName { get; set; }
    public string BillingLastName { get; set; }
    public string BillingAddress1 { get; set; }
    public string? BillingAddress2 { get; set; }
    public string BillingCity { get; set; }
    public string BillingState { get; set; }
    public string BillingZipCode { get; set; }
    public string BillingCountry { get; set; }
    public bool IsStoreCreditUsed { get; set; }
}
