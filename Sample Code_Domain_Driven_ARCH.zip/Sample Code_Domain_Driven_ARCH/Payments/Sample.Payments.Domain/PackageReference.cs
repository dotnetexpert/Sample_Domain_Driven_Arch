﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Domain;

public class PackageReference : Entity<PackageReferenceId>
{
    public MerchantId MerchantId { get; private set; }
    public ReferenceId ReferenceId { get; private set; }

    public static Result<PackageReference> Create(MerchantId merchantId, ReferenceId referenceId)
    {
        if (merchantId == null || merchantId.Value == Guid.Empty)
            return Result.Failure<PackageReference>(Errors.General.EmptyGuid());

        if (referenceId == null || referenceId.Value == Guid.Empty)
            return Result.Failure<PackageReference>(Errors.General.EmptyGuid());

        return new PackageReference(merchantId, referenceId);
    }

    public PackageReference(MerchantId merchantId, ReferenceId referenceIds)
    {
        Id = new(Guid.NewGuid());
        MerchantId = merchantId;
        ReferenceId = referenceIds;
    }

    private PackageReference() { }
}
