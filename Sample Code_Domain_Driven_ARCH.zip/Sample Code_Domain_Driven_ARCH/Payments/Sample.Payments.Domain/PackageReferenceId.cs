﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Domain;

public record PackageReferenceId(Guid Value) : StronglyTypedId<Guid>(Value);
