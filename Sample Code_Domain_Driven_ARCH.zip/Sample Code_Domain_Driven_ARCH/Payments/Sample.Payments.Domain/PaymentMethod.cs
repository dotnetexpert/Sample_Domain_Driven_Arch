﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Domain;

public class PaymentMethod : AggregateRoot<PaymentMethodId>
{
    public DateTime CreateDate { get; private set; }
    public DateTime? DeletedDate { get; private set; }
    public bool Deleted { get; private set; }
    public PayorId PayorId { get; private set; }
    public PaymentSystem PaymentSystem { get; private set; }
    public BillingAddress? BillingAddress { get; private set; }
    public CardInformation? CardInformation { get; private set; }
    public string PayorName { get; private set; }
    public string PayorEmailAddress { get; private set; }
    public string? PayorAccountId { get; private set; }

    public static Result<PaymentMethod> Create(
        PayorId payorId,
        PaymentSystem paymentSystem,
        BillingAddress? billingAddress,
        CardInformation cardInformation,
        string payorName,
        string payorEmailAddress,
        string payorAccountId
    )
    {
        if (payorId?.Value is null || payorId.Value == Guid.Empty || paymentSystem is null)
            return Result.Failure<PaymentMethod>(Errors.General.Null());

        return new PaymentMethod(
            payorId,
            paymentSystem,
            billingAddress,
            cardInformation,
            payorName,
            payorEmailAddress,
            payorAccountId
        );
    }

    private PaymentMethod(
        PayorId payorId,
        PaymentSystem paymentSystem,
        BillingAddress? billingAddress,
        CardInformation cardInformation,
        string payorName,
        string payorEmailAddress,
        string payorAccountId
    )
    {
        Id = new(Guid.NewGuid());
        CreateDate = DateTime.UtcNow;
        PayorId = payorId;
        PaymentSystem = paymentSystem;
        BillingAddress = billingAddress;
        CardInformation = cardInformation;
        PayorName = payorName;
        PayorEmailAddress = payorEmailAddress;
        PayorAccountId = payorAccountId;
    }

    private PaymentMethod() { }
}
