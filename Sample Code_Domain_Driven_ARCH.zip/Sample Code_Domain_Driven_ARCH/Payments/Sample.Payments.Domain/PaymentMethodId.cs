﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Domain;

public record PaymentMethodId(Guid Value) : StronglyTypedId<Guid>(Value);
