﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Domain;

public class PaymentSource
{
    [JsonPropertyName("paypal")]
    public PaypalPayment Paypal { get; set; }

    [JsonPropertyName("card")]
    public CardPayment Card { get; set; }
}
