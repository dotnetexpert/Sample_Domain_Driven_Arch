﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Domain;

public class PaymentToken : Entity<PaymentTokenId>
{
    public string EmailAddress { get; private set; }
    public string Token { get; private set; }
    public DateTime CreatedDate { get; private set; }

    public static Result<PaymentToken> Create(string emailAddress, string token)
    {
        if (string.IsNullOrWhiteSpace(emailAddress))
            return Result.Failure<PaymentToken>(Errors.General.NullOrWhiteSpaceString(emailAddress));

        if (string.IsNullOrWhiteSpace(token))
            return Result.Failure<PaymentToken>(Errors.General.NullOrWhiteSpaceString(token));

        var paymentToken = new PaymentToken(emailAddress, token);
        return Result.Success(paymentToken);
    }

    public void UpdatePaymentToken(string token)
    {
        Token = token;
    }

    private PaymentToken(string emailAddress, string token)
    {
        Id = new PaymentTokenId(Guid.NewGuid());
        EmailAddress = emailAddress;
        Token = token;
        CreatedDate = DateTime.UtcNow;
    }

    private PaymentToken() { }
}
