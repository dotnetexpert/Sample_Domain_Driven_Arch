﻿using System.ComponentModel.DataAnnotations;

namespace Sample.Payments.Domain;

public class PaymentTokenRequest
{
    [Required(ErrorMessage = "Billing Address 1 is required.")]
    public string BillingAddress1 { get; set; }

    public string? BillingAddress2 { get; set; }

    [Required(ErrorMessage = "Billing City is required.")]
    public string BillingCity { get; set; }

    [Required(ErrorMessage = "Billing State is required.")]
    public string BillingState { get; set; }

    [Required(ErrorMessage = "Billing Postal Code is required.")]
    public string BillingPostalCode { get; set; }

    [Required(ErrorMessage = "Billing Country Code is required.")]
    public string BillingCountryCode { get; set; }

    [Required(ErrorMessage = "Last Digits required.")]
    public string LastDigits { get; set; }

    [Required(ErrorMessage = "Vault Expiry is required.")]
    public string Expiry { get; set; }

    [Required(ErrorMessage = "Vault Name is required.")]
    public string Name { get; set; }
}
