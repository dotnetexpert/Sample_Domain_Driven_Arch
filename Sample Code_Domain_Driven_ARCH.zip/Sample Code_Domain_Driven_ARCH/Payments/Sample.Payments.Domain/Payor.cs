﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Domain;

public class Payor : AggregateRoot<PayorId>
{
    public DateTime CreatedDate { get; private set; }
    public DateTime? DeletedDate { get; private set; }
    public bool Deleted { get; private set; }
    public CustomerId CustomerId { get; private set; }
    private readonly List<PaymentMethod> _paymentMethods = new List<PaymentMethod>();
    public IReadOnlyCollection<PaymentMethod> PaymentMethods => _paymentMethods.AsReadOnly();
    private readonly List<Transaction> _transactions = new List<Transaction>();
    public IReadOnlyCollection<Transaction> Transactions => _transactions.AsReadOnly();

    public static Result<Payor> Create(CustomerId customerId)
    {
        if (customerId is null || customerId.Value == Guid.Empty)
            return Result.Failure<Payor>(Errors.General.Null());
        return new Payor(customerId);
    }

    public void AddTransaction(TransactionItemData transactionItemData)
    {
        var result = Transaction.Create(
            transactionItemData.PayorId,
            transactionItemData.PaymentMethodId,
            transactionItemData.MerchantId,
            transactionItemData.Subtotal,
            transactionItemData.Tax,
            transactionItemData.Total,
            transactionItemData.Discount,
            transactionItemData.Net,
            transactionItemData.Gross,
            transactionItemData.PlatformFee,
            transactionItemData.ExternalPaymentSystemTransactionId,
            transactionItemData.AuthorizationCode,
            transactionItemData.ResponseCode,
            transactionItemData.ResponseDescription,
            transactionItemData.ReferenceId,
            transactionItemData.Orderid,
            transactionItemData.FinalPayment,
            Money.Of(0.00m, Currency.USDollar.Code),
            transactionItemData.CardHolderName,
            transactionItemData.LastDigits,
            transactionItemData.ExpiryDate,
            transactionItemData.Brand,
            transactionItemData.CaptureStatus,
            transactionItemData.Network,
            transactionItemData.ProcessorAVSCode,
            transactionItemData.ProcessorCVVCode,
            transactionItemData.ProcessorResponseCode,
            transactionItemData.PaymentSystem,
            transactionItemData.StoreCreditUsed,
            transactionItemData.SampleFee,
            transactionItemData.PaymentDebugId
        );

        if (result.IsFailure)
        {
            throw new Exception("Failed to create transaction. Invalid data provided.");
        }
        _transactions.Add(result.Value);
    }

    public void AddPaymentMethod(PaymentMethodData paymentMethodData)
    {
        var result = PaymentMethod.Create(
            paymentMethodData.PayorId,
            paymentMethodData.PaymentSystem,
            paymentMethodData.BillingAddress,
            paymentMethodData.CardInformation,
            paymentMethodData.PayorName,
            paymentMethodData.PayorEmailAddress,
            paymentMethodData.PayorAccountId
        );

        if (result.IsFailure)
        {
            throw new Exception("Failed to create payment method. Invalid data provided.");
        }

        _paymentMethods.Add(result.Value);
    }

    private Payor(CustomerId customerId)
    {
        Id = new PayorId(Guid.NewGuid());
        CustomerId = customerId;
        CreatedDate = DateTime.UtcNow;
    }

    private Payor() { }
}
