﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Domain;

public record PayorId(Guid Value) : StronglyTypedId<Guid>(Value);
