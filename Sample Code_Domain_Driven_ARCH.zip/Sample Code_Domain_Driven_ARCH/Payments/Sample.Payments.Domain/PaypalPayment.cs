﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Domain;

public class PaypalPayment
{
    [JsonPropertyName("email_address")]
    public string EmailAddress { get; set; }

    [JsonPropertyName("account_id")]
    public string AccountId { get; set; }

    [JsonPropertyName("account_status")]
    public string AccountStatus { get; set; }

    [JsonPropertyName("name")]
    public Name Name { get; set; }
}
