﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Domain;

public record ReferenceId(Guid Value) : StronglyTypedId<Guid>(Value);
