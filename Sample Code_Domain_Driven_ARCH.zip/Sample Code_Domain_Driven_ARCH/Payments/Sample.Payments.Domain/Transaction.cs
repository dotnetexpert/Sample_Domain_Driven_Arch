﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Domain;

public class Transaction : AggregateRoot<TransactionId>
{
    public PayorId? PayorId { get; private set; }
    public PaymentMethodId? PaymentMethodId { get; private set; }
    public MerchantAccountId? MerchantId { get; private set; }
    public DateTime Date { get; private set; }
    public Money Subtotal { get; private set; }
    public Money Tax { get; private set; }
    public Money Total { get; private set; }
    public string ExternalPaymentSystemTransactionId { get; private set; }
    public string? AuthorizationCode { get; private set; }
    public string ResponseCode { get; private set; }
    public string? ResponseDescription { get; private set; }
    public Money Discount { get; private set; }
    public Money Net { get; private set; }
    public Money Gross { get; private set; }
    public Money PlatformFee { get; private set; }
    public string OrderId { get; private set; }
    public bool FinalPayment { get; private set; }
    public Money RefundedAmount { get; private set; }
    public DateTime RefundCompletedAt { get; private set; }
    public ReferenceId ReferenceId { get; private set; }
    public string? CardHolderName { get; private set; }
    public string? LastDigits { get; private set; }
    public string? ExpiryDate { get; private set; }
    public string? Brand { get; private set; }
    public string? CaptureStatus { get; private set; }
    public Dictionary<string, string>? Network { get; private set; }
    public string? ProcessorAVSCode { get; private set; }
    public string? ProcessorCVVCode { get; private set; }
    public string? ProcessorResponseCode { get; private set; }
    public PaymentSystem PaymentSystem { get; private set; }
    public Money StoreCreditUsed { get; private set; }
    public Money SampleFee { get; private set; }
    public string? PaymentDebugId { get; private set; }

    public static Result<Transaction> Create(
        PayorId payorId,
        PaymentMethodId? paymentMethodId,
        MerchantAccountId? merchantId,
        Money subtotal,
        Money tax,
        Money total,
        Money discount,
        Money net,
        Money gross,
        Money platformFee,
        string externalPaymentSystemTransactionId,
        string authorizationCode,
        string responseCode,
        string responseDescription,
        ReferenceId referenceId,
        string orderId,
        bool finalPayment,
        Money refundedAmount,
        string cardHolderName,
        string lastDigits,
        string expiryDate,
        string brand,
        string captureStatus,
        Dictionary<string, string> network,
        string processorAVSCode,
        string processorCVVCode,
        string processorResponseCode,
        PaymentSystem paymentSystem,
        Money storeCreditUsed,
        Money SampleFee,
        string paymentDebugId
    )
    {
        return new Transaction(
            payorId,
            paymentMethodId,
            merchantId,
            subtotal,
            tax,
            total,
            discount,
            net,
            gross,
            platformFee,
            externalPaymentSystemTransactionId,
            authorizationCode,
            responseCode,
            responseDescription,
            referenceId,
            orderId,
            finalPayment,
            refundedAmount,
            cardHolderName,
            lastDigits,
            expiryDate,
            brand,
            captureStatus,
            network,
            processorAVSCode,
            processorCVVCode,
            processorResponseCode,
            paymentSystem,
            storeCreditUsed,
            SampleFee,
            paymentDebugId
        );
    }

    private Transaction(
        PayorId payorId,
        PaymentMethodId? paymentMethodId,
        MerchantAccountId? merchantId,
        Money subtotal,
        Money tax,
        Money total,
        Money discount,
        Money net,
        Money gross,
        Money platformFee,
        string externalPaymentSystemTransactionId,
        string authorizationCode,
        string responseCode,
        string responseDescription,
        ReferenceId referenceId,
        string orderId,
        bool finalPayment,
        Money refundedAmount,
        string cardHolderName,
        string lastDigits,
        string expiryDate,
        string brand,
        string captureStatus,
        Dictionary<string, string> network,
        string processorAVSCode,
        string processorCVVCode,
        string processorResponseCode,
        PaymentSystem paymentSystem,
        Money storeCreditUsed,
        Money SampleFee,
        string paymentDebugId
    )
    {
        Id = new(Guid.NewGuid());
        PayorId = payorId;
        PaymentMethodId = paymentMethodId;
        MerchantId = merchantId;
        Date = DateTime.UtcNow;
        Subtotal = subtotal;
        Tax = tax;
        Total = total;
        Discount = discount;
        Net = net;
        Gross = gross;
        PlatformFee = platformFee;
        ExternalPaymentSystemTransactionId = externalPaymentSystemTransactionId;
        AuthorizationCode = authorizationCode;
        ResponseCode = responseCode;
        ResponseDescription = responseDescription;
        ReferenceId = referenceId;
        OrderId = orderId;
        FinalPayment = finalPayment;
        RefundedAmount = refundedAmount;
        CardHolderName = cardHolderName;
        LastDigits = lastDigits;
        ExpiryDate = expiryDate;
        Brand = brand;
        CaptureStatus = captureStatus;
        Network = network;
        ProcessorAVSCode = processorAVSCode;
        ProcessorCVVCode = processorCVVCode;
        ProcessorResponseCode = processorResponseCode;
        PaymentSystem = paymentSystem;
        StoreCreditUsed = storeCreditUsed;
        SampleFee = SampleFee;
        PaymentDebugId = paymentDebugId;
    }

    public void AddRefund(Money refund)
    {
        RefundedAmount += refund;
        RefundCompletedAt = DateTime.UtcNow;
    }

    private Transaction() { }
}
