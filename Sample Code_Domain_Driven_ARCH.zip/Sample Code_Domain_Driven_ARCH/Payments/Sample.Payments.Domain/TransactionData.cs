﻿namespace Sample.Payments.Domain;

public record TransactionData(DateTime Date, decimal Amount, string Description);
