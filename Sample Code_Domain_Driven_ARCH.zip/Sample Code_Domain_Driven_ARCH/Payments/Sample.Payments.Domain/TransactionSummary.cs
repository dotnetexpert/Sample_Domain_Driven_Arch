﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Domain
{
    public class TransactionSummary : ValueObject<TransactionSummary>
    {
        public List<TransactionData> Debits { get; private set; }
        public List<TransactionData> Credits { get; private set; }

        private TransactionSummary(List<TransactionData> credit, List<TransactionData> debit)
        {
            Credits = credit;
            Debits = debit;
        }

        public static Result<TransactionSummary> Create(List<TransactionData> credit, List<TransactionData> debit)
        {
            return Result.Success(new TransactionSummary(credit, debit));
        }

        protected override IEnumerable<object> GetEqualityComponents()
        {
            yield return Credits;
            yield return Debits;
        }
    }
}
