﻿namespace Sample.Payments.Domain;

public class VaultConfiguration
{
    public string Number { get; set; }
    public string Expiry { get; set; }
    public string Name { get; set; }
}
