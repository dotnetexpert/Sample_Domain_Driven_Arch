﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Domain;

public class VerificationStatus
{
    [JsonPropertyName("verification_status")]
    public string Status { get; set; }
}
