﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sample.Payments.Domain;

namespace Sample.Orders.Infrastructure.Data.Configurations;

public class MerchantAccountConfiguration : IEntityTypeConfiguration<MerchantAccount>
{
    public void Configure(EntityTypeBuilder<MerchantAccount> builder)
    {
        builder.HasKey(p => p.Id);
        builder.Property(p => p.Id).HasConversion(id => id.Value, value => new MerchantAccountId(value));

        builder.Property(p => p.DeletedDate).IsRequired(false);

        builder.Property(p => p.PaymentSystem).HasConversion(p => p.Value, value => PaymentSystem.FromValue(value)!);

        builder.OwnsOne(p => p.MerchantConfiguration);

        builder.Property(p => p.MerchantId).HasConversion(id => id.Value, value => new MerchantId(value));
    }
}
