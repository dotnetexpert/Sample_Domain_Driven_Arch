﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sample.Payments.Domain;

namespace Sample.Payments.Infrastructure.Data.Configurations;

public class MerchantConfiguration : IEntityTypeConfiguration<Merchant>
{
    public void Configure(EntityTypeBuilder<Merchant> builder)
    {
        builder.HasKey(p => p.Id);

        builder.Property(p => p.DeletedDate).IsRequired(false);

        builder.Property(p => p.Id).HasConversion(id => id.Value, value => new MerchantId(value));

        builder.HasMany(p => p.MerchantAccounts).WithOne().HasForeignKey(p => p.MerchantId);

        builder.HasMany(p => p.PackageReferences).WithOne().HasForeignKey(p => p.MerchantId);

        builder.Property(p => p.StoreId).HasConversion(id => id.Value, value => new StoreId(value));
    }
}
