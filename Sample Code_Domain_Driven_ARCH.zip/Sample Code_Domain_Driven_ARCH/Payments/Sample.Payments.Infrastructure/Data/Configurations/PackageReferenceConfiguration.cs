﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sample.Payments.Domain;

namespace Sample.Payments.Infrastructure.Data.Configurations;

public class PackageReferenceConfiguration : IEntityTypeConfiguration<PackageReference>
{
    public void Configure(EntityTypeBuilder<PackageReference> builder)
    {
        builder.HasKey(p => p.Id);

        builder.Property(p => p.Id).HasConversion(id => id.Value, value => new PackageReferenceId(value));

        builder.Property(p => p.MerchantId).HasConversion(id => id.Value, value => new MerchantId(value));

        builder.Property(p => p.ReferenceId).HasConversion(id => id.Value, value => new ReferenceId(value));
    }
}
