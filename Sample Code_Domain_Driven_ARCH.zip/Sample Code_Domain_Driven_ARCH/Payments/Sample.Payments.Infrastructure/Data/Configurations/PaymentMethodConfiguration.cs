﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sample.Payments.Domain;

namespace Sample.Payments.Infrastructure.Data.Configurations;

public class PaymentMethodConfiguration : IEntityTypeConfiguration<PaymentMethod>
{
    public void Configure(EntityTypeBuilder<PaymentMethod> builder)
    {
        builder.HasKey(p => p.Id);

        builder.HasQueryFilter(r => !r.Deleted);

        builder.Property(p => p.Id).HasConversion(id => id.Value, value => new PaymentMethodId(value));

        builder.Property(p => p.DeletedDate).IsRequired(false);

        builder.Property(p => p.PayorId).HasConversion(id => id.Value, value => new PayorId(value));

        builder.Property(p => p.PaymentSystem).HasConversion(p => p.Value, value => PaymentSystem.FromValue(value)!);

        builder.OwnsOne(
            p => p.BillingAddress,
            p =>
            {
                p.Property(p => p.Address1).HasColumnName("BillingAddress1").IsRequired(false);

                p.Property(p => p.Address2).HasColumnName("BillingAddress2").IsRequired(false);

                p.Property(p => p.City).HasColumnName("BillingCity").IsRequired(false);

                p.Property(p => p.State).HasColumnName("BillingState").IsRequired(false);

                p.Property(p => p.ZipCode).HasColumnName("BillingZipCode").IsRequired(false);

                p.Property(p => p.Country).HasColumnName("BillingCountry").IsRequired(false);
            }
        );

        builder.OwnsOne(p => p.CardInformation);
    }
}
