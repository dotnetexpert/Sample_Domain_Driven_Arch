﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sample.Payments.Domain;

namespace Sample.Payments.Infrastructure.Data.Configurations;

public class PaymentTokenConfiguration : IEntityTypeConfiguration<PaymentToken>
{
    public void Configure(EntityTypeBuilder<PaymentToken> builder)
    {
        builder.HasKey(p => p.Id);

        builder.Property(p => p.Id).HasConversion(p => p.Value, value => new PaymentTokenId(value)).IsRequired();

        builder.Property(p => p.EmailAddress).IsRequired().HasMaxLength(256);

        builder.Property(p => p.Token).IsRequired();

        builder.Property(p => p.CreatedDate).IsRequired();
    }
}
