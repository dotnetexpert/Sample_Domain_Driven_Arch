﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sample.Payments.Domain;
using Sample.Payments.Domain.Core;

namespace Sample.Payments.Infrastructure.Data.Configurations;

public class PayorConfiguration : IEntityTypeConfiguration<Payor>
{
    public void Configure(EntityTypeBuilder<Payor> builder)
    {
        builder.HasKey(p => p.Id);

        builder.HasQueryFilter(r => !r.Deleted);

        builder.Property(p => p.Id).HasConversion(id => id.Value, value => new PayorId(value));

        builder.Property(p => p.CustomerId).HasConversion(id => id.Value, value => new CustomerId(value));

        builder.Property(p => p.DeletedDate).IsRequired(false);

        builder.HasMany(p => p.Transactions).WithOne().HasForeignKey(p => p.PayorId);

        builder.HasMany(p => p.PaymentMethods).WithOne().HasForeignKey(p => p.PayorId);
    }
}
