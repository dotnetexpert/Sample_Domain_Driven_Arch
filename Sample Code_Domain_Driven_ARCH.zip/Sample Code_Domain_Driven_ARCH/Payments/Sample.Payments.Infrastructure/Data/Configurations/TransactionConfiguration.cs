﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sample.Payments.Domain;
using Sample.Payments.Domain.Core;

namespace Sample.Payments.Infrastructure.Data.Configurations;

public class TransactionConfiguration : IEntityTypeConfiguration<Transaction>
{
    public void Configure(EntityTypeBuilder<Transaction> builder)
    {
        builder.HasKey(p => p.Id);

        builder.Property(p => p.Id).HasConversion(id => id.Value, value => new TransactionId(value));

        builder.Property(p => p.PayorId).HasConversion(id => id.Value, value => new PayorId(value));

        builder.Property(p => p.PaymentMethodId).HasConversion(id => id.Value, value => new PaymentMethodId(value));

        builder.Property(p => p.PaymentMethodId).IsRequired(false);

        builder.Property(p => p.MerchantId).HasConversion(id => id.Value, value => new MerchantAccountId(value));

        builder.Property(p => p.ReferenceId).HasConversion(id => id.Value, value => new ReferenceId(value));

        builder.Property(p => p.PaymentSystem).HasConversion(p => p.Value, p => PaymentSystem.FromValue(p));

        builder.OwnsOne(
            p => p.Total,
            p =>
            {
                p.Property(p => p.Amount).HasColumnName("TotalAmount").HasPrecision(11, 2).IsRequired();

                p.Property(p => p.Currency).HasColumnName("TotalCurrencyCode").HasMaxLength(3).IsRequired();
            }
        );

        builder.OwnsOne(
            p => p.Subtotal,
            p =>
            {
                p.Property(p => p.Amount).HasColumnName("SubtotalAmount").HasPrecision(11, 2).IsRequired();

                p.Property(p => p.Currency).HasColumnName("SubtotalCurrencyCode").HasMaxLength(3).IsRequired();
            }
        );

        builder.OwnsOne(
            p => p.Tax,
            p =>
            {
                p.Property(p => p.Amount).HasColumnName("TaxAmount").HasPrecision(11, 2).IsRequired();

                p.Property(p => p.Currency).HasColumnName("TaxCurrencyCode").HasMaxLength(3).IsRequired();
            }
        );

        builder.OwnsOne(
            p => p.Discount,
            p =>
            {
                p.Property(p => p.Amount).HasColumnName("DiscountAmount").HasPrecision(11, 2).IsRequired();

                p.Property(p => p.Currency).HasColumnName("DiscountCurrencyCode").HasMaxLength(3).IsRequired();
            }
        );

        builder.OwnsOne(
            p => p.Net,
            p =>
            {
                p.Property(p => p.Amount).HasColumnName("NetAmount").HasPrecision(11, 2).IsRequired();

                p.Property(p => p.Currency).HasColumnName("NetCurrencyCode").HasMaxLength(3).IsRequired();
            }
        );

        builder.OwnsOne(
            p => p.Gross,
            p =>
            {
                p.Property(p => p.Amount).HasColumnName("GrossAmount").HasPrecision(11, 2).IsRequired();

                p.Property(p => p.Currency).HasColumnName("GrossCurrencyCode").HasMaxLength(3).IsRequired();
            }
        );

        builder.OwnsOne(
            p => p.PlatformFee,
            p =>
            {
                p.Property(p => p.Amount).HasColumnName("PlatformFeeAmount").HasPrecision(11, 2).IsRequired();

                p.Property(p => p.Currency).HasColumnName("PlatformFeeCurrencyCode").HasMaxLength(3).IsRequired();
            }
        );

        builder.OwnsOne(
            p => p.RefundedAmount,
            p =>
            {
                p.Property(p => p.Amount).HasColumnName("RefundedAmount").HasPrecision(11, 2).IsRequired();
                p.Property(p => p.Currency).HasColumnName("RefundedCurrencyCode").HasMaxLength(3).IsRequired();
            }
        );
        builder.OwnsOne(
            p => p.StoreCreditUsed,
            p =>
            {
                p.Property(p => p.Amount).HasColumnName("StoreCreditUsedAmount").HasPrecision(11, 2).IsRequired();
                p.Property(p => p.Currency).HasColumnName("StoreCreditUsedCurrencyCode").HasMaxLength(3).IsRequired();
            }
        );

        builder.OwnsOne(
            p => p.SampleFee,
            p =>
            {
                p.Property(p => p.Amount).HasColumnName("SampleFee").HasPrecision(11, 2).IsRequired();
                p.Property(p => p.Currency).HasColumnName("SampleFeeCurrencyCode").HasMaxLength(3).IsRequired();
            }
        );
    }
}
