﻿using System.Reflection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Sample.Payments.Domain;

namespace Sample.Payments.Infrastructure.Data;

public class PaymentsContext : DbContext
{
    private readonly IConfiguration _configuration;
#pragma warning disable CS8618 // Required by Entity Framework
    public PaymentsContext(DbContextOptions<PaymentsContext> options)
        : base(options) { }

    public PaymentsContext(DbContextOptions<PaymentsContext> options, IConfiguration configuration)
        : base(options)
    {
        _configuration = configuration;
    }

    public DbSet<Merchant> Merchants { get; set; }
    public DbSet<PaymentMethod> PaymentMethods { get; set; }
    public DbSet<Payor> Payors { get; set; }
    public DbSet<Transaction> Transactions { get; set; }
    public DbSet<PaymentToken> PaymentTokens { get; set; }
    public DbSet<GiftCard> GiftCards { get; set; }
    public DbSet<PackageReference> PackageReferences { get; set; }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        builder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseNpgsql(_configuration.GetConnectionString("PaymentsConnectionString"));
    }
}
