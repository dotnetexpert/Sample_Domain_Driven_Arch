﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Sample.Payments.Infrastructure.Migrations;

/// <inheritdoc />
public partial class Init : Migration
{
    /// <inheritdoc />
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "Merchants",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                Name = table.Column<string>(type: "text", nullable: false),
                CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                DeletedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                Deleted = table.Column<bool>(type: "boolean", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Merchants", x => x.Id);
            }
        );

        migrationBuilder.CreateTable(
            name: "PaymentMethods",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                CreateDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                DeletedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                Deleted = table.Column<bool>(type: "boolean", nullable: false),
                PayorId = table.Column<Guid>(type: "uuid", nullable: false),
                PaymentSystem = table.Column<int>(type: "integer", nullable: false),
                BillingAddress_FirstName = table.Column<string>(type: "text", nullable: false),
                BillingAddress_LastName = table.Column<string>(type: "text", nullable: false),
                BillingAddress1 = table.Column<string>(type: "text", nullable: false),
                BillingAddress2 = table.Column<string>(type: "text", nullable: true),
                BillingCity = table.Column<string>(type: "text", nullable: false),
                BillingState = table.Column<string>(type: "text", nullable: false),
                BillingCountry = table.Column<string>(type: "text", nullable: false),
                BillingZipCode = table.Column<string>(type: "text", nullable: false),
                CardInformation_CardType = table.Column<string>(type: "text", nullable: false),
                CardInformation_LastFour = table.Column<string>(type: "text", nullable: false),
                CardInformation_ExpirationMonth = table.Column<int>(type: "integer", nullable: false),
                CardInformation_ExpirationYear = table.Column<int>(type: "integer", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_PaymentMethods", x => x.Id);
            }
        );

        migrationBuilder.CreateTable(
            name: "Payors",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                Name = table.Column<string>(type: "text", nullable: false),
                CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                DeletedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                Deleted = table.Column<bool>(type: "boolean", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Payors", x => x.Id);
            }
        );

        migrationBuilder.CreateTable(
            name: "Transactions",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                PayorId = table.Column<Guid>(type: "uuid", nullable: false),
                PaymentMethodId = table.Column<Guid>(type: "uuid", nullable: false),
                MerchantId = table.Column<Guid>(type: "uuid", nullable: false),
                Date = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                SubtotalAmount = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: false),
                SubtotalCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                TaxAmount = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: false),
                TaxCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                TotalAmount = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: false),
                TotalCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                ExternalPaymentSystemTransactionId = table.Column<string>(type: "text", nullable: false),
                AuthorizationCode = table.Column<string>(type: "text", nullable: false),
                ResponseCode = table.Column<string>(type: "text", nullable: false),
                ResponseDescription = table.Column<string>(type: "text", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Transactions", x => x.Id);
            }
        );

        migrationBuilder.CreateTable(
            name: "MerchantAccount",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                PaymentSystem = table.Column<int>(type: "integer", nullable: false),
                CreatedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                DeletedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                Deleted = table.Column<bool>(type: "boolean", nullable: false),
                MerchantId = table.Column<Guid>(type: "uuid", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_MerchantAccount", x => x.Id);
                table.ForeignKey(
                    name: "FK_MerchantAccount_Merchants_MerchantId",
                    column: x => x.MerchantId,
                    principalTable: "Merchants",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Cascade
                );
            }
        );

        migrationBuilder.CreateIndex(name: "IX_MerchantAccount_MerchantId", table: "MerchantAccount", column: "MerchantId");
    }

    /// <inheritdoc />
    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(name: "MerchantAccount");

        migrationBuilder.DropTable(name: "PaymentMethods");

        migrationBuilder.DropTable(name: "Payors");

        migrationBuilder.DropTable(name: "Transactions");

        migrationBuilder.DropTable(name: "Merchants");
    }
}
