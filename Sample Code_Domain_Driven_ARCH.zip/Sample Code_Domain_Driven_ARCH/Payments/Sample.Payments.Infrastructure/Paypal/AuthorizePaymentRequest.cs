﻿namespace Sample.Payments.Infrastructure.Paypal;

public record AuthorizePaymentRequest(string OrderId);
