﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class Breakdown
{
    [JsonPropertyName("item_total")]
    public Money ItemTotal { get; set; }

    [JsonPropertyName("shipping")]
    public Money Shipping { get; set; }

    [JsonPropertyName("tax_total")]
    public Money TaxTotal { get; set; }

    [JsonPropertyName("discount")]
    public Money Discount { get; set; }
}
