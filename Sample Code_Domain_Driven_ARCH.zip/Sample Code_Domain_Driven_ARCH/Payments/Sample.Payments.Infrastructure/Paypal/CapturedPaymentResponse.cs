﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

internal class CapturedPaymentResponse
{
    [JsonPropertyName("payments")]
    public Payments Payments { get; set; }
}
