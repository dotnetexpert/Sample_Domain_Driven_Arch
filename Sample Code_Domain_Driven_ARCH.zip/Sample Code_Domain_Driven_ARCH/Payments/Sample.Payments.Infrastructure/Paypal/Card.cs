﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class Card
{
    [JsonPropertyName("vault_id")]
    public string vault_id { get; set; }
}
