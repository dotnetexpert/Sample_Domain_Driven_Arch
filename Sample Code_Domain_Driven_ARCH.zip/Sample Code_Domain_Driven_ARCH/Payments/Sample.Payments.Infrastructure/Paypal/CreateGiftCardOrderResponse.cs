﻿using Sample.Payments.Domain;

namespace Sample.Payments.Infrastructure.Paypal;

public record CreateGiftCardOrderResponse(string Id, string Status, List<Links> Links);
