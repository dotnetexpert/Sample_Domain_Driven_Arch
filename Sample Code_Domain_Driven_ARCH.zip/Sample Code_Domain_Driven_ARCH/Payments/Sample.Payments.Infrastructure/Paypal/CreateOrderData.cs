﻿using System.Text.Json.Serialization;
using Sample.Payments.Domain;

namespace Sample.Payments.Infrastructure.Paypal;

public class CreateOrderData
{
    [JsonPropertyName("id")]
    public string OrderId { get; set; }

    [JsonPropertyName("status")]
    public string Status { get; set; }

    [JsonPropertyName("token")]
    public string Token { get; set; }

    [JsonPropertyName("links")]
    public List<Links> Links { get; set; }
}
