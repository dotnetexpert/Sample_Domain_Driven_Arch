﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class CreateOrderRequest
{
    [JsonPropertyName("intent")]
    public string Intent { get; set; } = "CAPTURE";

    [JsonPropertyName("purchase_units")]
    public List<PurchaseUnit> PurchaseUnits { get; set; } = new List<PurchaseUnit>();
}
