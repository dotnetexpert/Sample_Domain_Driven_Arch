﻿using System.Text.Json.Serialization;
using Sample.Payments.Domain;

namespace Sample.Payments.Infrastructure.Paypal;

public class CreateVaultSetupResponse
{
    [JsonPropertyName("id")]
    public string Id { get; set; }

    [JsonPropertyName("customer")]
    public Customer Customer { get; set; }

    [JsonPropertyName("status")]
    public string Status { get; set; }

    [JsonPropertyName("payment_source")]
    public PaymentSource PaymentSource { get; set; }

    [JsonPropertyName("links")]
    public List<Links> Links { get; set; }
}
