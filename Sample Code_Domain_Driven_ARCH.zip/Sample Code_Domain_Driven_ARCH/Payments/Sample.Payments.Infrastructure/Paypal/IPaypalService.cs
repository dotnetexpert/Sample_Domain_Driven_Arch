﻿using Microsoft.AspNetCore.Http;
using Sample.Payments.Domain;
using Sample.Payments.Domain.Core;
using Sample.Payments.Infrastructure.GiftCards;
using static Sample.Payments.Infrastructure.Paypal.PaypalService;

namespace Sample.Payments.Infrastructure.Paypal;

public interface IPaypalService
{
    PaymentSystem PaymentSystem { get; }
    Task<AuthorizePaymentResponse> AuthorizePaymentAsync(string orderId);
    Task<PaymentCaptureResponse> CapturePaymentAsync(string orderId);
    Task<CreateOrderData> CreateOrderAsync(CreateOrderRequest createOrderRequest);
    Task<CreateGiftCardOrderResponse> BuyGiftCardAsync(BuyCardRequest createOrderRequest);
    Task<CreateOrderResponse> ConsumeGiftCardAsync(BuyCardRequest createOrderRequest);
    Task<AuthToken> GetAuthTokenAsync();
    Task<AuthToken> GetAuthTokenForOnboardingAsync();
    Task<RefundPaymentResponse> RefundPaymentAsync(string captureId, RefundRequest refundRequest);
    Task<List<Links>> PartnerOnboardingAsync(Guid trackingId);
    Task<bool> VerifyEvent(string json, IHeaderDictionary headerDictionary);
    Task<string> GetMerchantId(Guid trackingId);
    Task<bool> CheckMerchantIntegration(string sellerMerchantId);
    Task<GetOrderDetailsResponse> GetOrderDetails(string orderId);
    Task<string> VaultSetupToken(VaultSetupRequest createVaultRequest);
}
