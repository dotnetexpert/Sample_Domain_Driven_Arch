﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Infrastructure.Paypal;

public class Intent : Enumeration<Intent>
{
    public static readonly Intent Capture = new Intent(1, "CAPTURE");
    public static readonly Intent Authorize = new Intent(2, "AUTHORIZE");

    private Intent(int value, string name)
        : base(value, name) { }
}
