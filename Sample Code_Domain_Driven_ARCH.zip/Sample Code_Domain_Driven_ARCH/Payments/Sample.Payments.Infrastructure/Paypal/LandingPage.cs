﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Infrastructure.Paypal;

public class LandingPage : Enumeration<LandingPage>
{
    public static readonly LandingPage Login = new LandingPage(1, "LOGIN");
    public static readonly LandingPage GuestCheckout = new LandingPage(2, "GUEST_CHECKOUT");
    public static readonly LandingPage NoPreference = new LandingPage(2, "NO_PREFERENCE");

    private LandingPage(int value, string name)
        : base(value, name) { }
}
