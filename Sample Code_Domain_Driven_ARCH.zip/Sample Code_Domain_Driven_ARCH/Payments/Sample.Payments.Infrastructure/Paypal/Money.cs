﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class Money
{
    [JsonPropertyName("value")]
    public string Value { get; set; }

    [JsonPropertyName("currency_code")]
    public string CurrencyCode { get; set; }

    [JsonPropertyName("breakdown")]
    public Breakdown? Breakdown { get; set; }
}
