﻿using System.Text.Json.Serialization;
using Sample.Payments.Domain;

namespace Sample.Payments.Infrastructure.Paypal;

public class Payer
{
    [JsonPropertyName("name")]
    public Name Name { get; set; }

    [JsonPropertyName("email_address")]
    public string EmailAddress { get; set; }
}
