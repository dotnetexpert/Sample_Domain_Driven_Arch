﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class PaymentCapture
{
    [JsonPropertyName("id")]
    public string ExternalPaymentSystemTransactionId { get; set; }

    [JsonPropertyName("status")]
    public string Status { get; set; }

    [JsonPropertyName("amount")]
    public Money Amount { get; set; }

    [JsonPropertyName("final_capture")]
    public bool FinalCapture { get; set; }

    [JsonPropertyName("seller_receivable_breakdown")]
    public SellerReceivableBreakdown? SellerReceivableBreakdown { get; set; }

    [JsonPropertyName("create_time")]
    public DateTime CreateTime { get; set; }

    [JsonPropertyName("update_time")]
    public DateTime UpdateTime { get; set; }

    [JsonPropertyName("network_transaction_reference")]
    public NetworkTransactionReference NetworkTransactionReference { get; set; }

    [JsonPropertyName("processor_response")]
    public ProcessorResponse ProcessorResponse { get; set; }
}

public class NetworkTransactionReference
{
    [JsonPropertyName("id")]
    public string Id { get; set; }

    [JsonPropertyName("network")]
    public string Network { get; set; }
}

public class ProcessorResponse
{
    [JsonPropertyName("avs_code")]
    public string AvsCode { get; set; }

    [JsonPropertyName("cvv_code")]
    public string CvvCode { get; set; }

    [JsonPropertyName("response_code")]
    public string ResponseCode { get; set; }
}
