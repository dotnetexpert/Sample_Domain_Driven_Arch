﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class PaymentCaptureRequest
{
    [JsonPropertyName("authorization_token")]
    public string Token { get; set; }

    [JsonPropertyName("paypal_request_id")]
    public string RequestId { get; set; }
}
