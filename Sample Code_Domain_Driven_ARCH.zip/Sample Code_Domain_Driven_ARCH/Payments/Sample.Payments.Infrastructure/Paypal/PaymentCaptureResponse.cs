﻿using System.Text.Json.Serialization;
using Sample.Payments.Domain;

namespace Sample.Payments.Infrastructure.Paypal;

public class PaymentCaptureResponse : ErrorResponse
{
    [JsonPropertyName("id")]
    public string Id { get; set; }

    [JsonPropertyName("status")]
    public string Status { get; set; }

    [JsonPropertyName("purchase_units")]
    public List<PurchaseUnit> PurchaseUnits { get; set; }

    [JsonPropertyName("payer")]
    public Payer Payer { get; set; }

    [JsonPropertyName("payment_source")]
    public PaymentSource? PaymentSource { get; set; }

    public string? PaymentDebugId { get; set; }
}
