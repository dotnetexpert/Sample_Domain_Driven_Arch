﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class PaymentInstruction
{
    [JsonPropertyName("disbursement_mode")]
    public string DisbursementMode { get; } = "INSTANT";

    [JsonPropertyName("platform_fees")]
    public List<PlatformFee> PaymentFees { get; set; } = new List<PlatformFee>();
}
