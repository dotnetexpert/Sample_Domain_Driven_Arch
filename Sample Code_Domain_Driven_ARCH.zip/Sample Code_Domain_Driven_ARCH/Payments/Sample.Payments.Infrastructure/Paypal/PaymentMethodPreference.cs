﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Infrastructure.Paypal;

public class PaymentMethodPreference : Enumeration<PaymentMethodPreference>
{
    public static readonly PaymentMethodPreference Unrestricted = new PaymentMethodPreference(1, "UNRESTRICTED");
    public static readonly PaymentMethodPreference ImmediatePaymentRequired = new PaymentMethodPreference(
        2,
        "IMMEDIATE_PAYMENT_REQUIRED"
    );

    private PaymentMethodPreference(int value, string name)
        : base(value, name) { }
}
