﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class PaymentTokenResponse
{
    [JsonPropertyName("customer")]
    public Customer Customer { get; set; }

    [JsonPropertyName("payment_tokens")]
    public List<PaymentToken> PaymentTokens { get; set; }

    [JsonPropertyName("links")]
    public List<Link> Links { get; set; }
}

public class Customer
{
    [JsonPropertyName("id")]
    public string Id { get; set; }

    [JsonPropertyName("merchant_customer_id")]
    public string MerchantCustomerId { get; set; }
}

public class PaymentToken
{
    [JsonPropertyName("id")]
    public string Id { get; set; }

    [JsonPropertyName("customer")]
    public Customer Customer { get; set; }

    [JsonPropertyName("payment_source")]
    public VaultPaymentSource PaymentSource { get; set; }

    [JsonPropertyName("links")]
    public List<Link> Links { get; set; }
}

public class VaultPaymentSource
{
    [JsonPropertyName("card")]
    public PaymentSourceCard Card { get; set; }
}

public class PaymentSourceCard
{
    [JsonPropertyName("name")]
    public string Name { get; set; }

    [JsonPropertyName("last_digits")]
    public string LastDigits { get; set; }

    [JsonPropertyName("brand")]
    public string Brand { get; set; }

    [JsonPropertyName("expiry")]
    public string Expiry { get; set; }

    [JsonPropertyName("billing_address")]
    public BillingAddress BillingAddress { get; set; }

    [JsonPropertyName("verification_status")]
    public string VerificationStatus { get; set; }

    [JsonPropertyName("verification")]
    public Verification Verification { get; set; }

    [JsonPropertyName("network_transaction_reference")]
    public NetworkTransactionReferenceResponse NetworkTransactionReference { get; set; }
}

public class BillingAddress
{
    [JsonPropertyName("postal_code")]
    public string PostalCode { get; set; }

    [JsonPropertyName("country_code")]
    public string CountryCode { get; set; }

    [JsonPropertyName("id")]
    public string Id { get; set; }
}

public class Verification
{
    [JsonPropertyName("network_transaction_id")]
    public string NetworkTransactionId { get; set; }

    [JsonPropertyName("time")]
    public string Time { get; set; }

    [JsonPropertyName("amount")]
    public Amount Amount { get; set; }

    [JsonPropertyName("processor_response")]
    public VerificationProcessorResponse ProcessorResponse { get; set; }
}

public class Amount
{
    [JsonPropertyName("currency_code")]
    public string CurrencyCode { get; set; }

    [JsonPropertyName("value")]
    public string Value { get; set; }
}

public class VerificationProcessorResponse
{
    [JsonPropertyName("avs_code")]
    public string AvsCode { get; set; }

    [JsonPropertyName("cvv_code")]
    public string CvvCode { get; set; }

    [JsonPropertyName("response_code")]
    public string ResponseCode { get; set; }
}

public class NetworkTransactionReferenceResponse
{
    [JsonPropertyName("id")]
    public string Id { get; set; }

    [JsonPropertyName("time")]
    public string Time { get; set; }
}

public class Link
{
    [JsonPropertyName("href")]
    public string Href { get; set; }

    [JsonPropertyName("rel")]
    public string Rel { get; set; }

    [JsonPropertyName("method")]
    public string Method { get; set; }

    [JsonPropertyName("encType")]
    public string EncType { get; set; }
}
