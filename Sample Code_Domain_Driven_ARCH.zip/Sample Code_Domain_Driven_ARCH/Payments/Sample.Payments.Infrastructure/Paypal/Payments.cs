﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class Payments
{
    [JsonPropertyName("captures")]
    public List<PaymentCapture> Captures { get; set; }
}
