﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class PaymentsSource
{
    [JsonPropertyName("card")]
    public Card card { get; set; }
}
