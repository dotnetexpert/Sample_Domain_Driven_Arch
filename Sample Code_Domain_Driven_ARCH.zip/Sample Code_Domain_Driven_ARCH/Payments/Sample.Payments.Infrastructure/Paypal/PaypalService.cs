﻿using System.Text;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using Sample.CrossCutting.Infrastructure.Models;
using Sample.Payments.Domain;
using Sample.Payments.Infrastructure.GiftCards;
using Sample.Payments.Infrastructure.PaypalOnboarding;

namespace Sample.Payments.Infrastructure.Paypal;

public class PaypalService : IPaypalService
{
    public PaymentSystem PaymentSystem => PaymentSystem.PayPal;
    private readonly ILogger<PaypalService> _logger;
    private readonly PaypalConfiguration _configuration;
    private readonly PaypalOnboardingConfiguration _onboardingConfiguration;

    public PaypalService(
        ILogger<PaypalService> logger,
        IOptions<PaypalConfiguration> configuration,
        IOptions<PaypalOnboardingConfiguration> onboardingConfiguration
    )
    {
        _logger = logger;
        _configuration = configuration.Value;
        _onboardingConfiguration = onboardingConfiguration.Value;
    }

    public async Task<AuthToken> GetAuthTokenAsync()
    {
        var client = new RestClient(_configuration.BaseUrl);
        var request = new RestRequest("/v1/oauth2/token", Method.Post);

        request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
        request.AddParameter("application/x-www-form-urlencoded", $"grant_type=client_credentials", ParameterType.RequestBody);

        var encodedAuthentication = Base64Encode($"{_configuration.ClientId}:{_configuration.ClientSecret}");

        request.AddHeader("Authorization", $"Basic {encodedAuthentication}");

        var response = await client.ExecuteAsync<AuthToken>(request);

        if (!response.IsSuccessStatusCode)
        {
            _logger.LogError($"Error authenticating to paypal with encodedAuthentication: {encodedAuthentication}");
            throw new Exception($"Error retrieving authentication token: {response.ErrorException.Message}");
        }

        return response.Data;
    }

    public string GetRefundAuthAssertion(string merchantAccountId)
    {
        var encodedHeader = Base64Encode("{\"alg\":\"none\"}");
        var encodedPayload = Base64Encode(
            "{\"iss\":\"" + _configuration.ClientId + "\",\"payer_id\":\"" + merchantAccountId + "\"}"
        );

        return $"{encodedHeader}.{encodedPayload}.";
    }

    public async Task<AuthToken> GetAuthTokenForOnboardingAsync()
    {
        var client = new RestClient(_onboardingConfiguration.BaseUrl);
        var request = new RestRequest("/v1/oauth2/token", Method.Post);

        request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
        request.AddParameter("application/x-www-form-urlencoded", $"grant_type=client_credentials", ParameterType.RequestBody);

        var encodedAuthentication = Base64Encode($"{_onboardingConfiguration.ClientId}:{_onboardingConfiguration.ClientSecret}");

        request.AddHeader("Authorization", $"Basic {encodedAuthentication}");

        var response = await client.ExecuteAsync<AuthToken>(request);

        if (!response.IsSuccessStatusCode)
        {
            _logger.LogError($"Error authenticating to paypal with encodedAuthentication: {encodedAuthentication}");
            throw new Exception($"Error retrieving authentication token: {response.ErrorException.Message}");
        }

        return response.Data;
    }

    public async Task<CreateOrderData> CreateOrderAsync(CreateOrderRequest createOrderRequest)
    {
        var authToken = await GetAuthTokenAsync();

        var client = new RestClient(_configuration.BaseUrl);
        var request = new RestRequest("/v2/checkout/orders", Method.Post);

        request.AddHeader("Authorization", $"Bearer {authToken.AccessToken}");
        request.AddHeader("Content-Type", "application/json");
        request.AddHeader("PayPal-Partner-Attribution-ID", _configuration.BN_Code);

        var paymentSource = new
        {
            paypal = new
            {
                experience_context = new
                {
                    brand_name = _configuration.BrandName,
                    payment_method_preference = PaymentMethodPreference.ImmediatePaymentRequired.Name,
                    landing_page = LandingPage.Login.Name,
                    shipping_preference = ShippingPreference.SetProvidedAddress.Name,
                    user_action = UserAction.PayNow.Name,
                    return_url = _configuration.ReturnUrl,
                    cancel_url = _configuration.CancelUrl,
                },
                name = createOrderRequest.PurchaseUnits.Select(n => n.Shipping.Name).First(),
                address = createOrderRequest.PurchaseUnits.Select(a => a.Shipping.Address).First(),
                phone = createOrderRequest.PurchaseUnits.Select(ph => ph.Shipping.PhoneNumber).First(),
            },
        };

        var requestBody = new
        {
            intent = createOrderRequest.Intent,
            purchase_units = createOrderRequest.PurchaseUnits.Select(pu =>
            {
                decimal subtotal = pu.Items.Sum(i => i.Quantity * i.UnitAmount.Amount);

                return new
                {
                    reference_id = pu.ReferenceId,
                    amount = pu.Amount,
                    payee = pu.Payee,
                    items = pu.Items.Select(i => new
                    {
                        name = i.ProductName,
                        quantity = i.Quantity,
                        url = i.Url,
                        unit_amount = new
                        {
                            value = Math.Round(i.UnitAmount.Amount, 2).ToString(),
                            currency_code = i.UnitAmount.Currency,
                        },
                    }),
                    shipping = new { address = pu.Shipping?.Address },
                    payment_instruction = new
                    {
                        platform_fees = new[]
                        {
                            new
                            {
                                amount = new { value = Math.Round(subtotal * .07m, 2), currency_code = pu.Amount.CurrencyCode },
                            },
                        },
                    },
                };
            }),
            payment_source = paymentSource,
        };

        request.AddJsonBody(requestBody);

        var paypalRequestId = Guid.NewGuid();

        request.AddHeader("PayPal-Request-Id", paypalRequestId);

        var response = await client.ExecuteAsync<CreateOrderData>(request);

        var result = new CreateOrderData
        {
            OrderId = response.Data.OrderId,
            Status = response.Data.Status,
            Token = authToken.AccessToken,
            Links = response.Data.Links,
        };

        return result;
    }

    public async Task<CreateGiftCardOrderResponse> BuyGiftCardAsync(BuyCardRequest createOrderRequest)
    {
        var authToken = await GetAuthTokenAsync();

        var client = new RestClient(_configuration.BaseUrl);
        var request = new RestRequest("/v2/checkout/orders", Method.Post);

        request.AddHeader("Authorization", $"Bearer {authToken.AccessToken}");
        request.AddHeader("Content-Type", "application/json");
        request.AddHeader("PayPal-Partner-Attribution-ID", _configuration.BN_Code);

        var paymentSource = new
        {
            paypal = new
            {
                experience_context = new
                {
                    brand_name = _configuration.BrandName,
                    payment_method_preference = PaymentMethodPreference.ImmediatePaymentRequired.Name,
                    landing_page = LandingPage.Login.Name,
                    user_action = UserAction.PayNow.Name,
                    return_url = _configuration.ReturnUrl,
                    cancel_url = _configuration.CancelUrl,
                },
            },
        };

        var requestBody = new
        {
            intent = createOrderRequest.Intent,
            purchase_units = createOrderRequest.PurchaseUnits.Select(pu => new
            {
                reference_id = pu.ReferenceId,
                payee = pu.Payee,
                amount = pu.Amount,
            }),
            payment_source = paymentSource,
            application_context = new { shipping_preference = "NO_SHIPPING" },
        };

        request.AddJsonBody(requestBody);

        var paypalRequestId = Guid.NewGuid();

        request.AddHeader("PayPal-Request-Id", paypalRequestId);

        var response = await client.ExecuteAsync<CreateOrderResponse>(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorMessage = $"Error creating an order: {response.ErrorException.Message}";
            _logger.LogError(errorMessage);
            throw new Exception(errorMessage);
        }

        var result = new CreateGiftCardOrderResponse(response.Data.Id, response.Data.Status, response.Data.Links);

        return result;
    }

    public async Task<CreateOrderResponse> ConsumeGiftCardAsync(BuyCardRequest createOrderRequest)
    {
        var authToken = await GetAuthTokenAsync();

        var client = new RestClient(_configuration.BaseUrl);
        var request = new RestRequest("/v2/checkout/orders", Method.Post);

        request.AddHeader("Authorization", $"Bearer {authToken.AccessToken}");
        request.AddHeader("Content-Type", "application/json");
        request.AddHeader("PayPal-Partner-Attribution-ID", _configuration.BN_Code);

        var paymentSource = new PaymentsSource
        {
            card = new Card { vault_id = createOrderRequest.PaymentsSource[0].card.vault_id },
        };

        var requestBody = new
        {
            intent = createOrderRequest.Intent,
            purchase_units = createOrderRequest.PurchaseUnits.Select(pu => new
            {
                reference_id = pu.ReferenceId,
                payee = pu.Payee,
                amount = pu.Amount,
            }),
            payment_source = paymentSource,
        };

        request.AddJsonBody(requestBody);

        var paypalRequestId = Guid.NewGuid();

        request.AddHeader("PayPal-Request-Id", paypalRequestId);

        var response = await client.ExecuteAsync<CreateOrderResponse>(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorMessage = $"Error creating an order: {response.ErrorException.Message}";
            _logger.LogError(errorMessage);
            throw new Exception(errorMessage);
        }

        var paypalDebugId = response
            .Headers.FirstOrDefault(header => header.Name.ToLower().Contains("paypal-debug-id"))
            ?.Value?.ToString();

        response.Data.PaymentDebugId = paypalDebugId;

        return response.Data;
    }

    public async Task<string> VaultSetupToken(VaultSetupRequest createVaultRequest)
    {
        var authToken = await GetAuthTokenAsync();

        var client = new RestClient(_configuration.BaseUrl);
        var request = new RestRequest("/v3/vault/setup-tokens", Method.Post);

        request.AddHeader("Authorization", $"Bearer {authToken.AccessToken}");
        request.AddHeader("Content-Type", "application/json");

        var requestBody = new { customer = createVaultRequest.Customer, payment_source = createVaultRequest.PaymentSource };

        request.AddJsonBody(requestBody);

        var paypalRequestId = Guid.NewGuid();

        request.AddHeader("PayPal-Request-Id", paypalRequestId);
        request.AddHeader("PayPal-Partner-Attribution-ID", _configuration.BN_Code);

        var response = await client.ExecuteAsync<CreateVaultSetupResponse>(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorMessage = $"Error in creating setup-token: {response.ErrorException?.Message}";
            _logger.LogError(errorMessage);
            throw new Exception(errorMessage);
        }

        var responseData = JsonConvert.DeserializeObject<CreateVaultSetupResponse>(response.Content);

        if (responseData == null)
        {
            var errorMessage = $"Deserialized response data is null.";
            _logger.LogError(errorMessage);
            throw new Exception(errorMessage);
        }

        var creatVaultPaymentRequest = await GetPaymentTokensAsync(responseData.Customer.Id);

        if (creatVaultPaymentRequest?.PaymentTokens == null || !creatVaultPaymentRequest.PaymentTokens.Any())
        {
            var errorMessage = "PaymentTokenId not found or payment tokens list is null.";
            _logger.LogError(errorMessage);
            throw new Exception(errorMessage);
        }

        var paymentToken = creatVaultPaymentRequest.PaymentTokens.FirstOrDefault()?.Id;

        if (paymentToken == null)
        {
            var errorMessage = "PaymentTokenId not found.";
            _logger.LogError(errorMessage);
            throw new Exception(errorMessage);
        }

        return paymentToken;
    }

    public async Task<PaymentTokenResponse> GetPaymentTokensAsync(string customerId)
    {
        var authToken = await GetAuthTokenAsync();

        var client = new RestClient(_configuration.BaseUrl);
        var request = new RestRequest($"/v3/vault/payment-tokens?customer_id={customerId}", Method.Get);

        request.AddHeader("Authorization", $"Bearer {authToken.AccessToken}");

        var response = await client.ExecuteAsync<PaymentTokenResponse>(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorMessage = $"Error in retrieving payment tokens: {response.ErrorException.Message}";
            _logger.LogError(errorMessage);
            throw new Exception(errorMessage);
        }

        var responseData = System.Text.Json.JsonSerializer.Deserialize<PaymentTokenResponse>(response.Content);

        if (responseData == null)
        {
            var errorMessage = $"Deserialized response data is null.: {response.ErrorException.Message}";
            _logger.LogError(errorMessage);
            throw new Exception("Deserialized response data is null.");
        }

        return responseData;
    }

    public async Task<GetOrderDetailsResponse> GetOrderDetails(string orderId)
    {
        var authToken = await GetAuthTokenAsync();
        var client = new RestClient(_configuration.BaseUrl);
        var request = new RestRequest($"/v2/checkout/orders/{orderId}", Method.Get);

        request.AddHeader("Authorization", $"Bearer {authToken.AccessToken}");
        request.AddHeader("Content-Type", "application/json");
        request.AddHeader("PayPal-Partner-Attribution-ID", _configuration.BN_Code);

        var response = await client.ExecuteAsync<GetOrderDetailsResponse>(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorMessage = $"Error retrieving order with id {orderId}: {response.ErrorException.Message}";
            _logger.LogError(errorMessage);
            throw new Exception(errorMessage);
        }

        return response.Data;
    }

    public async Task<PaymentCaptureResponse> CapturePaymentAsync(string orderId)
    {
        var authToken = await GetAuthTokenAsync();
        var client = new RestClient(_configuration.BaseUrl);
        var request = new RestRequest($"/v2/checkout/orders/{orderId}/capture", Method.Post);

        // used for failed payment testing
        //var mockApplicationCode = new { mock_application_codes = "DUPLICATE_INVOICE_ID" };

        request.AddHeader("Authorization", $"Bearer {authToken.AccessToken}");
        request.AddHeader("Content-Type", "application/json");
        //request.AddHeader("PayPal-Mock-Response", JsonConvert.SerializeObject(mockApplicationCode));
        request.AddHeader("PayPal-Partner-Attribution-ID", _configuration.BN_Code);

        var response = await client.ExecuteAsync<PaymentCaptureResponse>(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorMessage = $"Error capturing authorized payment with id {orderId}: {response.ErrorException.Message}";
            _logger.LogError(errorMessage);
            throw new Exception(errorMessage);
        }

        var paypalDebugId = response
            .Headers.FirstOrDefault(header => header.Name.ToLower().Contains("paypal-debug-id"))
            ?.Value?.ToString();

        response.Data.PaymentDebugId = paypalDebugId;

        return response.Data;
    }

    public async Task<RefundPaymentResponse> RefundPaymentAsync(string captureId, RefundRequest refundRequest)
    {
        var client = new RestClient(_configuration.BaseUrl);
        var request = new RestRequest($"/v2/payments/captures/{captureId}/refund", Method.Post);
        var authToken = await GetAuthTokenAsync();

        request.AddHeader("Authorization", $"Bearer {authToken.AccessToken}");
        request.AddHeader("Content-Type", "application/json");
        request.AddHeader("PayPal-Request-Id", Guid.NewGuid().ToString());
        request.AddHeader("PayPal-Auth-Assertion", GetRefundAuthAssertion(refundRequest.MerchantAccountId));
        request.AddHeader("PayPal-Partner-Attribution-ID", _configuration.BN_Code);

        request.AddBody(refundRequest);

        var response = await client.ExecuteAsync<RefundPaymentResponse>(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorMessage = $"Error refunding captured payment with id {captureId}: {response.ErrorException.Message}";
            _logger.LogError(errorMessage);
            throw new Exception(errorMessage);
        }

        return response.Data;
    }

    public async Task<AuthorizePaymentResponse> AuthorizePaymentAsync(string orderId)
    {
        var client = new RestClient(_configuration.BaseUrl);
        var request = new RestRequest($"/v2/checkout/orders/{orderId}/authorize", Method.Post);
        var authToken = await GetAuthTokenAsync();

        request.AddHeader("Authorization", $"Bearer {authToken.AccessToken}");
        request.AddHeader("Content-Type", "application/json");
        request.AddHeader("PayPal-Request-Id", Guid.NewGuid().ToString());
        request.AddHeader("PayPal-Partner-Attribution-ID", _configuration.BN_Code);

        var response = await client.ExecuteAsync<AuthorizePaymentResponse>(request);

        if (!response.IsSuccessStatusCode)
        {
            var errorMessage = $"Error authorizing payment for order id {orderId}: {response.ErrorException.Message}";
            _logger.LogError(errorMessage);
            throw new Exception(errorMessage);
        }

        return response.Data;
    }

    public static string Base64Encode(string plainText)
    {
        var plainTextBytes = Encoding.UTF8.GetBytes(plainText);

        return Convert.ToBase64String(plainTextBytes);
    }

    public async Task<List<Links>> PartnerOnboardingAsync(Guid trackingId)
    {
        var authToken = await GetAuthTokenForOnboardingAsync();
        var client = new RestClient(_onboardingConfiguration.BaseUrl);
        var request = new RestRequest("/v2/customer/partner-referrals", Method.Post);
        request.AddHeader("Authorization", $"Bearer {authToken.AccessToken}");
        request.AddHeader("Content-Type", "application/json");
        request.AddHeader("PayPal-Partner-Attribution-ID", _configuration.BN_Code);

        var requestBody = new
        {
            operations = new[]
            {
                new
                {
                    operation = "API_INTEGRATION",
                    api_integration_preference = new
                    {
                        rest_api_integration = new
                        {
                            integration_type = "THIRD_PARTY",
                            third_party_details = new
                            {
                                features = new[] { "PAYMENT", "REFUND", "PARTNER_FEE", "ACCESS_MERCHANT_INFORMATION" },
                            },
                        },
                    },
                },
            },
            products = new[] { "EXPRESS_CHECKOUT" },
            tracking_id = trackingId,
            legal_consents = new[] { new { type = "SHARE_DATA_CONSENT", granted = true } },
        };

        request.AddJsonBody(requestBody);

        var response = await client.ExecuteAsync<MerchantOnboardingResponse>(request);

        if (!response.IsSuccessful)
        {
            var errorMessage = $"Error creating an order: {response.ErrorMessage}";
            _logger.LogError(errorMessage);
            throw new Exception(errorMessage);
        }

        return response.Data.Links;
    }

    public async Task<bool> VerifyEvent(string json, IHeaderDictionary headerDictionary)
    {
        var authAlgo = GetHeaderValue(headerDictionary, "PAYPAL-AUTH-ALGO");
        var certUrl = GetHeaderValue(headerDictionary, "PAYPAL-CERT-URL");
        var transmissionId = GetHeaderValue(headerDictionary, "PAYPAL-TRANSMISSION-ID");
        var transmissionSig = GetHeaderValue(headerDictionary, "PAYPAL-TRANSMISSION-SIG");
        var transmissionTime = GetHeaderValue(headerDictionary, "PAYPAL-TRANSMISSION-TIME");

        var paypalVerifyRequestJsonString =
            $@"{{
           ""auth_algo"": ""{authAlgo}"",
           ""cert_url"": ""{certUrl}"",
           ""transmission_id"": ""{transmissionId}"",
           ""transmission_sig"": ""{transmissionSig}"",
           ""transmission_time"": ""{transmissionTime}"",
           ""webhook_id"": ""{_onboardingConfiguration.MerchantOnboardingWebhookId}"",
           ""webhook_event"": {json}
        }}";

        var content = new StringContent(paypalVerifyRequestJsonString, Encoding.UTF8, "application/json");

        var authToken = await GetAuthTokenAsync();
        var client = new RestClient(_onboardingConfiguration.BaseUrl);
        var request = new RestRequest("/v1/notifications/verify-webhook-signature", Method.Post);
        request.AddHeader("Authorization", $"Bearer {authToken.AccessToken}");
        request.AddParameter("application/json", paypalVerifyRequestJsonString, ParameterType.RequestBody);
        var response = await client.ExecuteAsync(request);
        var verifyWebhookResponse = JsonConvert.DeserializeObject<WebHookVerificationResponse>(response.Content);

        return verifyWebhookResponse.verification_status == "SUCCESS";
    }

    string GetHeaderValue(IHeaderDictionary dictionary, string key)
    {
        if (dictionary.ContainsKey(key))
            return dictionary[key].FirstOrDefault();

        foreach (var header in dictionary)
        {
            if (header.Key.ToLower().Contains(key.ToLower()))
                return header.Value.FirstOrDefault();
        }

        return "";
    }

    public async Task<string> GetMerchantId(Guid trackingId)
    {
        var authToken = await GetAuthTokenAsync();
        var client = new RestClient(_onboardingConfiguration.BaseUrl);

        var request = new RestRequest(
            $"/v1/customer/partners/{_onboardingConfiguration.PartnerMerchantId}/merchant-integrations",
            Method.Get
        );

        request.AddHeader("Authorization", $"Bearer {authToken.AccessToken}");
        request.AddHeader("Content-Type", "application/json");
        request.AddHeader("PayPal-Partner-Attribution-ID", _configuration.BN_Code);

        request.AddParameter("tracking_id", trackingId.ToString());

        var response = await client.ExecuteAsync(request);

        if (!response.IsSuccessful)
        {
            throw new Exception($"Error: {response.StatusCode} - {response.ErrorMessage}");
        }

        var merchantId = GetMerchantIdFromResponse(response.Content);

        return merchantId;
    }

    private string GetMerchantIdFromResponse(string responseContent)
    {
        dynamic jsonResponse = JsonConvert.DeserializeObject(responseContent);
        string merchantId = jsonResponse["merchant_id"];

        return merchantId;
    }

    public async Task<bool> CheckMerchantIntegration(string sellerMerchantId)
    {
        var authToken = await GetAuthTokenForOnboardingAsync();

        var client = new RestClient(_onboardingConfiguration.BaseUrl);
        var request = new RestRequest(
            $"/v1/customer/partners/{_onboardingConfiguration.PartnerMerchantId}/merchant-integrations/{sellerMerchantId}",
            Method.Get
        );

        request.AddHeader("Authorization", $"Bearer {authToken.AccessToken}");
        request.AddHeader("Content-Type", "application/json");
        request.AddHeader("PayPal-Partner-Attribution-ID", _configuration.BN_Code);

        var response = await client.ExecuteAsync(request);

        if (!response.IsSuccessful)
        {
            throw new Exception($"Error: {response.StatusCode} - {response.ErrorMessage}");
        }

        return CheckIntegrationConditions(response.Content);
    }

    private bool CheckIntegrationConditions(string responseContent)
    {
        JObject jsonResponse = JObject.Parse(responseContent);

        bool paymentsReceivable = (bool)jsonResponse["payments_receivable"];
        bool primaryEmailConfirmed = (bool)jsonResponse["primary_email_confirmed"];
        JArray oauthIntegrations = (JArray)jsonResponse["oauth_integrations"];

        return paymentsReceivable && primaryEmailConfirmed && oauthIntegrations != null && oauthIntegrations.Count > 0;
    }
}
