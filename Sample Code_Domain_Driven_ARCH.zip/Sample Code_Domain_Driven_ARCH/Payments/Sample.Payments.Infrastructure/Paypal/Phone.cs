﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class Phone
{
    [JsonPropertyName("phone_type")]
    public string PhoneType { get; } = "MOBILE";

    [JsonPropertyName("phone_number")]
    public PhoneNumber PhoneNumber { get; set; }
}
