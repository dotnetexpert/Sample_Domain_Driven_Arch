﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class PhoneNumber
{
    [JsonPropertyName("national_number")]
    public string NationalNumber { get; set; }
}
