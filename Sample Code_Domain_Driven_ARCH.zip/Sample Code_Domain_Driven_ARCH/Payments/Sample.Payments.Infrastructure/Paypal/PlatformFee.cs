﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class PlatformFee
{
    [JsonPropertyName("amount")]
    public Money Amount { get; set; }
}
