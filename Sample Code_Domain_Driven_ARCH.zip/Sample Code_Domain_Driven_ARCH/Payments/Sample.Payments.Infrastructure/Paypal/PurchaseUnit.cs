﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class PurchaseUnit
{
    [JsonPropertyName("reference_id")]
    public string ReferenceId { get; set; }

    [JsonPropertyName("amount")]
    public Money Amount { get; set; }

    [JsonPropertyName("soft_descriptor")]
    public string SoftDescriptor { get; set; }

    [JsonPropertyName("description")]
    public string? Description { get; set; }

    [JsonPropertyName("payee")]
    public Payee Payee { get; set; }

    [JsonPropertyName("shipping")]
    public Shipping Shipping { get; set; }

    [JsonPropertyName("items")]
    public List<Items> Items { get; set; }

    [JsonPropertyName("payment_instruction")]
    public PaymentInstruction? PaymentInstruction { get; set; }

    [JsonPropertyName("payments")]
    public Payments Payments { get; set; }
}
