﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class PurchaseUnitResponse
{
    [JsonPropertyName("reference_id")]
    public string ReferenceId { get; set; }
}
