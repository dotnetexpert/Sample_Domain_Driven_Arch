﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class RefundPaymentResponse : ErrorResponse
{
    [JsonPropertyName("id")]
    public string Id { get; set; }

    [JsonPropertyName("amount")]
    public Money Amount { get; set; }

    [JsonPropertyName("status")]
    public string Status { get; set; }

    [JsonPropertyName("note")]
    public string Note { get; set; }

    [JsonPropertyName("seller_payable_breakdown")]
    public SellerPayableBreakdown SellerPayableBreakdown { get; set; }

    [JsonPropertyName("invoice_id")]
    public string InvoiceId { get; set; }

    [JsonPropertyName("create_time")]
    public DateTime CreateTime { get; set; }

    [JsonPropertyName("update_time")]
    public DateTime UpdateTime { get; set; }
}
