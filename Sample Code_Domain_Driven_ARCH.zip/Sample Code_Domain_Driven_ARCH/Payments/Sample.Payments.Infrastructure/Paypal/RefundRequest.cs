﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class RefundRequest
{
    [JsonPropertyName("amount")]
    public Money Amount { get; set; }

    [JsonPropertyName("invoice_id")]
    public string InvoiceId { get; set; }

    [JsonPropertyName("note_to_payer")]
    public string NoteToPayor { get; set; }

    [JsonIgnore]
    public string MerchantAccountId { get; set; }
}
