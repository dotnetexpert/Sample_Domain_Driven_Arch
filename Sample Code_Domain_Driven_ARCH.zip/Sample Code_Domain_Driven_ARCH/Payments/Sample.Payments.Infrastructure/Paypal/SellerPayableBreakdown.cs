﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class SellerPayableBreakdown
{
    [JsonPropertyName("gross_amount")]
    public Money GrossAmount { get; set; }

    [JsonPropertyName("paypal_fee")]
    public Money PaypalFee { get; set; }

    [JsonPropertyName("platform_fees")]
    public List<Money> PlatformFees { get; set; } = new List<Money>();

    [JsonPropertyName("net_amount")]
    public Money NetAmount { get; set; }

    [JsonPropertyName("total_refunded_amount")]
    public Money TotalRefundedAmount { get; set; }
}
