﻿using System.Text.Json.Serialization;

namespace Sample.Payments.Infrastructure.Paypal;

public class SellerReceivableBreakdown
{
    [JsonPropertyName("gross_amount")]
    public Money GrossAmount { get; set; }

    [JsonPropertyName("paypal_fee")]
    public Money PaypalFee { get; set; }

    [JsonPropertyName("net_amount")]
    public Money NetAmount { get; set; }
}
