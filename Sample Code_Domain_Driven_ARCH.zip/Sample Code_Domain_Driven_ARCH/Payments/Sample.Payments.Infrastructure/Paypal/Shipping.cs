﻿using System.Text.Json.Serialization;
using Sample.Payments.Domain;

namespace Sample.Payments.Infrastructure.Paypal;

public class Shipping
{
    [JsonPropertyName("type")]
    public string Type { get; } = "SHIPPING";

    [JsonPropertyName("name")]
    public Name Name { get; set; }

    [JsonPropertyName("address")]
    public Address Address { get; set; }

    [JsonPropertyName("phone_number")]
    public Phone PhoneNumber { get; set; }
}
