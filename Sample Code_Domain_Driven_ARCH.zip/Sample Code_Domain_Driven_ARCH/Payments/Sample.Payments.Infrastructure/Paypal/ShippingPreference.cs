﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Infrastructure.Paypal;

public class ShippingPreference : Enumeration<ShippingPreference>
{
    public static readonly ShippingPreference GetFromFile = new ShippingPreference(1, "GET_FROM_FILE");
    public static readonly ShippingPreference NoShipping = new ShippingPreference(2, "NO_SHIPPING");
    public static readonly ShippingPreference SetProvidedAddress = new ShippingPreference(2, "SET_PROVIDED_ADDRESS");

    private ShippingPreference(int value, string name)
        : base(value, name) { }
}
