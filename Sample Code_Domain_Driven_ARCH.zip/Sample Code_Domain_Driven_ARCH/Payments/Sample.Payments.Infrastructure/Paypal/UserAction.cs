﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Infrastructure.Paypal;

public class UserAction : Enumeration<UserAction>
{
    public static readonly UserAction Continue = new UserAction(1, "CONTINUE");
    public static readonly UserAction PayNow = new UserAction(2, "PAY_NOW");

    private UserAction(int value, string name)
        : base(value, name) { }
}
