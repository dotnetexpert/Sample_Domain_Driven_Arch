﻿using Sample.Payments.Domain.Core;

namespace Sample.Payments.Infrastructure.Paypal;

public class VerificationMethod : Enumeration<VerificationMethod>
{
    public static readonly VerificationMethod ScsWhenRequired = new VerificationMethod(1, "SCA_WHEN_REQUIRED");
    public static readonly VerificationMethod ScsAlways = new VerificationMethod(2, "SCA_ALWAYS");

    private VerificationMethod(int value, string name)
        : base(value, name) { }
}
