﻿using Microsoft.EntityFrameworkCore;
using Sample.Payments.Domain;
using Sample.Payments.Infrastructure.Data;

namespace Sample.Payments.Infrastructure.Repositories;

public class MerchantRepository : IMerchantRepository
{
    private readonly PaymentsContext _context;

    public MerchantRepository(PaymentsContext context)
    {
        _context = context;
    }

    public async Task<Merchant> GetByPaypalAccountId(string merchantPaypalAccountId)
    {
        var merchant = await _context
            .Merchants.Include(merchant => merchant.MerchantAccounts)
            .ThenInclude(merchantAccount => merchantAccount.MerchantConfiguration)
            .FirstOrDefaultAsync(merchant =>
                merchant.MerchantAccounts.Any(merchantAccount =>
                    merchantAccount.MerchantConfiguration.AccountId == merchantPaypalAccountId
                )
            );

        return merchant;
    }

    public async Task SaveChangesAsync()
    {
        await _context.SaveChangesAsync();
    }
}
