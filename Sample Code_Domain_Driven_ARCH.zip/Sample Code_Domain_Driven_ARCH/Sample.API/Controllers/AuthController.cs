﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Sample.API.Providers;
using Sample.Security.Application.Register;
using Sample.Security.Domain.Security;

namespace Sample.API.Controllers;

[ApiController]
[Route("api/security")]
public class AuthController : Controller
{
    private readonly IMediator _mediator;
    private readonly IUserProvider _userProvider;

    public AuthController(IMediator mediator)
    {
        _mediator = mediator;
    }

    [HttpPost]
    [Route("identities")]
    public async Task<IActionResult> Register([FromBody] AuthRequest request)
    {
        var command = new IdentityVerifyOrRegisterCommand(
            request.Sub,
            new IdentityConfigurationData(
                Name: request.Name,
                Email: request.Email,
                EmailVerified: request.EmailVerified,
                Picture: request.Picture,
                Sub: request.Sub
            )
        );

        var result = await _mediator.Send(command);

        return Ok(result.Value);
    }
}
