﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Sample.API.Providers;
using Sample.API.Requests.Customers;

namespace Sample.API.Controllers;

[ApiController]
[Route("api/customers")]
[Authorize]
public class CustomerController : ControllerBase
{
    private readonly IMediator _mediator;
    private readonly IUserProvider _userProvider;

    public CustomerController(IMediator mediator, IUserProvider userProvider)
    {
        _mediator = mediator;
        _userProvider = userProvider;
    }

    #region Customer

    [HttpGet("profile")]
    public async Task<IActionResult> GetCustomerProfile(CancellationToken cancellationToken)
    {
        var customerId = _userProvider.Id;

        var result = await _mediator.Send(new GetProfileQuery(customerId), cancellationToken);

        if (result.IsFailure)
        {
            return NotFound("Customer not found");
        }

        return Ok(result.Value);
    }

    [HttpPatch("profile")]
    public async Task<IActionResult> SetCustomerProfile([FromBody] SetProfileRequest request, CancellationToken cancellationToken)
    {
        var customerId = _userProvider.Id;
        var command = new SaveProfileCommand(
            new CustomerId(customerId),
            new ProfileData(
                null, // not setting email here
                request.FirstName,
                request.LastName,
                request.PhoneNumber,
                request.ShippingAddress,
                request.BillingAddress
            )
        );

        var updatedRecord = await _mediator.Send(command, cancellationToken);

        return Ok(updatedRecord);
    }

    #endregion

    #region Cart

    [HttpGet("cart/summary")]
    public async Task<ActionResult<CartSummary>> GetCartAsync(CancellationToken cancellationToken)
    {
        var orderSummaryQuery = new GetCartItemsQuery(new CustomerId(_userProvider.Id));
        var orderSummary = await _mediator.Send(orderSummaryQuery, cancellationToken);

        return Ok(orderSummary);
    }

    [HttpDelete("cart")]
    public async Task<IActionResult> RemoveAllCartItemsAsync(CancellationToken cancellationToken)
    {
        var command = new RemoveAllItemsFromCartCommand(new CustomerId(_userProvider.Id));

        await _mediator.Send(command, cancellationToken);
        return Ok();
    }

    #endregion
}
