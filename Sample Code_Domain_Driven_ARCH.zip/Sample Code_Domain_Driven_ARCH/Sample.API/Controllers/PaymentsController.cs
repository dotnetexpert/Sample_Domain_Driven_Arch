﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Sample.API.Providers;
using Address = Sample.Payments.Domain.Core.Address;
using Money = Sample.Payments.Domain.Core.Money;

namespace Sample.API.Controllers;

[ApiController]
[Route("api/payments")]
[Authorize]
public class PaymentsController : ControllerBase
{
    private readonly IUserProvider _userProvider;
    private readonly IMediator _mediator;
    private readonly ILogger<PaymentsController> _logger;

    public PaymentsController(
        IUserProvider userProvider,
        IPaypalService paypalService,
        IMediator mediator,
        ILogger<PaymentsController> logger,
        IOptions<PaypalConfiguration> configuration
    )
    {
        _userProvider = userProvider;
        _paypalService = paypalService;
        _mediator = mediator;
        _logger = logger;
        _configuration = configuration.Value;
    }

    #region Order

    [HttpPost("orders")]
    public async Task<IActionResult> CreateOrder(
        [FromBody] OrderCreationRequest orderCreationRequest,
        CancellationToken cancellationToken
    )
    {
        var command = new CreatePaypalOrderCommand(new CustomerId(_userProvider.Id), orderCreationRequest);

        var response = await _mediator.Send(command, cancellationToken);

        return Ok(response);
    }

    #endregion
}
