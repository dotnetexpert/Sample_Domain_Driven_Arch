﻿using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using Sample.API.Providers;

namespace Sample.API.Controllers
{
    [ApiController]
    [Authorize]
    [Route("api/stores")]
    public class StoreController : Controller
    {
        private readonly IMediator _mediator;
        private readonly IEventBus _eventBus;

        public StoreController(IMediator mediator, IUserProvider userProvider)
        {
            _mediator = mediator;
            _userProvider = userProvider;
        }

        #region Store

        [HttpGet("profile")]
        public async Task<ActionResult> GetStoreProfile(CancellationToken cancellationToken)
        {
            var query = new GetProfileQuery(new StoreId(_userProvider.StoreId));
            var profileData = await _mediator.Send(query, cancellationToken);

            return Ok(profileData);
        }

        #endregion
    }
}
