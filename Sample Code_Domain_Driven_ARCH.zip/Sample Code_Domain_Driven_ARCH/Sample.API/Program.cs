using System.Security.Claims;
using Amazon;
using Amazon.SecretsManager;
using Sample.API.Authorization;
using Sample.API.Middleware;
using Sample.CrossCutting.Infrastructure.Http;
using Sample.CrossCutting.Infrastructure.Models;
using Sample.CrossCutting.Infrastructure.Providers;
using Sample.CrossDomain.Application.Payments.CreatePaypalOrder;
using Sample.Customers.Application.OrderHandler;
using Sample.Customers.Infrastructure.Data;
using Sample.Customers.Infrastructure.Repository;
using Sample.Orders.Application.Consumers;
using Sample.Orders.Infrastructure.Data;
using Sample.Payments.Domain;
using Sample.Payments.Infrastructure.Data;
using Sample.Payments.Infrastructure.Repositories;
using Sample.Security.Application.Register;
using Sample.Security.Domain.Security;
using Sample.Security.Infrastructure.Data;
using Sample.Security.Infrastructure.Repositories;
using Sample.Stores.Application;
using Sample.Stores.Application.Behaviors;
using Sample.Stores.Application.Created;
using Sample.Stores.Application.Customers;
using Sample.Stores.Application.Handshake;
using Sample.Stores.Application.Merchant;
using Sample.Stores.Application.Messages;
using Sample.Stores.Application.Orders;
using Sample.Stores.Application.Profile;
using Sample.Stores.Application.Refunds;
using Sample.Stores.Application.Services;
using Sample.Stores.Application.ShippingConfiguration.Update;
using Sample.Stores.Application.ShippingOptions;
using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Interfaces.Services;
using Sample.Stores.Domain.Stores;
using Sample.Stores.Infrastructure.Data;
using Sample.Stores.Infrastructure.Repositories;
using MassTransit;
using MediatR;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection.Extensions;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using SendGrid;
using Serilog;
using Serilog.Filters;
using Swashbuckle.AspNetCore.SwaggerGen;

var builder = WebApplication.CreateBuilder(args);

builder
    .Configuration.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true)
    .AddJsonFile($"appsettings.{builder.Environment.EnvironmentName}.json", optional: true, reloadOnChange: true);

builder.Services.AddMemoryCache();
builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();

builder.Services.AddDefaultAWSOptions(builder.Configuration.GetAWSOptions());
builder.Services.AddAWSService<IAmazonSecretsManager>();

if (builder.Environment.IsDevelopment())
{
    // use regular appSettings files
}
else
{
    builder.Configuration.AddSecretsManager(
        configurator: config =>
        {
            config.SecretFilter = record => record.Name.StartsWith($"{builder.Environment.EnvironmentName}/heavily-played/");
            config.KeyGenerator = (secret, name) =>
                name.Replace($"{builder.Environment.EnvironmentName}/heavily-played/", "").Replace("__", ":");
        },
        region: RegionEndpoint.USEast1
    );
}

// Logging
builder.Host.UseSerilog(
    (context, configuration) =>
    {
        configuration
            .ReadFrom.Configuration(context.Configuration)
            .Filter.ByExcluding(Matching.FromSource("Microsoft.EntityFrameworkCore"));
    }
);

builder.Services.PostConfigure<ApiBehaviorOptions>(options =>
{
    var builtInFactory = options.InvalidModelStateResponseFactory;

    options.InvalidModelStateResponseFactory = context =>
    {
        var logger = context.HttpContext.RequestServices.GetRequiredService<ILogger<Program>>();

        var errors = context.ModelState.Values.SelectMany(v => v.Errors);

        foreach (var error in errors)
        {
            logger.LogError($"Error found executing request: {error.ErrorMessage}");

            if (error.Exception != null)
            {
                logger.LogError($"Error found executing request: {error.Exception.Message}");
            }
        }

        return builtInFactory(context);
    };
});

// App Settings Options
builder.Services.AddOptions();
builder.Services.Configure<GlobalShippingConfiguration>(
    builder.Configuration.GetSection(key: nameof(GlobalShippingConfiguration))
);
);
builder.Services.Configure<DefaultShippingOptionsConfiguration>(
    builder.Configuration.GetSection(key: nameof(DefaultShippingOptionsConfiguration))
);
builder.Services.Configure<ShippingCountriesConfiguration>(
    builder.Configuration.GetSection(key: nameof(ShippingCountriesConfiguration))
);
builder.Services.Configure<CountryCodesConfiguration>(builder.Configuration.GetSection(key: nameof(CountryCodesConfiguration)));
builder.Services.Configure<SampleBillingAddressConfiguration>(
    builder.Configuration.GetSection(key: nameof(SampleBillingAddressConfiguration))
);
builder.Services.Configure<VaultConfiguration>(builder.Configuration.GetSection(key: nameof(VaultConfiguration)));

builder.Services.TryAddSingleton<IHttpContextAccessor, HttpContextAccessor>();

var domain = $"https://{builder.Configuration["Auth0:Domain"]}";

builder.Host.ConfigureServices(
    (services) =>
        services
            .AddAuthentication(JwtBearerDefaults.AuthenticationScheme)
            .AddJwtBearer(options =>
            {
                var audience = "https://hello-world.example.com";

                options.Authority = domain;
                options.Audience = builder.Configuration["Auth0:Audience"];
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateAudience = true,
                    ValidateIssuerSigningKey = true,
                    NameClaimType = ClaimTypes.NameIdentifier,
                };
            })
);

// Authorization
builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("read:stores", policy => policy.Requirements.Add(new HasScopeRequirement("read:stores", domain)));
    options.AddPolicy("write:stores", policy => policy.Requirements.Add(new HasScopeRequirement("write:stores", domain)));
});

// Entity Framework
builder.Services.AddDbContext<StoreContext>(build =>
    build.UseNpgsql(builder.Configuration.GetConnectionString("StoresConnectionString"))
);

builder.Services.AddDbContext<PaymentsContext>(build =>
    build.UseNpgsql(builder.Configuration.GetConnectionString("PaymentsConnectionString"))
);

builder.Services.AddDbContext<OrderContext>(build =>
    build.UseNpgsql(builder.Configuration.GetConnectionString("OrdersConnectionString"))
);

builder.Services.AddDbContext<CustomerContext>(build =>
    build.UseNpgsql(builder.Configuration.GetConnectionString("CustomersConnectionString"))
);

builder.Services.AddDbContext<SecurityContext>(build =>
    build.UseNpgsql(builder.Configuration.GetConnectionString("SecurityConnectionString"))
);



builder.Services.AddCors();

// Configure SendGrid Email
builder.Services.AddScoped<ISendGridClient>(_ =>
{
    var apiKey = builder.Configuration["SendGrid:SendGridApiKey"];
    return new SendGridClient(apiKey);
});

// Options
builder.Services.Configure<Auth0Configuration>(builder.Configuration.GetSection("Auth0"));
builder.Services.Configure<PaypalConfiguration>(builder.Configuration.GetSection("Paypal"));
builder.Services.Configure<PaypalOnboardingConfiguration>(builder.Configuration.GetSection("PaypalOnboarding"));
builder.Services.Configure<DefaultShippingOptionsConfiguration>(builder.Configuration.GetSection("DefaultShippingOptions"));
builder.Services.Configure<ShippingCountriesConfiguration>(builder.Configuration.GetSection("ShippingCountries"));
builder.Services.Configure<CountryCodesConfiguration>(builder.Configuration.GetSection("CountryCodes"));
);
builder.Services.Configure<VaultConfiguration>(builder.Configuration.GetSection("VaultConfiguration"));
builder.Services.Configure<Sample.Catalog.Domain.Products.ProductVariantConfiguration>(
    builder.Configuration.GetSection("ProductVariantConfiguration")
);
builder.Services.Configure<ProductVariantConfiguration>(builder.Configuration.GetSection("ProductVariantConfiguration"));

// ElasticMQ


builder.Services.AddMassTransit(busConfigurator =>
{
    busConfigurator.SetEndpointNameFormatter(new KebabCaseEndpointNameFormatter(prefix: builder.Environment.EnvironmentName));

    busConfigurator.AddConsumers(typeof(IssuePartialRefundCompletedEventHandler).Assembly);
    busConfigurator.AddConsumers(typeof(CustomerOrderMessageEventHandler).Assembly);
    busConfigurator.AddConsumers(typeof(StoreCreatedEventHandler).Assembly);
    busConfigurator.AddConsumers(typeof(CategoryCreatedEventConsumer).Assembly);
    busConfigurator.AddConsumers(typeof(CustomerOrderReviewEventHandler).Assembly);
    busConfigurator.AddConsumers(typeof(ProductVariantIdAddedEventHandler).Assembly);
    busConfigurator.AddConsumers(typeof(UpdateStoreOnboardingStatusEventConsumer).Assembly);

    busConfigurator.AddConsumersFromNamespaceContaining<ConsumersNamespace>();



builder.Services.AddTransient<IEndpointAddressProvider, ElasticMqEndpointAddressProvider>();



// MediatR
builder.Services.AddMediatR(cfg =>
{
    cfg.RegisterServicesFromAssemblyContaining<SetShippingConfigurationCommand>();

    cfg.RegisterServicesFromAssemblyContaining<IdentityVerifyOrRegisterCommand>();
    cfg.RegisterServicesFromAssemblyContaining<CustomerWithOrderQuery>();

    cfg.RegisterServicesFromAssemblyContaining<StoreInboxQuery>();
    cfg.RegisterServicesFromAssemblyContaining<StoreOrderHistoryQuery>();
    cfg.RegisterServicesFromAssemblyContaining<InitialHandshakeCommand>();
    cfg.RegisterServicesFromAssemblyContaining<HandshakeConfirmationCommand>();
    cfg.RegisterServicesFromAssemblyContaining<HandshakeDesyncCommand>();
    cfg.RegisterServicesFromAssemblyContaining<StoreOrderHistoryRetrievalQuery>();
    cfg.RegisterServicesFromAssemblyContaining<UpdateShippingOptionCommand>();
    cfg.RegisterServicesFromAssemblyContaining<OrderRatingListQuery>();
    cfg.RegisterServicesFromAssemblyContaining<GetProfileQuery>();
    cfg.RegisterServicesFromAssemblyContaining<CreatePaypalOrderCommand>();

});

builder.Services.AddTransient(typeof(IPipelineBehavior<,>), typeof(LoggingPipelineBehavior<,>));

builder.Services.AddSingleton<IAuthorizationHandler, HasScopeHandler>();

// Repositories
builder.Services.AddTransient<ICustomerRepository, CustomerRepository>();
builder.Services.AddTransient<IIdentityRepository, IdentityRepository>();
builder.Services.AddTransient<IStoreRepository, StoreRepository>();
builder.Services.AddTransient<IMerchantRepository, MerchantRepository>();



// Services
builder.Services.AddTransient<IOrdersRefundService, OrdersRefundService>();
builder.Services.AddTransient<
    Sample.Payments.Infrastructure.Paypal.IPaypalService,
    Sample.Payments.Infrastructure.Paypal.PaypalService
>();

builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo { Title = "Sample.API", Version = "v1" });
    c.SchemaGeneratorOptions = new SchemaGeneratorOptions { SchemaIdSelector = type => type.FullName };
});

builder.Services.AddTransient<IRestApiService, RestApiService>();

var app = builder.Build();

app.UseCors(x => x.AllowAnyMethod().AllowAnyHeader().SetIsOriginAllowed(origin => true).AllowCredentials());

if (!app.Environment.IsDevelopment())
{
    app.UseHsts();
}



app.UseSwagger();

app.UseSwaggerUI(c =>
{
    c.SwaggerEndpoint("/swagger/v1/swagger.json", "Sample.API v1");
    c.RoutePrefix = "";
});

app.UseSerilogRequestLogging();
app.UseHttpsRedirection();

app.UseMiddleware<GlobalExceptionHandlingMiddleware>();

app.MapControllers();

app.UseAuthentication();
app.UseAuthorization();

app.Run();
