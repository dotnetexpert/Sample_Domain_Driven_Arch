﻿namespace Sample.API.Providers;

public interface IUserProvider
{
    Guid Id { get; }
    Guid StoreId { get; }
}
