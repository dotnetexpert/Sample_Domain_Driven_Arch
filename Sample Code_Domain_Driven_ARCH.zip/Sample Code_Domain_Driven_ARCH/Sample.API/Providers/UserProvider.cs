﻿namespace Sample.API.Providers;

public class UserProvider : IUserProvider
{
    public UserProvider(IHttpContextAccessor httpContextAccessor)
    {
        if (
            httpContextAccessor != null
            && httpContextAccessor.HttpContext != null
            && httpContextAccessor.HttpContext.User != null
            && httpContextAccessor.HttpContext.User.Claims.Count() > 0
            && httpContextAccessor.HttpContext.User.Claims.Any(c => c.Type == "https://Sample.com/user-id")
            && Guid.TryParse(
                httpContextAccessor.HttpContext.User.Claims.First(x => x.Type == "https://Sample.com/user-id").Value,
                out Guid id
            )
        )
        {
            Id = id;
        }

        if (
            httpContextAccessor != null
            && httpContextAccessor.HttpContext != null
            && httpContextAccessor.HttpContext.User != null
            && httpContextAccessor.HttpContext.User.Claims.Count() > 0
            && httpContextAccessor.HttpContext.User.Claims.Any(c => c.Type == "https://Sample.com/store-id")
            && Guid.TryParse(
                httpContextAccessor.HttpContext.User.Claims.First(x => x.Type == "https://Sample.com/store-id").Value,
                out Guid storeId
            )
        )
        {
            StoreId = storeId;
        }
    }

    public Guid Id { get; private set; }
    public Guid StoreId { get; private set; }
}
