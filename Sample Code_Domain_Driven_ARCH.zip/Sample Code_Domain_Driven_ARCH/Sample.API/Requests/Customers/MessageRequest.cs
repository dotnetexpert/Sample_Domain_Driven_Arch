﻿using System.ComponentModel.DataAnnotations;

namespace Sample.API.Requests.Customers;

public class MessageRequest
{
    [Required]
    public Guid PackageId { get; set; }
    public Guid StoreId { get; set; }

    [Required]
    public string Subject { get; set; }

    [Required]
    public string Body { get; set; }
}
