﻿using MediatR;
using Sample.Security.Domain.Core;
using Sample.Security.Domain.Security;
using Identity = Sample.Security.Domain.Security.Identity;

namespace Sample.Security.Application.Register;

public record IdentityVerifyOrRegisterCommand(string Id, IdentityConfigurationData Data) : IRequest<Result<Identity>>;
