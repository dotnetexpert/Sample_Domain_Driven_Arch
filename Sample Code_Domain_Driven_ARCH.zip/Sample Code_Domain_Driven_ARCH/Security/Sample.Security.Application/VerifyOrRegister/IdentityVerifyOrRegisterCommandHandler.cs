﻿using MediatR;
using Microsoft.Extensions.Logging;
using Sample.CrossCutting.Infrastructure.Events.Identities;
using Sample.CrossCutting.Infrastructure.MessageBroker;
using Sample.Security.Domain.Core;
using Sample.Security.Domain.Interfaces;
using Sample.Security.Domain.Security;
using Identity = Sample.Security.Domain.Security.Identity;

namespace Sample.Security.Application.Register;

public class IdentityVerifyOrRegisterCommandHandler : IRequestHandler<IdentityVerifyOrRegisterCommand, Result<Identity>>
{
    private readonly IIdentityRepository _identityRepository;
    private readonly IEventBus _eventBus;
    private readonly ILogger<IdentityVerifyOrRegisterCommandHandler> _logger;
    private readonly IAuth0Service _auth0Service;

    public IdentityVerifyOrRegisterCommandHandler(
        IIdentityRepository identityRepository,
        IEventBus eventBus,
        ILogger<IdentityVerifyOrRegisterCommandHandler> logger,
        IAuth0Service auth0Service
    )
    {
        _identityRepository = identityRepository;
        _eventBus = eventBus;
        _logger = logger;
        _auth0Service = auth0Service;
    }

    public async Task<Result<Identity>> Handle(IdentityVerifyOrRegisterCommand request, CancellationToken cancellationToken)
    {
        var identity = await _identityRepository.GetByExternalIdAsync(request.Id);

        if (identity != null)
        {
            return identity;
        }

        var managementToken = await _auth0Service.GetManagementTokenAsync();
        var user = await _auth0Service.GetUserAsync(request.Data.Sub, managementToken);

        var userId = Guid.Parse(user.AppMetaData.UserId);

        var existingUser = await _identityRepository.GetByIdAsync(new(userId));

        if (existingUser != null)
        {
            var nameArray = existingUser.Name.Split(' ');

            var firstName = nameArray[0];
            string? lastName = null;

            // auth0 often times returns the email as the name value, this is a way to handle that scenario
            if (firstName == existingUser.Email)
            {
                firstName = null;
            }
            if (nameArray.Length > 1)
            {
                lastName = nameArray[1];
            }

            _ = _eventBus.PublishAsync(
                new IdentityRegisteredEvent(
                    existingUser.Id.Value,
                    firstName,
                    lastName,
                    existingUser.Email,
                    existingUser.LastModified
                )
            );

            return existingUser;
        }
        else
        {
            var result = Identity.Create(
                request.Data.Name,
                request.Data.Email,
                request.Data.EmailVerified,
                request.Data.Picture,
                request.Data.Sub,
                Guid.Parse(user.AppMetaData.UserId)
            );

            if (result.IsFailure)
            {
                var exceptionMessage = $"Error creating user: {result.Error.Message}";
                _logger.LogError(exceptionMessage);
                throw new ApplicationException(exceptionMessage);
            }

            _identityRepository.Add(result.Value);

            await _identityRepository.SaveChangesAsync();

            await _auth0Service.AddUserIdToAuth0UserAsync(result.Value.Id.Value, result.Value.Sub);

            var nameArray = result.Value.Name.Split(' ');

            var firstName = nameArray[0];
            string? lastName = null;

            // auth0 often times returns the email as the name value, this is a way to handle that scenario
            if (firstName == result.Value.Email)
            {
                firstName = null;
            }
            if (nameArray.Length > 1)
            {
                lastName = nameArray[1];
            }

            _ = _eventBus.PublishAsync(
                new IdentityRegisteredEvent(
                    result.Value.Id.Value,
                    firstName,
                    lastName,
                    result.Value.Email,
                    result.Value.LastModified
                )
            );

            return result;
        }
    }
}
