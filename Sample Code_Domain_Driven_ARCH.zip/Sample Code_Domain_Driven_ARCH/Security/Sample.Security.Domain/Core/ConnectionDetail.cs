﻿using Newtonsoft.Json;

namespace Sample.Security.Domain.Core;

public class ConnectionDetail
{
    [JsonProperty("connection")]
    public string Connection { get; private set; }

    [JsonProperty("user_id")]
    public string UserId { get; private set; }

    [JsonProperty("provider")]
    public string Provider { get; private set; }

    [JsonProperty("isSocial")]
    public bool IsSocial { get; private set; }
}
