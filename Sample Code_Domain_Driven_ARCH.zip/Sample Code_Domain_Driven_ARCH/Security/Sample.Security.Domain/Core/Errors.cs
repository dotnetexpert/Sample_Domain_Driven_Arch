﻿namespace Sample.Security.Domain.Core;

public static class Errors
{
    public static class General
    {
        public static Error MoneyAmountMustBeGreaterThanZero(decimal amount) =>
            new("Money.Amount", $"'{amount}' must be greater than zero");

        public static Error QuantityGreaterThanZero(int quantity) =>
            new("Quantity.Positive", $"'{quantity}' must be greater than zero");

        public static Error NullOrWhiteSpaceString(string propertyName) =>
            new("String.NullOrWhiteSpace", $"'{propertyName}' cannot be null or white space");

        public static Error DateTimeMin() => new("DateTime.MinValue", $"DateTime cannot equal DateTime.MinValue.");

        public static Error EmptyGuid() => new("Guid.Empty", $"Guid value cannot equal Guid.Empty().");

        public static Error Null() => new("Null", $"Object is null.");

        public static Error NotFound(Guid id = new Guid()) => new("Id.NotFound", $"Id {id} not found.");

        public static Error ObjectAlreadyExists() => new("Id.AlreadyExists", $"Cannot create object, it already exists.");
    }

    public static class IdentityConfiguration
    {
        public static Error FirstNameMissing() => new Error("Customer.FirstName", $"First name must have a value");
    }

    public static class Identity
    {
        public static Error InvalidConfiguration(string message) => new Error("Identity.Create", message);

        public static Error IdentityAlreadyExists(string id) =>
            new Error("Identity.Create.Handler", $"The identity {id} already exists in the system");
    }

    public static class Auth0
    {
        public static Error StoreNotRegistered() =>
            new Error("Auth0.StoreNotRegistered", "Store registeration failed: Store not registered with the provided email.");

        public static Error StoreNotFound() => new Error("Auth0.StoreNotFound", "Store not found with the provided email.");
    }
}
