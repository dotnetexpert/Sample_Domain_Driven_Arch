﻿namespace Sample.Security.Domain.Core;

public interface IAggregateRoot<out TKey>
    where TKey : StronglyTypedId<Guid>
{
    TKey Id { get; }
}
