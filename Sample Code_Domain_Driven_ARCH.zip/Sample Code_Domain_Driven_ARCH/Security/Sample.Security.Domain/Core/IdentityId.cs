﻿namespace Sample.Security.Domain.Core;

public record IdentityId(Guid Value) : StronglyTypedId<Guid>(Value);
