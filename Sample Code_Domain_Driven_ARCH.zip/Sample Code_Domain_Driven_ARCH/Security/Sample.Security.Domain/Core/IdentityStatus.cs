﻿namespace Sample.Security.Domain.Core;

public class IdentityStatus : Enumeration<IdentityStatus>
{
    public static readonly IdentityStatus Pending = new IdentityStatus(1, "Pending");
    public static readonly IdentityStatus Complete = new IdentityStatus(2, "Complete");
    public static readonly IdentityStatus Failed = new IdentityStatus(3, "Failed");

    private IdentityStatus(int value, string name)
        : base(value, name) { }
}
