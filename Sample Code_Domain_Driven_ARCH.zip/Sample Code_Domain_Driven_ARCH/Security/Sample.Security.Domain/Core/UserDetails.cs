﻿using Newtonsoft.Json;

namespace Sample.Security.Domain.Core;

public class UserDetails : ValueObject<UserDetails>
{
    [JsonProperty("created_at")]
    public DateTime CreatedAt { get; private set; }

    [JsonProperty("email")]
    public string Email { get; private set; }

    [JsonProperty("password")]
    public string Password { get; private set; }

    [JsonProperty("email_verified")]
    public bool EmailVerified { get; private set; }

    [JsonProperty("connectionDetails")]
    public List<ConnectionDetail> ConnectionDetails { get; private set; }

    [JsonProperty("name")]
    public string Name { get; private set; }

    [JsonProperty("nickname")]
    public string Nickname { get; private set; }

    [JsonProperty("picture")]
    public string Picture { get; private set; }

    [JsonProperty("sub")]
    public string Sub { get; private set; }

    [JsonProperty("updated_at")]
    public DateTime UpdatedAt { get; private set; }

    [JsonProperty("user_id")]
    public string UserId { get; private set; }

    [JsonProperty("app_metadata")]
    public AppMetadata AppMetaData { get; private set; }

    private UserDetails(
        string name,
        string email,
        bool emailVerified,
        List<ConnectionDetail> connectionDetails,
        string nickname,
        string picture,
        string userId,
        AppMetadata appMetadata
    )
    {
        Name = name;
        Email = email;
        EmailVerified = emailVerified;
        ConnectionDetails = connectionDetails;
        Nickname = nickname;
        Picture = picture;
        UserId = userId;
        AppMetaData = appMetadata;
    }

    public static Result<UserDetails> Create(
        Guid storeId,
        string name,
        string email,
        bool emailVerified,
        string sub,
        DateTime createdAt,
        List<ConnectionDetail>? connectionDetails,
        string nickname,
        string picture,
        DateTime updatedAt,
        string userId,
        AppMetadata appMetadata
    )
    {
        return Result.Success(
            new UserDetails(name, email, emailVerified, connectionDetails, nickname, picture, userId, appMetadata)
        );
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Name;
        yield return Email;
        yield return Password;
    }

    public class AppMetadata
    {
        [JsonProperty("storeId")]
        public string StoreId { get; set; }

        [JsonProperty("UserId")]
        public string UserId { get; set; }
    }

    public UserDetails() { }
}
