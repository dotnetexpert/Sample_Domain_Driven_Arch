﻿using Newtonsoft.Json;

namespace Sample.Security.Domain.Core;

public class UserResponse
{
    [JsonProperty("created_at")]
    public DateTime CreatedAt { get; set; }

    [JsonProperty("email")]
    public string Email { get; set; }

    [JsonProperty("email_verified")]
    public bool EmailVerified { get; set; }

    [JsonProperty("identity")]
    public List<Identity> Identities { get; set; }

    [JsonProperty("name")]
    public string Name { get; set; }

    [JsonProperty("nickname")]
    public string Nickname { get; set; }

    [JsonProperty("picture")]
    public string Picture { get; set; }

    [JsonProperty("updated_at")]
    public DateTime UpdatedAt { get; set; }

    [JsonProperty("user_id")]
    public string UserId { get; set; }

    [JsonProperty("app_metadata")]
    public AppMetadata AppMetadata { get; set; }
}

public class Identity
{
    [JsonProperty("connection")]
    public string Connection { get; set; }

    [JsonProperty("user_id")]
    public string UserId { get; set; }

    [JsonProperty("provider")]
    public string Provider { get; set; }

    [JsonProperty("isSocial")]
    public bool IsSocial { get; set; }
}

public class AppMetadata
{
    [JsonProperty("storeId")]
    public Guid StoreId { get; set; }

    [JsonProperty("UserId")]
    public Guid UserId { get; set; }
}
