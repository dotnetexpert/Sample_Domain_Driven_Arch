﻿using Sample.Security.Domain.Core;

namespace Sample.Security.Domain.Security;

public interface IIdentityRepository
{
    public void Add(Identity identity);
    public Task<Identity> GetByIdAsync(IdentityId id);
    public Task<Identity?> GetByExternalIdAsync(string externalId);
    public void Update(Identity security);
    public Task SaveChangesAsync();
}
