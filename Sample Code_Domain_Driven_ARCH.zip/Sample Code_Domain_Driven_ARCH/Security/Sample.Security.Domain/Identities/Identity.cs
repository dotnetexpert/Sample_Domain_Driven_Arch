﻿using Sample.Security.Domain.Core;

namespace Sample.Security.Domain.Security;

public class Identity : AggregateRoot<IdentityId>
{
    public string Name { get; private set; }
    public string Email { get; private set; }
    public bool EmailVerified { get; private set; }
    public string Picture { get; private set; }
    public string Sub { get; private set; }
    public DateTime LastModified { get; private set; }

    public static Result<Identity> Create(string name, string email, bool emailVerified, string picture, string sub, Guid userId)
    {
        if (string.IsNullOrWhiteSpace(sub))
            return Result.Failure<Identity>(Errors.General.NullOrWhiteSpaceString(sub));

        if (string.IsNullOrWhiteSpace(name))
            return Result.Failure<Identity>(Errors.General.NullOrWhiteSpaceString(name));

        // TODO: validate email address
        if (string.IsNullOrWhiteSpace(email))
            return Result.Failure<Identity>(Errors.General.NullOrWhiteSpaceString(email));

        return new Identity(name, email, emailVerified, picture, sub, userId);
    }

    private Identity(string name, string email, bool emailVerified, string picture, string sub, Guid userId)
    {
        Id = new(userId);
        Name = name;
        Email = email;
        EmailVerified = emailVerified;
        Picture = picture;
        Sub = sub;
        LastModified = DateTime.UtcNow;
    }

    public void Verify()
    {
        EmailVerified = true;
    }

    public Result Update(Identity identity)
    {
        if (string.IsNullOrWhiteSpace(identity.Name))
            return Result.Failure<Identity>(Errors.General.NullOrWhiteSpaceString(identity.Name));

        // TODO: validate email address
        if (string.IsNullOrWhiteSpace(identity.Email))
            return Result.Failure<Identity>(Errors.General.NullOrWhiteSpaceString(identity.Email));

        Name = identity.Name;
        Email = identity.Email;
        EmailVerified = identity.EmailVerified;
        Picture = identity.Picture;
        LastModified = DateTime.UtcNow;

        return Result.Success();
    }

    private Identity() { }
}
