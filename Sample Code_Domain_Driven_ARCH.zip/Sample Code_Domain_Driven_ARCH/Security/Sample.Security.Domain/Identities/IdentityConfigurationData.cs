﻿namespace Sample.Security.Domain.Security;

public record IdentityConfigurationData(string Name, string Email, bool EmailVerified, string Picture, string Sub);
