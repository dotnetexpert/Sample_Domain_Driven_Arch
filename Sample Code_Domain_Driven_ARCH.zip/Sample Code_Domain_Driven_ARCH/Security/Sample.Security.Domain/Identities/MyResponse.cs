﻿namespace Sample.Security.Domain.Security;

internal class MyResponse
{
    public string Id { get; set; }
    public string Name { get; set; }
    public string UserName { get; set; }
    public string Email { get; set; }
    public string Email_verified { get; set; }
    public string Picture { get; set; }
    public string Sub { get; set; }
    public DateTime Updated_at { get; set; }

    public MyResponse(
        string id,
        string name,
        string userName,
        string email,
        string email_verified,
        string picture,
        string sub,
        DateTime updated_at
    )
    {
        Id = id;
        Name = name;
        UserName = userName;
        Email = email;
        Email_verified = email_verified;
        Picture = picture;
        Sub = sub;
        Updated_at = updated_at;
    }
}
