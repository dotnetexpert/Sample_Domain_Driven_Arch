﻿using Sample.Security.Domain.Core;

namespace Sample.Security.Domain.Interfaces;

public interface IAuth0Service
{
    Task<string> GetManagementTokenAsync();
    Task AddUserIdToAuth0UserAsync(Guid userId, string auth0UserId);
    Task AssignAdminRoleToUserAsync(string auth0userid);
    Task<UserDetails> AddUserAsync(UserDetails userDetails);
    Task<UserDetails> GetUserAsync(string auth0UserId, string token);
    Task<UserResponse> GetStoreByEmailAsync(string storeEmail, string token);
    Task RemoveStoreAdminRoleFromUserAsync(string auth0UserId);
    Task<UserResponse> GetUserByEmailAsync(string email);
    Task RemoveStoreIdFromAppMetadataAsync(string auth0UserId, Guid userId);
    Task AddStoreIdToUserAsync(Guid userId, string auth0UserId, Guid storeId);
}
