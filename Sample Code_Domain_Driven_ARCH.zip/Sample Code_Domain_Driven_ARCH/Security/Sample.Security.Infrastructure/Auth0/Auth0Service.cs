﻿using System.Net;
using Auth0.ManagementApi.Models;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RestSharp;
using Sample.CrossCutting.Infrastructure.Models;
using Sample.Security.Domain.Core;
using Sample.Security.Domain.Interfaces;
using Auth0Api = Auth0.ManagementApi;
using JsonSerializer = System.Text.Json.JsonSerializer;

namespace Sample.Security.Infrastructure.Auth0;

public class Auth0Service : IAuth0Service
{
    private readonly Auth0Configuration _configuration;

    public Auth0Service(IOptions<Auth0Configuration> config)
    {
        _configuration = config.Value;
    }

    public async Task<string> GetManagementTokenAsync()
    {
        var client = new RestClient($"https://{_configuration.Domain}");
        var request = new RestRequest("/oauth/token", Method.Post);

        request.AddHeader("content-type", "application/x-www-form-urlencoded");
        request.AddParameter(
            "application/x-www-form-urlencoded",
            $"grant_type=client_credentials&client_id={_configuration.ClientId}&client_secret={_configuration.ClientSecret}&audience={_configuration.ManagementApiAudience}",
            ParameterType.RequestBody
        );

        var response = await client.ExecuteAsync(request);

        return JsonSerializer.Deserialize<TokenResponse>(response.Content).AccessToken;
    }

    public async Task AddUserIdToAuth0UserAsync(Guid userId, string auth0UserId)
    {
        var token = await GetManagementTokenAsync();
        var client = new Auth0Api.ManagementApiClient(token, _configuration.Domain);

        await client.Users.UpdateAsync(auth0UserId, new UserUpdateRequest { AppMetadata = new { UserId = userId.ToString() } });
    }

    public async Task<UserDetails> GetUserAsync(string auth0UserId, string token)
    {
        if (string.IsNullOrEmpty(auth0UserId))
        {
            throw new Exception($"auth0UserId parameter is null or empty");
        }

        var client = new RestClient(_configuration.ManagementApiAudience);
        var request = new RestRequest($"users/{auth0UserId}", Method.Get);

        request.AddHeader("Accept", "application/json");
        request.AddHeader("Authorization", $"Bearer {token}");

        var response = await client.ExecuteAsync(request);

        if (!response.IsSuccessful)
        {
            throw new Exception(
                $"Failed to retrieve user details. Status Code: {response.StatusCode}, Content: {response.Content}"
            );
        }

        var userDetails = JsonConvert.DeserializeObject<UserDetails>(response.Content);

        return userDetails;
    }

    public async Task AssignAdminRoleToUserAsync(string auth0UserId)
    {
        var token = await GetManagementTokenAsync();
        var client = CreateRestClient(token);
        var roles = await GetAvailableRolesAsync(client);
        var adminRole = roles.FirstOrDefault(role => string.Equals(role.Name, "Store admin", StringComparison.OrdinalIgnoreCase));

        if (adminRole == null)
        {
            throw new Exception("Admin role not found");
        }

        var request = new RestRequest($"roles/{adminRole.Id}/users", Method.Post);

        request.AddJsonBody(new { users = new[] { auth0UserId } });

        var response = await client.ExecuteAsync(request);

        if (!response.IsSuccessful)
        {
            throw new Exception($"Error updating auth0 store id. Status code: {response.StatusCode}");
        }
    }
}
