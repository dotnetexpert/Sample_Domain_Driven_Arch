﻿using System.Text.Json.Serialization;

namespace Sample.Security.Infrastructure.Auth0;

public class TokenResponse
{
    [JsonPropertyName("access_token")]
    public string AccessToken { get; set; }
}
