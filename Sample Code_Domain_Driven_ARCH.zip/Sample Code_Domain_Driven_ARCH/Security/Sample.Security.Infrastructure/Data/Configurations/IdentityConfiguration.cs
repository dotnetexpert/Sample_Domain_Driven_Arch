﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sample.Security.Domain.Core;

namespace Sample.Orders.Infrastructure.Data.Configurations;

public class IdentityConfiguration : IEntityTypeConfiguration<Security.Domain.Security.Identity>
{
    public void Configure(EntityTypeBuilder<Security.Domain.Security.Identity> builder)
    {
        builder.HasKey(p => p.Id);

        builder.Property(p => p.Id).HasConversion(id => id.Value, value => new IdentityId(value));
    }
}
