﻿using System.Reflection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;

namespace Sample.Security.Infrastructure.Data;

public class SecurityContext : DbContext
{
    private readonly IConfiguration _configuration;
#pragma warning disable CS8618 // Required by Entity Framework
    public SecurityContext(DbContextOptions<SecurityContext> options)
        : base(options) { }

    public SecurityContext(DbContextOptions<SecurityContext> options, IConfiguration configuration)
        : base(options)
    {
        System.Diagnostics.Debug.WriteLine("begin");
        _configuration = configuration;
    }

    public DbSet<Security.Domain.Security.Identity> Identities { get; set; }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        System.Diagnostics.Debug.WriteLine("begin");
        base.OnModelCreating(builder);
        builder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        System.Diagnostics.Debug.WriteLine("begin");
        optionsBuilder.UseNpgsql(_configuration.GetConnectionString("SecurityConnectionString"));
    }
}
