﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Sample.Security.Infrastructure.Migrations;

/// <inheritdoc />
public partial class Identities : Migration
{
    /// <inheritdoc />
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(name: "Security");

        migrationBuilder.DropTable(name: "SecurityState");

        migrationBuilder.CreateTable(
            name: "Identities",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                Name = table.Column<string>(type: "text", nullable: false),
                Email = table.Column<string>(type: "text", nullable: false),
                EmailVerified = table.Column<bool>(type: "boolean", nullable: false),
                Picture = table.Column<string>(type: "text", nullable: false),
                Sub = table.Column<string>(type: "text", nullable: false),
                LastModified = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Identities", x => x.Id);
            }
        );
    }

    /// <inheritdoc />
    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(name: "Identities");

        migrationBuilder.CreateTable(
            name: "Security",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                Email = table.Column<string>(type: "text", nullable: false),
                Email_verified = table.Column<string>(type: "text", nullable: false),
                Name = table.Column<string>(type: "text", nullable: false),
                Picture = table.Column<string>(type: "text", nullable: false),
                Sub = table.Column<string>(type: "text", nullable: false),
                Updated_at = table.Column<string>(type: "text", nullable: false),
                UserName = table.Column<string>(type: "text", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Security", x => x.Id);
            }
        );

        migrationBuilder.CreateTable(
            name: "SecurityState",
            columns: table => new
            {
                CorrelationId = table.Column<Guid>(type: "uuid", nullable: false),
                CurrentState = table.Column<int>(type: "integer", maxLength: 64, nullable: false),
                Reason = table.Column<string>(type: "text", nullable: true),
                RetryAttempt = table.Column<int>(type: "integer", nullable: false),
                ScheduleRetryToken = table.Column<Guid>(type: "uuid", nullable: true),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_SecurityState", x => x.CorrelationId);
            }
        );
    }
}
