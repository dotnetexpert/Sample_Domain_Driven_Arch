﻿using Microsoft.EntityFrameworkCore;
using Sample.Security.Domain.Core;
using Sample.Security.Domain.Security;
using Sample.Security.Infrastructure.Data;
using Identity = Sample.Security.Domain.Security.Identity;

namespace Sample.Security.Infrastructure.Repositories;

public class IdentityRepository : IIdentityRepository
{
    private readonly SecurityContext _context;

    public IdentityRepository(SecurityContext context)
    {
        _context = context;
    }

    public async Task<Identity?> GetByExternalIdAsync(string externalId)
    {
        return await _context.Identities.FirstOrDefaultAsync(i => i.Sub == externalId);
    }

    public async Task<Identity> GetByIdAsync(IdentityId id)
    {
        return await _context.Identities.FindAsync(id);
    }

    public void Add(Identity identity)
    {
        _context.Add(identity);
    }

    public void Update(Identity identity)
    {
        _context.Entry(identity).State = EntityState.Modified;
    }

    public async Task SaveChangesAsync()
    {
        await _context.SaveChangesAsync();
    }
}
