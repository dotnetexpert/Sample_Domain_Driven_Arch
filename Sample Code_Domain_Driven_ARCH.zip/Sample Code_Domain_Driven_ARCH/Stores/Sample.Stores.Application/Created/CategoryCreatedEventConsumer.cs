﻿using MassTransit;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Sample.CrossCutting.Infrastructure.Events.Catalog;
using Sample.CrossCutting.Infrastructure.MessageBroker;
using Sample.CrossCutting.Infrastructure.Models;
using Sample.CrossCutting.Infrastructure.Queries.Search;
using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Stores;
using Sample.Stores.Infrastructure.CrystalCommerce.Services;
using Money = Sample.Stores.Domain.Core.Money;

namespace Sample.Stores.Application.Created;

public class CategoryCreatedEventConsumer : IConsumer<CategoryCreatedEvent>
{
    private readonly ILogger<CategoryCreatedEventConsumer> _logger;
    private readonly IStoreRepository _storeRepository;
    private readonly ICrystalCommerceV1Service _crystalCommerceV1Service;
    private readonly IRequestClient<ExternalCatalogIdRequest> _externalCatalogIdsClient;
    private readonly IEventBus _eventBus;
    private Guid _storeId;
    private Store? _currentStore;
    private Dictionary<ExternalVariantId, ExternalVariantId> _existingStoreVariants = new();
    private readonly CrystalCommerceConfiguration _crystalCommerceConfiguration;
    private readonly ProductVariantConfiguration _configuration;

    public CategoryCreatedEventConsumer(
        ILogger<CategoryCreatedEventConsumer> logger,
        IStoreRepository storeRepository,
        ICrystalCommerceV1Service crystalCommerceV1Service,
        IEventBus eventBus,
        IRequestClient<ExternalCatalogIdRequest> externalCatalogIdsClient,
        IOptions<CrystalCommerceConfiguration> crystalCommerceConfiguration,
        IOptions<ProductVariantConfiguration> configuration
    )
    {
        _logger = logger;
        _storeRepository = storeRepository;
        _crystalCommerceV1Service = crystalCommerceV1Service;
        _eventBus = eventBus;
        _externalCatalogIdsClient = externalCatalogIdsClient;
        _crystalCommerceConfiguration = crystalCommerceConfiguration.Value;
        _configuration = configuration.Value;
    }

    public async Task Consume(ConsumeContext<CategoryCreatedEvent> context)
    {
        try
        {
            _storeId = _crystalCommerceConfiguration.StoreId;

            var storeIds = await _storeRepository.GetAllStoreIds();
            _currentStore = await _storeRepository.GetWithProductsAsync(new(_storeId));
            _existingStoreVariants = _currentStore.Products.ToDictionary(p => p.ExternalVariantId, p => p.ExternalVariantId);

            var hasCategory = false;

            foreach (var storeId in storeIds)
            {
                var catalogResponse = await _crystalCommerceV1Service.GetCategoriesByCatalogIdAsync(
                    context.Message.ExternalCategoryCatalogId,
                    storeId
                );

                if (catalogResponse != null && catalogResponse.Category?.CatalogId.HasValue == true)
                {
                    var externalStoreCategoryId = catalogResponse.Category.Id;

                    var newStoreProducts = await AddCategoryProducts(externalStoreCategoryId, storeId);

                    if (newStoreProducts.Any())
                    {
                        hasCategory = true;

                        _logger.LogInformation($"{newStoreProducts.Count} products found and processed.");

                        break;
                    }
                    else
                    {
                        _logger.LogInformation(
                            "No products were found for the specified category in store. Store ID: {StoreId}",
                            storeId
                        );
                    }
                }
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error syncing catalog: {ex.Message}");
            throw;
        }
    }

    public async Task<List<StoreProduct>> AddCategoryProducts(int id, StoreId storeId)
    {
        var newStoreProducts = new List<StoreProduct>();

        try
        {
            var variantsRoot = await _crystalCommerceV1Service.GetVariantsByCategoryAsync(id, storeId);

            if (!variantsRoot.Entries.Any())
            {
                _logger.LogInformation($"No variants found for category id {id}.");

                return newStoreProducts;
            }

            var externalProductCatalogIds = variantsRoot
                .Entries.Where(i => i.Variant.ProductCatalogId.HasValue)
                .Select(e => e.Variant.ProductCatalogId.Value)
                .Distinct()
                .ToList();

            var response = await _externalCatalogIdsClient.GetResponse<ExternalCatalogIdResponse>(new(externalProductCatalogIds));
            var internalProductCatalogIds = response.Message.Ids;

            var storeProductResults = variantsRoot.Entries.Select(
                (entry, index) =>
                {
                    if (entry.Variant.Id.HasValue && _existingStoreVariants.ContainsKey(new(entry.Variant.Id.Value)))
                    {
                        var storeProduct = _currentStore.Products.First(p => p.ExternalVariantId.Value == entry.Variant.Id.Value);
                        storeProduct.SetQuantity(entry.Variant.Qty ?? 0);
                        storeProduct.SetBuyQuantity(entry.Variant.WtbQty ?? 0);
                        storeProduct.SetPrice(Money.Of(entry.Variant.SellPrice.Money.Cents / 100m, Currency.USDollar.Code));
                        storeProduct.SetBuyPrice(Money.Of(entry.Variant.BuyPrice.Money.Cents / 100m, Currency.USDollar.Code));

                        _logger.LogInformation(
                            $"{entry.Variant.ProductName}, {entry.Variant.SellPrice.Money.Cents / 100m}, {entry.Variant.Id} updated for category id {id}"
                        );
                    }

                    if (
                        entry.Variant.ProductCatalogId == null
                        || !internalProductCatalogIds.ContainsKey(entry.Variant.ProductCatalogId.Value)
                    )
                    {
                        return Result.Failure<StoreProduct>(new("CreateStoreProduct", "Missing catalog id"));
                    }

                    var variantDescriptors = entry
                        .Variant.Descriptors?.Where(d =>
                            !string.IsNullOrWhiteSpace(d.VariantDescriptor.Name)
                            && !string.IsNullOrWhiteSpace(d.VariantDescriptor.Value)
                        )
                        .GroupBy(d => d.VariantDescriptor.Name)
                        .ToDictionary(
                            d => d.First().VariantDescriptor.Name,
                            d =>
                            {
                                var value = d.First().VariantDescriptor.Value.Trim();
                                if (d.First().VariantDescriptor.Name == "Condition")
                                {
                                    var mappedCondition = ProductVariantTypesEnum.FromString(value, _configuration)?.Name;
                                    return mappedCondition ?? null;
                                }
                                return value;
                            }
                        );

                    if (string.IsNullOrEmpty(variantDescriptors["Condition"]))
                    {
                        return Result.Failure<StoreProduct>(
                            new("CreateStoreProduct", "Variant descriptors are missing or empty.")
                        );
                    }

                    var internalProductCatalogId = internalProductCatalogIds[entry.Variant.ProductCatalogId.Value];

                    return StoreProduct.Create(
                        new ProductCatalogId(internalProductCatalogId),
                        new ExternalProductId(entry.Variant.ProductId ?? 0),
                        new ExternalVariantId(entry.Variant.Id ?? 0),
                        new ProductVariantId(Guid.Empty),
                        new StoreId(_storeId),
                        entry.Variant.ProductName,
                        Money.Of((entry.Variant.SellPrice.Money.Cents / 100m), Currency.USDollar.Code),
                        entry.Variant.Qty.Value,
                        Money.Of(entry.Variant.BuyPrice.Money.Cents, entry.Variant.BuyPrice.Money.Currency),
                        entry.Variant.WtbQty.Value,
                        variantDescriptors
                            ?? new Dictionary<string, string>()
                                .Concat(new[] { new KeyValuePair<string, string>("Language", "English") })
                                .GroupBy(kvp => kvp.Key)
                                .ToDictionary(g => g.Key, g => g.Last().Value)
                    );
                }
            );

            newStoreProducts = storeProductResults.Where(r => r.IsSuccess).Select(r => r.Value).ToList();

            if (newStoreProducts.Any())
            {
                _currentStore.AddProductsToInventory(newStoreProducts);

                _logger.LogInformation($"{newStoreProducts.Count} new products added for category id {id}:");

                foreach (var product in newStoreProducts)
                {
                    _logger.LogInformation($"{product.Name}, {product.Price}, {product.Id} added to category id {id}");
                }

                await _storeRepository.SaveChangesAsync();

                var importProductVariantTypes = new ProductVariantTypesAddedEvent(
                    newStoreProducts
                        .Select(p => new ProductVariantTypesAddedPayload(
                            ProductId: p.ProductCatalogId.Value,
                            ExternalVariantId: p.ExternalVariantId.Value,
                            ProductVariantTypes: p.VariantTypes,
                            StoreId: _storeId
                        ))
                        .ToList()
                );

                if (importProductVariantTypes.Payload.Any())
                {
                    _logger.LogInformation(
                        $"{importProductVariantTypes.Payload.Count} new variants found for category id {id}, sending to the catalog"
                    );
                    _ = _eventBus.PublishAsync(importProductVariantTypes);
                }
            }

            return newStoreProducts;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error syncing catalog: {ex.Message}");

            return newStoreProducts;
        }
    }
}
