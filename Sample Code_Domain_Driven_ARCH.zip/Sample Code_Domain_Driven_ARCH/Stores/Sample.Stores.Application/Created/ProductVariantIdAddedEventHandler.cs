﻿using System.Text.Json;
using MassTransit;
using Microsoft.Extensions.Logging;
using Sample.CrossCutting.Infrastructure.Events.Catalog;
using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Stores;

namespace Sample.Stores.Application.Created;

public class ProductVariantIdAddedEventHandler : IConsumer<ProductVariantIdAddedEvent>
{
    private readonly IStoreRepository _storeRepository;
    private readonly ILogger<ProductVariantIdAddedEventHandler> _logger;

    public ProductVariantIdAddedEventHandler(IStoreRepository storeRepository, ILogger<ProductVariantIdAddedEventHandler> logger)
    {
        _storeRepository = storeRepository;
        _logger = logger;
    }

    public async Task Consume(ConsumeContext<ProductVariantIdAddedEvent> context)
    {
        var variantIdsByProductCatalogIds = context.Message.Payload;

        foreach (var productIdEntry in variantIdsByProductCatalogIds)
        {
            var productCatalogId = productIdEntry.ProductCatalogId;
            var storeId = productIdEntry.StoreId;
            var productVariantIdDictionary = productIdEntry.ExternalVariantIdWithProductVariantIdMap;

            var storeProducts = await _storeRepository.GetProductsByCatalogIdAsync(
                new StoreId(storeId),
                new ProductCatalogId(productCatalogId)
            );

            foreach (var product in storeProducts)
            {
                var key = $"{storeId}:{productCatalogId}:{product.VariantTypes["Condition"]}:{product.VariantTypes["Language"]}";

                if (productVariantIdDictionary.TryGetValue(key, out var newProductVariantId))
                {
                    product.SetProductVariantId(new ProductVariantId(newProductVariantId));
                }
                else
                {
                    _logger.LogInformation(
                        $"No product variant id found for store {storeId} and product catalog id {productCatalogId}"
                    );
                }
            }
        }

        await _storeRepository.SaveChangesAsync();
    }
}
