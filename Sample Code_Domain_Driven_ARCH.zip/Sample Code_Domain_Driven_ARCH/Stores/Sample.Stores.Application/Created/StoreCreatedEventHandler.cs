﻿using MassTransit;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Sample.CrossCutting.Infrastructure.Events.Catalog;
using Sample.CrossCutting.Infrastructure.Events.Stores;
using Sample.CrossCutting.Infrastructure.MessageBroker;
using Sample.CrossCutting.Infrastructure.Queries.Categories;
using Sample.CrossCutting.Infrastructure.Queries.Search;
using Sample.CrossCutting.Infrastructure.Service.EmailService;
using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Stores;
using Sample.Stores.Infrastructure.CrystalCommerce.Models.Categories;
using Sample.Stores.Infrastructure.CrystalCommerce.Models.Variants;
using Sample.Stores.Infrastructure.CrystalCommerce.Services;
using IMediator = MediatR.IMediator;
using Money = Sample.Stores.Domain.Core.Money;

namespace Sample.Stores.Application.Created;

public class StoreCreatedEventHandler : IConsumer<StoreCreatedEvent>
{
    private readonly ILogger<StoreCreatedEventHandler> _logger;
    private readonly IStoreRepository _storeRepository;
    private readonly ICrystalCommerceV1Service _crystalCommerceV1Service;
    private readonly IRequestClient<ExternalCatalogIdRequest> _externalCatalogIdsClient;
    private readonly ProductVariantConfiguration _configuration;
    private readonly IRequestClient<GetCategoryLeavesRequest> _categoryLeavesClient;
    private readonly IMediator _mediator;
    private readonly IEventBus _eventBus;
    private readonly IEmailService _emailService;
    private Guid _storeId;
    private Store? _currentStore;
    private List<int> _categoryLeaves = new List<int>();
    private Dictionary<int, int> _catalogCategoryLeaves = new Dictionary<int, int>();
    private Dictionary<ExternalVariantId, ExternalVariantId> _existingVariants = new();
    private Dictionary<ExternalVariantId, ExternalVariantId> _existingStoreVariants = new();

    public StoreCreatedEventHandler(
        ILogger<StoreCreatedEventHandler> logger,
        IStoreRepository storeRepository,
        ICrystalCommerceV1Service crystalCommerceV1Service,
        IMediator mediator,
        IEmailService emailService,
        IEventBus eventBus,
        IRequestClient<GetCategoryLeavesRequest> categoryLeavesClient,
        IRequestClient<ExternalCatalogIdRequest> externalCatalogIdsClient,
        IOptions<ProductVariantConfiguration> configuration
    )
    {
        _logger = logger;
        _storeRepository = storeRepository;
        _crystalCommerceV1Service = crystalCommerceV1Service;
        _mediator = mediator;
        _eventBus = eventBus;
        _categoryLeavesClient = categoryLeavesClient;
        _externalCatalogIdsClient = externalCatalogIdsClient;
        _configuration = configuration.Value;
        _emailService = emailService;
    }

    public async Task Consume(ConsumeContext<StoreCreatedEvent> context)
    {
        try
        {
            _storeId = context.Message.Id;

            try
            {
                await _emailService.SendEmailAsync(
                    new CrossCutting.Infrastructure.Models.Email
                    {
                        Subject = $"Begin {context.Message.Name} Inventory Import ",
                        To = "eric@Sample.com",
                        Body = "Store Name: " + context.Message.Name + "\r\n\r\n" + "Store Id: " + context.Message.Id.ToString(),
                    }
                );
            }
            catch (Exception ex)
            {
                _logger.LogError("Error sending email: " + ex.Message);
            }

            var response = await _categoryLeavesClient.GetResponse<GetCategoryLeavesResponse>(new GetCategoryLeavesRequest());

            _catalogCategoryLeaves = response.Message.ExternalCategoryIds;

            var categoryRoot = await _crystalCommerceV1Service.GetCategoryHierarchyAsync(_storeId);

            if (categoryRoot == null)
            {
                _logger.LogError($"Category root was null when syncing category hierarchy");
                throw new ArgumentNullException();
            }

            foreach (var child in categoryRoot.Category.Children)
            {
                GetCategoryLeaves(child.Category);
            }

            _currentStore = await _storeRepository.GetWithProductsAsync(new(_storeId));

            var productDictionary = new Dictionary<ExternalVariantId, ExternalVariantId>();

            foreach (var product in _currentStore.Products)
            {
                if (!productDictionary.ContainsKey(product.ExternalVariantId))
                {
                    productDictionary.Add(product.ExternalVariantId, product.ExternalVariantId);
                }
            }

            _existingStoreVariants = productDictionary;

            foreach (var category in _categoryLeaves.Distinct())
            {
                await AddCategoryProducts(category);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error syncing catalog {ex.Message}");

            await _emailService.SendEmailAsync(
                new CrossCutting.Infrastructure.Models.Email
                {
                    Subject = $"Error During {context.Message.Name} Inventory Import ",
                    To = "eric@Sample.com",
                    Body = ex.Message,
                }
            );

            throw;
        }

        await _emailService.SendEmailAsync(
            new CrossCutting.Infrastructure.Models.Email
            {
                Subject = $"{context.Message.Name} Inventory Import Complete",
                To = "eric@Sample.com",
                Body = "Store Name: " + context.Message.Name + "\r\n\r\n" + "Store Id: " + context.Message.Id.ToString(),
            }
        );
    }

    public void GetCategoryLeaves(Category root)
    {
        if (root.IsLeaf && root.CatalogId.HasValue && _catalogCategoryLeaves.ContainsKey(root.CatalogId.Value))
        {
            _categoryLeaves.Add(root.Id);
        }

        foreach (var child in root.Children)
        {
            GetCategoryLeaves(child.Category);
        }
    }

    public async Task AddCategoryProducts(int id)
    {
        try
        {
            var pageNumber = 1;
            var pageSize = 100;
            var entries = new List<Entry>();

            var variantsRoot = await _crystalCommerceV1Service.GetVariantsByCategoryAsync(
                id,
                new StoreId(_storeId),
                pageNumber,
                pageSize
            );

            entries.AddRange(variantsRoot.Entries);
            pageNumber += 1;

            while (variantsRoot.NextPage != null)
            {
                variantsRoot = await _crystalCommerceV1Service.GetVariantsByCategoryAsync(
                    id,
                    new StoreId(_storeId),
                    pageNumber,
                    pageSize
                );
                entries.AddRange(variantsRoot.Entries);
                pageNumber += 1;
            }

            var externalProductCatalogIds = entries
                // removed line below because checking for non-existent variants doesn't really make sense
                //.Where(i => i.Variant.ProductCatalogId.HasValue && !_existingStoreVariants.ContainsKey(new(i.Variant.Id.Value)))
                .Where(i => i.Variant.ProductCatalogId.HasValue)
                .Select(e => e.Variant.ProductCatalogId.Value)
                .Distinct()
                .ToList();

            if (!externalProductCatalogIds.Any())
            {
                return;
            }

            // get catalog ids using request/response model
            var response = await _externalCatalogIdsClient.GetResponse<ExternalCatalogIdResponse>(
                new(externalProductCatalogIds),
                default,
                RequestTimeout.After(s: 180)
            );

            var internalProductCatalogIds = response.Message.Ids;

            var storeProductResults = entries.Select(
                (entry, index) =>
                {
                    // check if it exists in the store already, if it does and the quantity is different, match the quantities
                    if (entry.Variant.Id.HasValue && _existingStoreVariants.ContainsKey(new(entry.Variant.Id.Value)))
                    {
                        // how can this be optimized? This can be looping through 30k+ records?
                        var storeProduct = _currentStore.Products.First(p => p.ExternalVariantId.Value == entry.Variant.Id.Value);
                        storeProduct.SetQuantity(entry.Variant.Qty ?? 0);
                        storeProduct.SetBuyQuantity(entry.Variant.WtbQty ?? 0);
                        storeProduct.SetPrice(Money.Of(entry.Variant.SellPrice.Money.Cents / 100m, Currency.USDollar.Code));
                        storeProduct.SetBuyPrice(Money.Of(entry.Variant.BuyPrice.Money.Cents / 100m, Currency.USDollar.Code));

                        _logger.LogInformation(
                            $"{entry.Variant.ProductName}, {entry.Variant.SellPrice.Money.Cents / 100m}, {entry.Variant.Id} updated for category id {id}"
                        );

                        return Result.Failure<StoreProduct>(new("CreateStoreProduct", "Product exists and quantity updated"));
                    }

                    if (
                        entry.Variant.ProductCatalogId == null
                        || !internalProductCatalogIds.ContainsKey(entry.Variant.ProductCatalogId.Value)
                    )
                    {
                        return Result.Failure<StoreProduct>(new("CreateStoreProduct", "Missing catalog id"));
                    }

                    var variantDescriptors = entry
                        .Variant.Descriptors?.Where(d =>
                            !string.IsNullOrWhiteSpace(d.VariantDescriptor.Name)
                            && !string.IsNullOrWhiteSpace(d.VariantDescriptor.Value)
                        )
                        .GroupBy(d => d.VariantDescriptor.Name)
                        .ToDictionary(
                            d => d.First().VariantDescriptor.Name,
                            d =>
                            {
                                var value = d.First().VariantDescriptor.Value.Trim();
                                if (d.First().VariantDescriptor.Name == "Condition")
                                {
                                    var mappedCondition = ProductVariantTypesEnum.FromString(value, _configuration)?.Name;
                                    return mappedCondition ?? null;
                                }
                                return value;
                            }
                        );

                    if (string.IsNullOrEmpty(variantDescriptors["Condition"]))
                    {
                        return Result.Failure<StoreProduct>(
                            new("CreateStoreProduct", "Variant descriptors are missing or empty.")
                        );
                    }

                    var internalProductCatalogId = internalProductCatalogIds[entry.Variant.ProductCatalogId.Value];

                    // if it does not exist in the store, create a new store product and save it
                    return StoreProduct.Create(
                        new ProductCatalogId(internalProductCatalogId),
                        new ExternalProductId(entry.Variant.ProductId ?? 0),
                        new ExternalVariantId(entry.Variant.Id ?? 0),
                        new ProductVariantId(Guid.Empty),
                        new StoreId(_storeId),
                        entry.Variant.ProductName,
                        Money.Of((entry.Variant.SellPrice.Money.Cents / 100m), Currency.USDollar.Code),
                        entry.Variant.Qty.Value,
                        Money.Of(entry.Variant.BuyPrice.Money.Cents, entry.Variant.BuyPrice.Money.Currency),
                        entry.Variant.WtbQty.Value,
                        variantDescriptors
                            ?? new Dictionary<string, string>()
                                .Concat(new[] { new KeyValuePair<string, string>("Language", "English") })
                                .GroupBy(kvp => kvp.Key)
                                .ToDictionary(g => g.Key, g => g.Last().Value)
                    );
                }
            );

            var newStoreProducts = storeProductResults?.Where(r => r.IsSuccess).Select(r => r.Value) ?? new List<StoreProduct>();

            if (newStoreProducts.Any(p => p.VariantTypes.ContainsKey("Condition") && p.VariantTypes["Condition"] == "NM"))
            {
                var messedUpProduct = newStoreProducts.First(p =>
                    p.VariantTypes.ContainsKey("Condition") && p.VariantTypes["Condition"] == "NM"
                );
                var thisShouldnBe = "true";
            }

            _currentStore.AddProductsToInventory(newStoreProducts);

            _logger.LogInformation($"{newStoreProducts.Count()} new products added for category id {id}:");
            foreach (var product in newStoreProducts)
            {
                _logger.LogInformation($"{product.Name}, {product.Price}, {product.Id} added to category id {id}");
            }

            await _storeRepository.SaveChangesAsync();

            var importProductVariantTypes = new ProductVariantTypesAddedEvent(
                newStoreProducts
                    .Select(p => new ProductVariantTypesAddedPayload(
                        ProductId: p.ProductCatalogId.Value,
                        ExternalVariantId: p.ExternalVariantId.Value,
                        ProductVariantTypes: p.VariantTypes,
                        StoreId: _storeId
                    ))
                    .ToList()
            );

            if (importProductVariantTypes.Payload.Count > 0)
            {
                _logger.LogInformation(
                    $"{importProductVariantTypes.Payload.Count} new variants found for category id {id}, sending to the catalog"
                );
                _ = _eventBus.PublishAsync(importProductVariantTypes);
            }
        }
        catch (Exception ex)
        {
            _logger.LogError($"Error syncing catalog {ex.Message}");
            return;
        }
    }
}
