﻿using Sample.Stores.Domain.Interfaces.Services;
using Sample.Stores.Domain.Stores;

namespace Sample.Stores.Application.Services;

public class OrdersRefundService : IOrdersRefundService
{
    public Task<Guid> IssueFullRefundAsync(Guid orderId)
    {
        throw new NotImplementedException();
    }

    public Task<Guid> IssuePartialRefundAsync(Guid orderId, decimal subtotal, decimal tax, decimal shippingCost)
    {
        throw new NotImplementedException();
    }

    public Task<Guid> RefundProductAsync(Guid orderId, IEnumerable<ProductReturn> returns)
    {
        throw new NotImplementedException();
    }
}
