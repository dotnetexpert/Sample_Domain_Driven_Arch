﻿using MassTransit;
using Sample.CrossCutting.Infrastructure.Events.Customers.ShoppingCart;
using Sample.CrossCutting.Infrastructure.Models;
using Sample.Stores.Domain.Stores;

namespace Sample.Stores.Application.ShippingOptions;

public class CalculateShippingRateEventConsumer : IConsumer<CalculateShippingRateEvent>
{
    private readonly IStoreRepository _storeRepository;

    public CalculateShippingRateEventConsumer(IStoreRepository storeRepository)
    {
        _storeRepository = storeRepository;
    }

    public async Task Consume(ConsumeContext<CalculateShippingRateEvent> context)
    {
        var shippingRateEvent = context.Message;
        var shippingRateDataList = new List<CalculateShippingRateData>();

        foreach (var shippingRateData in shippingRateEvent.ShippingRateData)
        {
            var shippingOptions = await _storeRepository.GetShippingOptionsByCountry(
                new StoreId(shippingRateData.StoreId),
                shippingRateData.Country
            );

            var shippingCategory = ShippingCategory.DetermineCategory(shippingRateData.TotalWeight);

            if (shippingCategory == shippingRateData.ShippingCategory)
            {
                var calculatedShippingCost = shippingOptions.CalculateShippingCost(
                    shippingRateData.TotalWeight,
                    shippingOptions,
                    shippingRateData.TotalPackageCost,
                    shippingOptions.FreeShippingThreshold.Amount
                );
                var shippingCost = calculatedShippingCost.Keys.First().Amount;
                shippingRateDataList.Add(
                    new CalculateShippingRateData(shippingRateData.StoreId, shippingCost, shippingRateData.ShippingCategory)
                );
            }
        }

        await context.RespondAsync(new CalculateShippingRateResponse(shippingRateDataList));
    }
}
