﻿using MassTransit;
using MediatR;
using Sample.CrossCutting.Core;
using Sample.CrossCutting.Infrastructure.Events.Stores.Shipping;
using Sample.Stores.Domain.Stores;

namespace Sample.Stores.Application.ShippingOptions;

public class GetFreeShippingThresholdEventHandler
    : IRequestHandler<GetFreeShippingThresholdEvent, Result<Dictionary<Guid, decimal>>>
{
    private readonly IStoreRepository _storeRepository;

    public GetFreeShippingThresholdEventHandler(IStoreRepository storeRepository)
    {
        _storeRepository = storeRepository;
    }

    public async Task<Result<Dictionary<Guid, decimal>>> Handle(
        GetFreeShippingThresholdEvent request,
        CancellationToken cancellationToken
    )
    {
        var storeIds = request.StoreIdList.Select(id => new StoreId(id)).ToList();
        var storeFreeShippingThresholdMapping = await _storeRepository.GetFreeShippingThresholdMapping(storeIds);
        return storeFreeShippingThresholdMapping;
    }
}
