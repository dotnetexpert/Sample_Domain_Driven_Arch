﻿using MediatR;
using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Stores;

namespace Sample.Stores.Application.ShippingOptions;

public class GetShippingOptionQueryHandler : IRequestHandler<GetShippingOptionQuery, Result<Domain.Stores.ShippingOptions>>
{
    private readonly IStoreRepository _storeRepository;

    public GetShippingOptionQueryHandler(IStoreRepository storeRepository)
    {
        _storeRepository = storeRepository;
    }

    public async Task<Result<Domain.Stores.ShippingOptions>> Handle(
        GetShippingOptionQuery request,
        CancellationToken cancellationToken
    )
    {
        var shippingOptions = await _storeRepository.GetShippingOptions(request.StoreId, request.CountryCode);

        if (shippingOptions == null)
        {
            if (request.CountryCode == "CA")
            {
                return Domain.Stores.ShippingOptions.Create(
                    request.StoreId,
                    Money.Of(3.99m, Currency.USDollar.Code),
                    Money.Of(9.99m, Currency.USDollar.Code),
                    Money.Of(19.99m, Currency.USDollar.Code),
                    Money.Of(20.00m, Currency.USDollar.Code),
                    Money.Of(50.00m, Currency.USDollar.Code),
                    request.CountryCode
                );
            }
            else if (request.CountryCode == "US")
            {
                return Domain.Stores.ShippingOptions.Create(
                    request.StoreId,
                    Money.Of(0.99m, Currency.USDollar.Code),
                    Money.Of(4.99m, Currency.USDollar.Code),
                    Money.Of(14.99m, Currency.USDollar.Code),
                    Money.Of(10.00m, Currency.USDollar.Code),
                    Money.Of(20.00m, Currency.USDollar.Code),
                    request.CountryCode
                );
            }
        }

        return Result.Success(shippingOptions);
    }
}
