﻿using MediatR;
using Sample.Stores.Domain.Core;

namespace Sample.Stores.Application.ShippingOptions;

public record SyncAllStoresShippingOptionsCommand() : IRequest<Result>;
