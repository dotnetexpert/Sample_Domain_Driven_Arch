﻿using MediatR;
using Microsoft.Extensions.Logging;
using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Stores;
using Sample.Stores.Infrastructure.CrystalCommerce.Services;

namespace Sample.Stores.Application.ShippingOptions;

public class SyncAllStoresShippingOptionsCommandHandler : IRequestHandler<SyncAllStoresShippingOptionsCommand, Result>
{
    private readonly IStoreRepository _storeRepository;
    private readonly ICrystalCommerceV1Service _crystalCommerceV1Service;
    private readonly ILogger<SyncAllStoresShippingOptionsCommandHandler> _logger;

    public SyncAllStoresShippingOptionsCommandHandler(
        IStoreRepository storeRepository,
        ICrystalCommerceV1Service crystalCommerceV1Service,
        ILogger<SyncAllStoresShippingOptionsCommandHandler> logger
    )
    {
        _storeRepository = storeRepository;
        _crystalCommerceV1Service = crystalCommerceV1Service;
        _logger = logger;
    }

    public async Task<Result> Handle(SyncAllStoresShippingOptionsCommand request, CancellationToken cancellationToken)
    {
        var storeIdList = await _storeRepository.GetAllStoreIds();

        foreach (var storeId in storeIdList)
        {
            var store = await _storeRepository.GetStoreShippingOptions(storeId);
            var response = await _crystalCommerceV1Service.GetShippingOptionsAsync(store.Id);

            int? smallShippingId = null;
            int? mediumShippingId = null;
            int? largeShippingId = null;
            int? trackedShippingId = null;

            foreach (var shippingOptionsResult in response.ToList())
            {
                if (shippingOptionsResult?.ShippingOptions.ShippingOptions?.USPS != null)
                {
                    foreach (var option in shippingOptionsResult.ShippingOptions.ShippingOptions.USPS)
                    {
                        var serviceName = option.Name.ToLower();

                        if (serviceName == "first-class mail stamped letter")
                        {
                            smallShippingId = option.Id;
                        }
                        else if (serviceName == "first-class mail large envelope")
                        {
                            mediumShippingId = option.Id;
                        }
                        else if (serviceName == "usps ground advantage")
                        {
                            largeShippingId = option.Id;
                            trackedShippingId = option.Id;
                        }
                    }
                }
                else
                {
                    _logger.LogWarning($"USPS shipping options not found for StoreId: {store.Id}");
                    continue;
                }

                var shippingOption = store.ShippingOptions.FirstOrDefault(p =>
                    p.CountryCode == shippingOptionsResult.CountryCode
                );

                if (shippingOption != null)
                {
                    shippingOption.SetShippingOptionIds(smallShippingId, mediumShippingId, largeShippingId, trackedShippingId);
                }
            }

            await _storeRepository.SaveChangesAsync();
        }

        return Result.Success();
    }
}
