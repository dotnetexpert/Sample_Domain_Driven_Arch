﻿using MediatR;
using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Stores;

namespace Sample.Stores.Application.ShippingOptions;

public record UpdateShippingOptionCommand(UpdateShippingOptionsData UpdateShippingOptionsData) : IRequest<Result>;
