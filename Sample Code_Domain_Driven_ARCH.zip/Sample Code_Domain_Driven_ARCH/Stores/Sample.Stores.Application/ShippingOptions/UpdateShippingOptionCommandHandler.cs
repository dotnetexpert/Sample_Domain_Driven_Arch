﻿using MediatR;
using Sample.CrossCutting.Infrastructure.Events.Stores.Shipping;
using Sample.CrossCutting.Infrastructure.MessageBroker;
using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Stores;

namespace Sample.Stores.Application.ShippingOptions;

public class UpdateShippingOptionCommandHandler : IRequestHandler<UpdateShippingOptionCommand, Result>
{
    private readonly IStoreRepository _storeRepository;
    private readonly IEventBus _eventBus;

    public UpdateShippingOptionCommandHandler(IStoreRepository storeRepository, IEventBus eventBus)
    {
        _storeRepository = storeRepository;
        _eventBus = eventBus;
    }

    public async Task<Result> Handle(UpdateShippingOptionCommand request, CancellationToken cancellationToken)
    {
        var shippingOptions = await _storeRepository.GetShippingOptions(
            request.UpdateShippingOptionsData.StoreId,
            request.UpdateShippingOptionsData.CountryCode
        );

        if (shippingOptions == null)
        {
            shippingOptions = Domain
                .Stores.ShippingOptions.Create(
                    request.UpdateShippingOptionsData.StoreId,
                    request.UpdateShippingOptionsData.Small,
                    request.UpdateShippingOptionsData.Medium,
                    request.UpdateShippingOptionsData.Large,
                    request.UpdateShippingOptionsData.FreeShippingThreshold,
                    request.UpdateShippingOptionsData.TrackingRequiredThreshold,
                    request.UpdateShippingOptionsData.CountryCode
                )
                .Value;

            var store = await _storeRepository.GetWithShippingOptions(request.UpdateShippingOptionsData.StoreId);
            store.AddShippingOptions(shippingOptions);
        }
        else
        {
            shippingOptions.UpdateShippingOptions(
                request.UpdateShippingOptionsData.Small,
                request.UpdateShippingOptionsData.Medium,
                request.UpdateShippingOptionsData.Large,
                request.UpdateShippingOptionsData.FreeShippingThreshold,
                request.UpdateShippingOptionsData.TrackingRequiredThreshold
            );
        }

        await _storeRepository.SaveChangesAsync();

        await _eventBus.PublishAsync(
            new ShippingConfigurationUpdateEvent(
                shippingOptions.StoreId.Value,
                shippingOptions.Id.Value,
                shippingOptions.Small.Amount,
                shippingOptions.Small.Currency,
                shippingOptions.Medium.Amount,
                shippingOptions.Medium.Currency,
                shippingOptions.Large.Amount,
                shippingOptions.Large.Currency,
                shippingOptions.FreeShippingThreshold.Amount,
                shippingOptions.FreeShippingThreshold.Currency,
                shippingOptions.TrackingRequiredThreshold.Amount,
                shippingOptions.TrackingRequiredThreshold.Currency
            )
        );

        return Result.Success();
    }
}
