﻿using MediatR;
using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Stores;

namespace Sample.Stores.Application.Staff.Add;

public class AddStaffMemberCommandHandler : IRequestHandler<AddStaffMemberCommand, Result>
{
    private readonly IStoreRepository _storeRepository;

    public AddStaffMemberCommandHandler(IStoreRepository storeRepository)
    {
        _storeRepository = storeRepository;
    }

    public async Task<Result> Handle(AddStaffMemberCommand request, CancellationToken cancellationToken)
    {
        var store = await _storeRepository.GetWithStaffAsync(request.StoreId);

        var result = store.AddStaffMember(new(request.UserId, request.FirstName, request.LastName, request.EmailAddress));

        if (result.IsFailure)
        {
            return result;
        }

        _storeRepository.Update(store);

        await _storeRepository.SaveChangesAsync();

        return result;
    }
}
