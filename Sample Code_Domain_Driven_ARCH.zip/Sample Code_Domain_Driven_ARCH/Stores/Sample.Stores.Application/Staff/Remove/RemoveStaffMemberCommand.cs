﻿using MediatR;
using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Stores;

namespace Sample.Stores.Application.Staff.Remove;

public record RemoveStaffMemberCommand(StoreId StoreId, StaffMemberId Id) : IRequest<Result>;
