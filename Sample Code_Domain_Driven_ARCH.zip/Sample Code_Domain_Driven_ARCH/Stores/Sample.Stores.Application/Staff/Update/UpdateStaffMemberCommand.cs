﻿using MediatR;
using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Stores;

namespace Sample.Stores.Application.Staff.Update;

public record UpdateStaffMemberCommand(
    StaffMemberId Id,
    StoreId StoreId,
    UserId UserId,
    string FirstName,
    string LastName,
    string EmailAddress
) : IRequest<Result>;
