﻿using MediatR;
using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Stores;

namespace Sample.Stores.Application.Staff.Update;

public class UpdateStaffMemberCommandHandler : IRequestHandler<UpdateStaffMemberCommand, Result>
{
    private readonly IStoreRepository _storeRepository;

    public UpdateStaffMemberCommandHandler(IStoreRepository storeRepository)
    {
        _storeRepository = storeRepository;
    }

    public async Task<Result> Handle(UpdateStaffMemberCommand request, CancellationToken cancellationToken)
    {
        var store = await _storeRepository.GetWithStaffAsync(request.StoreId);

        var result = store.UpdateStaffMember(
            request.Id,
            new(request.UserId, request.FirstName, request.LastName, request.EmailAddress)
        );

        if (result.IsFailure)
        {
            return result;
        }

        _storeRepository.Update(store);

        await _storeRepository.SaveChangesAsync();

        return result;
    }
}
