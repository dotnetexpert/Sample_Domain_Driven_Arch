﻿using MediatR;
using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Stores;
using Sample.Stores.Domain.Stores.AnalyticsSummary;

namespace Sample.Stores.Application.Summary;

public record StoreAnalyticsSummaryQuery(StoreId StoreId) : IRequest<Result<SalesSummaryResult>>;
