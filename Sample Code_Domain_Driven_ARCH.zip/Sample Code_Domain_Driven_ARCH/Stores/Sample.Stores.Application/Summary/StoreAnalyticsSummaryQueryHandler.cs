﻿using MediatR;
using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Stores;
using Sample.Stores.Domain.Stores.AnalyticsSummary;

namespace Sample.Stores.Application.Summary;

public class StoreAnalyticsSummaryQueryHandler : IRequestHandler<StoreAnalyticsSummaryQuery, Result<SalesSummaryResult>>
{
    private readonly IStoreRepository _storeRepository;

    public StoreAnalyticsSummaryQueryHandler(IStoreRepository storeRepository)
    {
        _storeRepository = storeRepository;
    }

    public async Task<Result<SalesSummaryResult>> Handle(StoreAnalyticsSummaryQuery request, CancellationToken cancellationToken)
    {
        var orders = await _storeRepository.GetOrdersByStoreIdAsync(request.StoreId);

        if (!orders.Any())
        {
            return new SalesSummaryResult();
        }

        string currencyCode = orders?.SelectMany(p => p.OrderProducts).FirstOrDefault()?.Price.Currency ?? Currency.USDollar.Code;

        var result = new SalesSummaryResult
        {
            // Total Sales
            TotalSalesCount = orders.Count,
            TotalSalesAmount = Money.Of(orders.Sum(o => o.OrderProducts.Sum(p => p.Price.Amount * p.Quantity)), currencyCode),
            // Sales in the last 30 days
            SalesLast30DaysCount = orders.Count(o => o.Date >= DateTime.UtcNow.AddDays(-30)),
            SalesLast30DaysAmount = Money.Of(
                orders
                    .Where(o => o.Date >= DateTime.UtcNow.AddDays(-30))
                    .Sum(o => o.OrderProducts.Sum(p => p.Price.Amount * p.Quantity)),
                currencyCode
            ),
            // Popular Categories
            PopularCategories = orders
                .SelectMany(o => o.OrderProducts)
                .GroupBy(p => p.CategoryName)
                .Select(g => new CategorySales
                {
                    CategoryName = g.Key,
                    SalesCount = g.Sum(p => p.Quantity),
                    TotalAmount = Money.Of(g.Sum(p => p.Price.Amount * p.Quantity), currencyCode),
                })
                .OrderByDescending(c => c.SalesCount)
                .Take(3)
                .Select(c => new CategorySales
                {
                    CategoryName = c.CategoryName,
                    SalesCount = c.SalesCount,
                    TotalAmount = Money.Of(c.TotalAmount.Amount, currencyCode),
                })
                .ToList(),
            // Top 3 Sold Items
            TopSoldItems = orders
                .SelectMany(o => o.OrderProducts)
                .GroupBy(p => p.ProductName)
                .Select(g => new TopSoldItem
                {
                    ProductName = g.Key,
                    QuantitySold = g.Sum(p => p.Quantity),
                    TotalAmount = Money.Of(g.Sum(p => p.Price.Amount * p.Quantity), currencyCode),
                })
                .OrderByDescending(i => i.QuantitySold)
                .Take(3)
                .Select(i => new TopSoldItem
                {
                    ProductName = i.ProductName,
                    QuantitySold = i.QuantitySold,
                    TotalAmount = Money.Of(i.TotalAmount.Amount, currencyCode),
                })
                .ToList(),
            // Average Sale Amount
            AverageSaleAmount = orders.Any()
                ? Money.Of(orders.Average(o => o.OrderProducts.Sum(p => p.Price.Amount * p.Quantity)), currencyCode)
                : Money.Of(0, currencyCode),
            // Average Sale Amount Last 30 Days
            AverageSaleAmountLast30Days = orders.Where(o => o.Date >= DateTime.UtcNow.AddDays(-30)).Any()
                ? Money.Of(
                    orders
                        .Where(o => o.Date >= DateTime.UtcNow.AddDays(-30))
                        .Average(o => o.OrderProducts.Sum(p => p.Price.Amount * p.Quantity)),
                    currencyCode
                )
                : Money.Of(0, currencyCode),
        };

        return result;
    }
}
