﻿namespace Sample.Stores.Domain.Core;

public record CategoryId(Guid Value) : StronglyTypedId<Guid>(Value);
