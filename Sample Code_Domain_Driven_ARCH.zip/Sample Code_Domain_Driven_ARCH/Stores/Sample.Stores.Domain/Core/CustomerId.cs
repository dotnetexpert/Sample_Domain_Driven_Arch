﻿namespace Sample.Stores.Domain.Core;

public record CustomerId(Guid Value) : StronglyTypedId<Guid>(Value);
