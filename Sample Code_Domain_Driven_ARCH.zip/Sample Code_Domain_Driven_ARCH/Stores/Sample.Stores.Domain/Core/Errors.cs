﻿using Sample.Stores.Domain.Stores;

namespace Sample.Stores.Domain.Core;

public static class Errors
{
    public static class General
    {
        public static Error MoneyAmountMustBeGreaterThanZero(decimal amount) =>
            new("Money.Amount", $"'{amount}' must be greater than zero");

        public static Error UnauthorizedRequest() => new("Request.Unauthorized", "Unauthorized Request");

        public static Error QuantityGreaterThanZero(int quantity) =>
            new("Quantity.Positive", $"'{quantity}' must be greater than zero");

        public static Error NullOrWhiteSpaceString(string propertyName) =>
            new("String.NullOrWhiteSpace", $"'{propertyName}' cannot be null or white space");

        public static Error DateTimeMin() => new("DateTime.MinValue", $"DateTime cannot equal DateTime.MinValue.");

        public static Error EmptyGuid() => new("Guid.Empty", $"Guid value cannot equal Guid.Empty().");

        public static Error Null() => new("Null", $"Object is null.");

        public static Error NotFound(Guid id = new Guid()) => new("Id.NotFound", $"Id {id} not found.");

        public static Error ObjectAlreadyExists() => new("Id.AlreadyExists", $"Cannot create object, it already exists.");
    }

    public static class Review
    {
        public static Error InvalidRating(int rating) =>
            new Error("Review.InvalidRating", $"Rating {rating} must a value from 1 to 5");
    }

    public static class Message
    {
        public static Error MessageDataConnotBeEmpty() => new Error("Review.InvalidRating", $"MessageData connot be empty.");
    }

    public static class ShippingConfiguration
    {
        public static Error InvalidShippingCost(decimal cost, decimal min, decimal max) =>
            new Error("ShippingConfiguration.InvalidShippingCost", $"Shipping cost {cost:C} must be between {min:C} and {max:C}");
    }

    public static class Order
    {
        public static Error ReturnQuantityExceedsOrderQuantity(Guid productId) =>
            new Error(
                "Order.ReturnProduct",
                $"Cannot return a quantity greater than the remaining quantity of product {productId}."
            );

        public static Error ReviewNotFound() => new Error("Order.ReviewNotFound", $"Review not found");

        public static Error OrderNotFound(Guid orderId) =>
            new Error("Order.OrderNotFound", $"Order not found for OrderId: {orderId}");

        public static Error NotFound(Guid id) => new Error("Order.Ship", $"Order  {id} is not found.");

        public static Error ProductNotFound(Guid id) => new Error("Order.ReturnProduct", $"Order product {id} is not found.");

        public static Error FullRefundIssued(Guid id) =>
            new Error("Order.IssueFullRefund", $"A full refund has been issued for order {id} previously.");

        public static Error RefundAmountExceedsLimit(decimal amount, decimal threshold) =>
            new Error("Order.IssuePartialRefund", $"Refund of {amount:C} exceeds the refund threshold of {threshold:C}.");

        public static Error OrderMissingProducts() =>
            new Error("Order.Create", $"Order is missing products and cannot be created.");

        public static Error ShippingAddressMissing() =>
            new Error("Order.Create", $"Order is missing shipping address and cannot be created.");

        public static Error BillingAddressMissing() =>
            new Error("Order.Create", $"Order is missing billing address and cannot be created.");

        public static Error PaymentMethodMissing() => new Error("Order.Create", $"Payment method missing.");

        public static Error OrderMissingStoreOrders() =>
            new Error("Order.Create", $"Order is missing products and cannot be created.");

        public static Error NegativeOrMissingShippingCost() =>
            new Error("Order.Create", $"Order has a missing or negative shipping cost and cannot be created.");

        public static Error InvalidOrderId(Guid orderId) =>
            new Error("OrderRating.InvalidOrderId", $"Invalid order ID: '{orderId}'");

        public static Error InvalidDateOfOrder(DateTime dateOfOrder) =>
            new Error("OrderRating.InvalidDateOfOrder", $"Invalid date of order: '{dateOfOrder}'");

        public static Error InvalidDateOfRating(DateTime dateOfRating) =>
            new Error("OrderRating.InvalidDateOfRating", $"Invalid date of rating: '{dateOfRating}'");

        public static Error InvalidMessage(string message) =>
            new Error("OrderRating.InvalidMessage", $"Invalid message: '{message}'");

        public static Error InvalidUsername(string username) =>
            new Error("OrderRating.InvalidUsername", $"Invalid username: '{username}'");

        public static Error InvalidRating(int rating) =>
            new Error("OrderRating.InvalidRating", $"Invalid rating: '{rating}'. Rating must be between 1 and 5.");
    }

    public static class Refund
    {
        public static Error RefundNotFound(Guid id) => new Error("Order.ReturnProduct", $"Order refund {id} is not found.");

        public static Error RefundFailed() => new Error("Order.ReturnFailed", $"Refund Failed");

        public static Error AlreadyProcessed() => new Error("Order.Refund", $"Refund has already been processed!!");
    }

    public static class Store
    {
        public static Error StoreNotFound(Guid id) => new Error("Store.NotFound", $"Store not found with given order Id: {id}");

        public static Error UniqueStaffMemberEmailAddress(string emailAddress) =>
            new Error(
                "Store.AddStaffMember",
                $"Email address {emailAddress} is already is use. Staff email addresses must be unique."
            );

        public static Error InvalidProductCatalogId() =>
            new Error("Store.CreateStoreProduct", $"Product catalog Id is not valid");

        public static Error InvalidProductCatalogId(Guid id) =>
            new Error("Store.CreateStoreProduct", $"Product catalog Id {id} is not valid");

        public static Error InvalidExternalProductCatalogId(int id) =>
            new Error("Store.CreateStoreProduct", $"External product id {id} is not valid");

        public static Error InvalidExternalVariantCatalogId(int id) =>
            new Error("Store.CreateStoreProduct", $"External variant Id {id} is not valid");

        public static Error InvalidProductVariantId(Guid id) =>
            new Error("Store.CreateStoreProduct", $"Product variant Id {id} is not valid");

        public static Error ProductNotFound(Guid id) => new Error("Store.AddStaffMember", $"Store product {id} is not found.");

        public static Error NoOrderFound(Guid id) => new Error("Store.NoOrderFound", $"No orders found for the store id :{id}");

        public static Error StaffMemberExists() => new Error("Store.AddStaffMember", $"This staff member already exists.");

        public static Error StaffMemberMissing(Guid id) =>
            new Error("Store.RemoveStaffMember", $"Staff member {id} does not exist.");

        public static Error ReviewMissing(Guid id) => new Error("Store.RemoveReview", $"Review {id} does not exist.");

        public static Error InvalidRegistrationStatus(StoreRegistrationStatus newStatus, StoreRegistrationStatus currentStatus) =>
            new Error(
                "Store.SetRegistrationStatus",
                $"{newStatus.Name} is an invalid status when the current status is {currentStatus.Name}"
            );

        public static Error DuplicateEmailAddress() =>
            new Error("Store.EmailAddress", "A store with the same email address already exists.");

        public static Error DuplicateDomainName() =>
            new Error("Store.DomainName", "A store with the same domain name already exists.");

        public static Error StoreNotFoundByEmail() =>
            new Error("Store.StoreNotFoundByEmail", "Store not found with the provided email.");

        public static Error StoreNotFound() =>
            new Error("Store.StoreNotFound", "Store not found with the provided email store name and api key.");

        public static Error StoreIsDesynced() => new Error("Store.Desync", "Store has previously been desynced.");

        public static Error StoreIsConfirmed() => new Error("Store.Desync", "Store has previously been confirmed.");

        public static Error FailedToDisableStore() =>
            new Error(
                "Store.FailedToDisableStore",
                "Failed to disable the store. The store does not exist or could not be found."
            );

        public static Error StoreConfirmation() =>
            new Error(
                "Store.StoreConfirmation",
                "Store confirmation failed: Store not found with the provided email and confirmation code."
            );

        public static Error InitialHandshakeFailure() =>
            new Error(
                "Store.InitialHandshakeFailure",
                "Failed to create a new store due to an error in the initial handshake process."
            );

        public static Error InvalidStoreName(string name) => new Error("StoreProfile.Create", $"Invalid store name: '{name}'");

        public static Error InvalidEmailAddress(string emailAddress) =>
            new Error("StoreProfile.Create", $"Invalid email address: '{emailAddress}'");

        public static Error InvalidPhoneNumber(string phoneNumber) =>
            new Error("StoreProfile.Create", $"Invalid phone number: '{phoneNumber}'");

        public static Error InvalidStoreProfile() => new Error("Store.InvalidStoreProfile", "Invalid store profile.");

        public static Error ProfileNotFound() =>
            new Error("Store.ProfileNotFound", "Store profile not found with the provided id.");

        public static Error InboxNotFound(Guid storeId) =>
            new Error("Store.InboxNotFound", $"Store inbox not found with the given store Id: {storeId}");
    }

    public static class Email
    {
        public static Error EmailSendingFailed(string errorMessage) =>
            new Error("Email.SendingFailed", $"Email sending failed. Error: {errorMessage}");
    }

    public static class SummaryItem
    {
        public static Error NullTax() => new Error("SummaryItem.NullTax", "Tax cannot be null or white space");
    }

    public static class StoreOrderSummary
    {
        public static Error NullDate() => new Error("StoreOrderSummary.NullDate", "Date cannot be null or white space");
    }

    public static class Auth0
    {
        public static Error StoreNotRegistered() =>
            new Error("Auth0.StoreNotRegistered", "Store registeration failed: Store not registered with the provided email.");
    }

    public static class ProductExceptions
    {
        public static Error ProductNotFound() => new Error("ProductExceptions.ProductNotFound", "Product not found !!");
    }

    public static class ShippingOptions
    {
        public static Error InvalidSmallShippingConfiguration(decimal smallAmount) =>
            new Error(
                "UpdateShippingOptionsData.InvalidSmallShippingConfiguration",
                $"Small shipping cost {smallAmount:C} must be between 0 and 4.99."
            );

        public static Error InvalidMediumShippingConfiguration(decimal mediumAmount) =>
            new Error(
                "UpdateShippingOptionsData.InvalidMediumShippingConfiguration",
                $"Medium shipping cost {mediumAmount:C} must be between 0 and 9.99."
            );

        public static Error InvalidLargeShippingConfiguration(decimal largeAmount) =>
            new Error(
                "UpdateShippingOptionsData.InvalidLargeShippingConfiguration",
                $"Large shipping cost {largeAmount:C} must be between 0 and 24.99."
            );

        public static Error ShippingOptionsNotFound() =>
            new Error("ShippingOptions.NotFouond", $"Failed to fetch shipping options. ");
    }

    public static class StoreOrder
    {
        public static Error ProductNotFound(Guid id) =>
            new Error("Order.ReturnProduct", $"Product {id} not found in store order.");

        public static Error StoreOrdersNullOrMissing() => new Error("StoreOrder.Create", $"StoreOrders cannot be empty.");

        public static Error StoreNameNullOrWhiteSpace() =>
            new Error("StoreOrder.Create", $"Store name cannot be null or white space.");

        public static Error StoreEmailNulLOrWhiteSpace() =>
            new Error("StoreOrder.Create", $"Store email cannot be null or white space.");

        public static Error StoreIdNullOrEmpty(Guid? id) =>
            new Error("StoreOrder.Create", $"Store id cannot be null or an empty Guid.");

        public static Error ShippingMethodIdNullOrEmpty(Guid? id) =>
            new Error("StoreOrder.Create", $"Shipping method id {id} cannot be null or an empty Guid.");

        public static Error ShippingCostCannotBeNullOrNegative(Money shippingCost) =>
            new Error("StoreOrder.Create", $"Shipping cost {shippingCost?.Amount} cannot be null or have a negative amount.");
    }

    public static class OrderPaymentMethod
    {
        public static Error PaymentMethodNameNullOrWhiteSpace() =>
            new Error("OrderPaymentMethod.Create", $"Payment method name cannot be null or white space.");

        public static Error MaskNullOrWhiteSpace() =>
            new Error("OrderPaymentMethod.Create", $"Mask cannot be null or white space.");

        public static Error PaymentTokenNullOrWhiteSpace() =>
            new Error("OrderPaymentMethod.Create", $"Payment token cannot be null or white space.");

        public static Error PaymentMethodIdNullOrMissing(Guid? id) =>
            new Error("OrderPaymentMethod.Create", $"Payment method id {id} cannot be null or an empty Guid.");
    }

    public static class PopularItems
    {
        public static Error NoOrderedItemsFound() =>
            new Error("PopularItems.NotFound", "No Ordered Products found. There are no popular items to display.");
    }

    public static class Customer
    {
        public static Error NoSearchPreferenceFound(Guid customerId) =>
            new Error("Customer.UserPreference", $"No user preference found with customerId: {customerId}.");
    }

    public static class Merchant
    {
        public static Error NoMerchantFound(Guid storeId) =>
            new Error("Customer.UserPreference", $"Merchant associated with StoreId: {storeId} not found.");
    }
}
