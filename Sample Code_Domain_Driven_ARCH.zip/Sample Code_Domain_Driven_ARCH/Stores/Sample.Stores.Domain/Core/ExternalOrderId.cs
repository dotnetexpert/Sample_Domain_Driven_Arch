﻿namespace Sample.Stores.Domain.Core;

public record ExternalOrderId(int Value) : StronglyTypedId<int>(Value);
