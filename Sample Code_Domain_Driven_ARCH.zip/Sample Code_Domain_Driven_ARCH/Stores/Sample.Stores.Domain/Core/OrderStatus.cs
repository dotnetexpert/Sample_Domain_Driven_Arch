﻿namespace Sample.Stores.Domain.Core;

public class OrderStatus : Enumeration<OrderStatus>
{
    public static readonly OrderStatus AwaitingShipment = new OrderStatus(1, "Awaiting Shipment");
    public static readonly OrderStatus Shipped = new OrderStatus(2, "Shipped");

    private OrderStatus(int value, string name)
        : base(value, name) { }
}
