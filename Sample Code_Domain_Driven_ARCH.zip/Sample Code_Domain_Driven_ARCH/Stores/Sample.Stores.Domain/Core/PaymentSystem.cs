﻿namespace Sample.Stores.Domain.Core;

public class PaymentSystem : Enumeration<PaymentSystem>
{
    public static readonly PaymentSystem PayPal = new PaymentSystem(1, "PayPal");
    public static readonly PaymentSystem StoreCredit = new PaymentSystem(2, "StoreCredit");
    public static readonly PaymentSystem AuthorizeNet = new PaymentSystem(3, "Authorize.Net");

    private PaymentSystem(int value, string name)
        : base(value, name) { }

    public static PaymentSystem FromValue(int value)
    {
        switch (value)
        {
            case 1:
                return PayPal;
            case 2:
                return StoreCredit;
            case 3:
                return AuthorizeNet;
            default:
                return null;
        }
    }
}
