﻿namespace Sample.Stores.Domain.Core;

public record ProductCatalogId(Guid Value) : StronglyTypedId<Guid>(Value);
