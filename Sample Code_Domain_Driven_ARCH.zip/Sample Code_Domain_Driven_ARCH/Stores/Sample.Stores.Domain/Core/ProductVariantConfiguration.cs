﻿namespace Sample.Stores.Domain.Core;

public class ProductVariantConfiguration
{
    public List<string> NearMintKeywords { get; set; }
    public List<string> ModeratelyPlayedKeywords { get; set; }
    public List<string> SampleKeywords { get; set; }
    public List<string> LightlyPlayedKeywords { get; set; }
    public List<string> DamagedKeywords { get; set; }
}
