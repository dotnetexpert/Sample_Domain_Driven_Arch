﻿using Sample.Stores.Domain.Core;

public class ProductVariantTypesEnum : Enumeration<ProductVariantTypesEnum>
{
    public static readonly ProductVariantTypesEnum NearMint = new ProductVariantTypesEnum(1, "Near Mint");
    public static readonly ProductVariantTypesEnum NearMint1stEdition = new ProductVariantTypesEnum(2, "Near Mint 1st Edition");
    public static readonly ProductVariantTypesEnum NearMintUnlimited = new ProductVariantTypesEnum(3, "Near Mint Unlimited");
    public static readonly ProductVariantTypesEnum NearMintLimited = new ProductVariantTypesEnum(4, "Near Mint Limited");

    public static readonly ProductVariantTypesEnum LightlyPlayed = new ProductVariantTypesEnum(5, "Lightly Played");
    public static readonly ProductVariantTypesEnum LightlyPlayed1stEdition = new ProductVariantTypesEnum(
        6,
        "Lightly Played 1st Edition"
    );
    public static readonly ProductVariantTypesEnum LightlyPlayedUnlimited = new ProductVariantTypesEnum(
        7,
        "Lightly Played Unlimited"
    );
    public static readonly ProductVariantTypesEnum LightlyPlayedLimited = new ProductVariantTypesEnum(
        8,
        "Lightly Played Limited"
    );

    public static readonly ProductVariantTypesEnum ModeratelyPlayed = new ProductVariantTypesEnum(9, "Moderately Played");
    public static readonly ProductVariantTypesEnum ModeratelyPlayedUnlimited = new ProductVariantTypesEnum(
        10,
        "Moderately Played Unlimited"
    );
    public static readonly ProductVariantTypesEnum ModeratelyPlayed1stEdition = new ProductVariantTypesEnum(
        27,
        "Moderately Played 1st Edition"
    );
    public static readonly ProductVariantTypesEnum ModeratelyPlayedLimited = new ProductVariantTypesEnum(
        28,
        "Moderately Played Limited"
    );

    public static readonly ProductVariantTypesEnum Sample = new ProductVariantTypesEnum(11, "Heavily Played");
    public static readonly ProductVariantTypesEnum Sample1stEdition = new ProductVariantTypesEnum(
        12,
        "Heavily Played 1st Edition"
    );
    public static readonly ProductVariantTypesEnum SampleUnlimited = new ProductVariantTypesEnum(13, "Heavily Played Unlimited");
    public static readonly ProductVariantTypesEnum SampleLimited = new ProductVariantTypesEnum(14, "Heavily Played Limited");

    public static readonly ProductVariantTypesEnum Damaged = new ProductVariantTypesEnum(15, "Damaged");
    public static readonly ProductVariantTypesEnum Damaged1stEdition = new ProductVariantTypesEnum(16, "Damaged 1st Edition");
    public static readonly ProductVariantTypesEnum DamagedUnlimited = new ProductVariantTypesEnum(17, "Damaged Unlimited");
    public static readonly ProductVariantTypesEnum DamagedLimited = new ProductVariantTypesEnum(18, "Damaged Limited");

    public static readonly ProductVariantTypesEnum Sealed = new ProductVariantTypesEnum(19, "Sealed");
    public static readonly ProductVariantTypesEnum Sealed1stEdition = new ProductVariantTypesEnum(20, "Sealed 1st Edition");
    public static readonly ProductVariantTypesEnum SealedUnlimited = new ProductVariantTypesEnum(21, "Sealed Unlimited");
    public static readonly ProductVariantTypesEnum SealedLimited = new ProductVariantTypesEnum(22, "Sealed Limited");

    public static readonly ProductVariantTypesEnum BrandNew = new ProductVariantTypesEnum(23, "Brand New");
    public static readonly ProductVariantTypesEnum BrandNew1stEdition = new ProductVariantTypesEnum(24, "Brand New 1st Edition");
    public static readonly ProductVariantTypesEnum BrandNewUnlimited = new ProductVariantTypesEnum(25, "Brand New Unlimited");
    public static readonly ProductVariantTypesEnum BrandNewLimited = new ProductVariantTypesEnum(26, "Brand New Limited");

    private ProductVariantTypesEnum(int value, string name)
        : base(value, name) { }

    public static ProductVariantTypesEnum FromString(string name, ProductVariantConfiguration config)
    {
        if (string.IsNullOrWhiteSpace(name))
        {
            return null;
        }

        var lowercaseName = name.ToLowerInvariant();

        if (config.NearMintKeywords.Any(key => lowercaseName.Contains(key)))
        {
            if (lowercaseName.Contains("1st edition"))
                return NearMint1stEdition;

            if (lowercaseName.Contains("unl"))
                return NearMintUnlimited;

            if (lowercaseName.Contains("limited") || lowercaseName.Contains("ltd"))
                return NearMintLimited;

            return NearMint;
        }
        else if (config.LightlyPlayedKeywords.Any(key => lowercaseName.Contains(key)))
        {
            if (lowercaseName.Contains("1st edition"))
                return LightlyPlayed1stEdition;

            if (lowercaseName.Contains("unl"))
                return LightlyPlayedUnlimited;

            if (lowercaseName.Contains("limited") || lowercaseName.Contains("ltd"))
                return LightlyPlayedLimited;

            return LightlyPlayed;
        }
        else if (config.SampleKeywords.Any(key => lowercaseName.Contains(key)))
        {
            if (lowercaseName.Contains("1st edition"))
                return Sample1stEdition;

            if (lowercaseName.Contains("unl"))
                return SampleUnlimited;

            if (lowercaseName.Contains("limited") || lowercaseName.Contains("ltd"))
                return SampleLimited;

            return Sample;
        }
        else if (config.ModeratelyPlayedKeywords.Any(key => lowercaseName.Contains(key)))
        {
            if (lowercaseName.Contains("1st edition"))
                return ModeratelyPlayed1stEdition;

            if (lowercaseName.Contains("unlimited"))
                return ModeratelyPlayedUnlimited;

            if (lowercaseName.Contains("limited") || lowercaseName.Contains("ltd"))
                return ModeratelyPlayedLimited;

            return ModeratelyPlayed;
        }
        else if (config.DamagedKeywords.Any(key => lowercaseName.Contains(key)))
        {
            if (lowercaseName.Contains("1st edition"))
                return Damaged1stEdition;

            if (lowercaseName.Contains("unlimited"))
                return DamagedUnlimited;

            if (lowercaseName.Contains("limited") || lowercaseName.Contains("ltd"))
                return DamagedLimited;

            return Damaged;
        }
        else if (lowercaseName == "sealed")
        {
            if (lowercaseName.Contains("1st edition"))
                return Sealed1stEdition;

            if (lowercaseName.Contains("unl"))
                return SealedUnlimited;

            if (lowercaseName.Contains("limited"))
                return SealedLimited;

            return Sealed;
        }
        else if (lowercaseName == "new" || lowercaseName == "brand new")
        {
            if (lowercaseName.Contains("1st edition"))
                return BrandNew1stEdition;

            if (lowercaseName.Contains("unl"))
                return BrandNewUnlimited;

            if (lowercaseName.Contains("limited") || lowercaseName.Contains("ltd"))
                return BrandNewLimited;

            return BrandNew;
        }
        else
        {
            return null;
        }
    }
}
