﻿namespace Sample.Stores.Domain.Core;

public class ShippingType : Enumeration<ShippingType>
{
    public static readonly ShippingType Letter = new ShippingType(1, "Letter");
    public static readonly ShippingType Box = new ShippingType(2, "Box");
    public static readonly ShippingType LargePackage = new ShippingType(3, "Large Package");

    private ShippingType(int value, string name)
        : base(value, name) { }
}
