﻿namespace Sample.Stores.Domain.Core;

public class SortingPaginationOptions
{
    private const int DefaultPage = 1;
    private const int DefaultPageSize = 10;

    private int _page = DefaultPage;
    private int _pageSize = DefaultPageSize;

    public int Page
    {
        get => _page;
        set => _page = value <= 0 ? DefaultPage : value;
    }

    public int PageSize
    {
        get => _pageSize;
        set => _pageSize = value <= 0 ? DefaultPageSize : value;
    }

    public bool? SortByName { get; set; }
    public bool? SortByDate { get; set; }
    public bool? SortByRating { get; set; }
}
