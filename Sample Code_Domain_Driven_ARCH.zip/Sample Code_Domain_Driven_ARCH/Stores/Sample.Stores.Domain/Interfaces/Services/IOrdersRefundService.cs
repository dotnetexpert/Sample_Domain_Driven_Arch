﻿using Sample.Stores.Domain.Stores;

namespace Sample.Stores.Domain.Interfaces.Services;

public interface IOrdersRefundService
{
    Task<Guid> IssueFullRefundAsync(Guid orderId);
    Task<Guid> IssuePartialRefundAsync(Guid orderId, decimal subtotal, decimal tax, decimal shippingCost);
    Task<Guid> RefundProductAsync(Guid orderId, IEnumerable<ProductReturn> returns);
}
