﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Orders;

public class OrderPaymentMethod : ValueObject<OrderPaymentMethod>
{
    public OrderPaymentMethodId PaymentMethodId { get; set; }
    public string Mask { get; set; }
    public string Name { get; set; }
    public string Token { get; set; }

    public static Result<OrderPaymentMethod> Create(
        OrderPaymentMethodId orderPaymentMethodId,
        string mask,
        string name,
        string token
    )
    {
        if (string.IsNullOrWhiteSpace(mask))
            return Result.Failure<OrderPaymentMethod>(Errors.OrderPaymentMethod.MaskNullOrWhiteSpace());

        if (string.IsNullOrWhiteSpace(token))
            return Result.Failure<OrderPaymentMethod>(Errors.OrderPaymentMethod.PaymentTokenNullOrWhiteSpace());

        if (string.IsNullOrWhiteSpace(name))
            return Result.Failure<OrderPaymentMethod>(Errors.OrderPaymentMethod.PaymentMethodNameNullOrWhiteSpace());

        if (orderPaymentMethodId == null || orderPaymentMethodId.Value == Guid.Empty)
            return Result.Failure<OrderPaymentMethod>(
                Errors.OrderPaymentMethod.PaymentMethodIdNullOrMissing(orderPaymentMethodId?.Value)
            );

        return new OrderPaymentMethod(orderPaymentMethodId, mask, name, token);
    }

    private OrderPaymentMethod(OrderPaymentMethodId orderPaymentMethodId, string mask, string name, string token)
    {
        PaymentMethodId = orderPaymentMethodId;
        Mask = mask;
        Name = name;
        Token = token;
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Token;
        yield return PaymentMethodId;
        yield return Mask;
        yield return Name;
    }

    private OrderPaymentMethod() { }
}
