﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Orders;

public record OrderPaymentMethodId(Guid Value) : StronglyTypedId<Guid>(Value);
