﻿using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Stores;

namespace Sample.Stores.Domain.Orders;

public record OrderProductData(
    StoreProductId StoreProductId,
    ProductCatalogId ProductCatalogId,
    string ProductName,
    CategoryId CategoryId,
    string CateoryName,
    Money UnitPrice,
    Money UnitTax,
    int Quantity,
    PackageType PackageType,
    string ProductImageUrl,
    Dictionary<string, string> Variant,
    bool isPreOrder,
    DateTime? releaseDate
);
