﻿using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Stores;

namespace Sample.Stores.Domain.Orders;

public record StoreOrderData(
    StoreId StoreId,
    string StoreName,
    string StoreEmail,
    List<OrderProductData> OrderProductData,
    ShippingOptionId ShippingMethodId,
    Money ShippingCost
);
