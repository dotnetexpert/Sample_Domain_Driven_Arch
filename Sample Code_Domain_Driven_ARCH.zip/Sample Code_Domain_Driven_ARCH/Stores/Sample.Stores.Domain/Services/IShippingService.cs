﻿namespace Sample.Stores.Domain.Services;

public interface IShippingService { }
