﻿namespace Sample.Stores.Domain.Services;

public class ShippingService : IShippingService { }
