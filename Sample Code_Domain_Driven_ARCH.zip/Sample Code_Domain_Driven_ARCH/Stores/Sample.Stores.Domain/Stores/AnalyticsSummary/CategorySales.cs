﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores.AnalyticsSummary;

public class CategorySales
{
    public string CategoryName { get; set; }
    public int SalesCount { get; set; }
    public Money TotalAmount { get; set; }
}
