﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores.AnalyticsSummary;

public class SalesSummaryResult
{
    public int TotalSalesCount { get; set; }
    public Money TotalSalesAmount { get; set; }
    public int SalesLast30DaysCount { get; set; }
    public Money SalesLast30DaysAmount { get; set; }
    public List<CategorySales> PopularCategories { get; set; }
    public List<TopSoldItem> TopSoldItems { get; set; }
    public Money AverageSaleAmount { get; set; }
    public Money AverageSaleAmountLast30Days { get; set; }
}
