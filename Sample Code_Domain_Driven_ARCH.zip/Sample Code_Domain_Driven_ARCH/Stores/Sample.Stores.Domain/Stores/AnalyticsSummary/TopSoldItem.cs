﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores.AnalyticsSummary;

public class TopSoldItem
{
    public string ProductName { get; set; }
    public int QuantitySold { get; set; }
    public Money TotalAmount { get; set; }
}
