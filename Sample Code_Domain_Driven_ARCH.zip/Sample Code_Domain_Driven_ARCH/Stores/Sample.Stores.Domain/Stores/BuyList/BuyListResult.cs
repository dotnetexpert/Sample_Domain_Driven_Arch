﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores.BuyList;

public class BuyListResult : ValueObject<BuyListResult>
{
    public Guid StoreProductId { get; private set; }
    public Guid StoreId { get; private set; }
    public Guid ProductCatalogId { get; private set; }
    public Guid ProductVariantId { get; private set; }
    public string ProductName { get; private set; }
    public string ImageUrl { get; private set; }
    public string CategoryName { get; private set; }
    public int Quantity { get; private set; }
    public Dictionary<string, string> Variants { get; private set; }
    public Money BuyPrice { get; private set; }
    public int NumberOfBuyers { get; private set; }

    private BuyListResult(
        Guid storeProductId,
        Guid storeId,
        Guid productCatalogId,
        Guid productVariantId,
        string productName,
        string imageUrl,
        string categoryName,
        int quantity,
        Dictionary<string, string> variants,
        Money buyPrice,
        int numberOfBuyers
    )
    {
        StoreProductId = storeProductId;
        StoreId = storeId;
        ProductCatalogId = productCatalogId;
        ProductVariantId = productVariantId;
        ProductName = productName;
        ImageUrl = imageUrl;
        CategoryName = categoryName;
        Quantity = quantity;
        Variants = variants;
        BuyPrice = buyPrice;
        NumberOfBuyers = numberOfBuyers;
    }

    public static Result<BuyListResult> Create(
        Guid storeProductId,
        Guid storeId,
        Guid productCatalogId,
        Guid productVariantId,
        string productName,
        string imageUrl,
        string categoryName,
        int quantity,
        Dictionary<string, string> variants,
        Money buyPrice,
        int numberOfBuyers
    )
    {
        return Result.Success(
            new BuyListResult(
                storeProductId,
                storeId,
                productCatalogId,
                productVariantId,
                productName,
                imageUrl,
                categoryName,
                quantity,
                variants,
                buyPrice,
                numberOfBuyers
            )
        );
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return StoreProductId;
        yield return StoreId;
        yield return ProductCatalogId;
        yield return ProductVariantId;
        yield return ProductName;
        yield return ImageUrl;
        yield return CategoryName;
        yield return Quantity;
        yield return Variants;
        yield return BuyPrice;
        yield return NumberOfBuyers;
    }
}
