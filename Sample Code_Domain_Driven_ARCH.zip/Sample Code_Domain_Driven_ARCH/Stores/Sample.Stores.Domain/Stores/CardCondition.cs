﻿namespace Sample.Stores.Domain.Stores;

public enum CardCondition
{
    Damaged = 0,
    Heavily_Played = 1,
    Moderately_Played = 2,
    Lightly_Played = 3,
    Near_Mint = 4,
    Sealed = 5,
    Brand_New = 6,
}
