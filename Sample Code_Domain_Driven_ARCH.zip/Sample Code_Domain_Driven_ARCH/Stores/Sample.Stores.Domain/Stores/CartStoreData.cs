﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class CartStoreData : ValueObject<CartStoreData>
{
    public StoreId StoreId { get; private set; }
    public string StoreName { get; private set; }
    public string DomainName { get; private set; }
    public string StoreEmailAddress { get; private set; }
    public int StoreProductQuantity { get; private set; }
    public StoreProductId StoreProductId { get; private set; }
    public Money ProductPrice { get; private set; }
    public ProductCatalogId ProductCatalogId { get; private set; }
    public string ProductName { get; private set; }
    public ShippingOptions ShippingOptions { get; private set; }
    public ShippingOptionId ShippingOptionId { get; private set; }
    public ExternalProductId ExternalProductId { get; private set; }
    public ExternalVariantId ExternalVariantId { get; private set; }

    private CartStoreData(
        StoreId storeId,
        string storeName,
        string domainName,
        string storeEmailAddress,
        int storeProductQuantity,
        StoreProductId storeProductId,
        Money productPrice,
        ProductCatalogId productCatalogId,
        string productName,
        ShippingOptions shippingOptions,
        ExternalProductId externalProductId,
        ExternalVariantId externalVariantId
    )
    {
        StoreId = storeId;
        StoreName = storeName;
        DomainName = domainName;
        StoreEmailAddress = storeEmailAddress;
        StoreProductQuantity = storeProductQuantity;
        StoreProductId = storeProductId;
        ProductPrice = productPrice;
        ProductCatalogId = productCatalogId;
        ProductName = productName;
        ShippingOptions = shippingOptions;
        ShippingOptionId = shippingOptions.Id;
        ExternalProductId = externalProductId;
        ExternalVariantId = externalVariantId;
    }

    public static Result<CartStoreData> Create(
        StoreId storeId,
        string storeName,
        string domainName,
        string storeEmailAddress,
        int storeProductQuantity,
        StoreProductId storeProductId,
        Money productPrice,
        ProductCatalogId productCatalogId,
        string productName,
        ShippingOptions shippingOptions,
        ExternalProductId externalProductId,
        ExternalVariantId externalVariantId
    )
    {
        return Result.Success(
            new CartStoreData(
                storeId,
                storeName,
                domainName,
                storeEmailAddress,
                storeProductQuantity,
                storeProductId,
                productPrice,
                productCatalogId,
                productName,
                shippingOptions,
                externalProductId,
                externalVariantId
            )
        );
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return StoreId;
        yield return StoreName;
        yield return DomainName;
        yield return StoreEmailAddress;
        yield return StoreProductQuantity;
        yield return StoreProductId;
        yield return ProductPrice;
        yield return ProductCatalogId;
        yield return ProductName;
        yield return ShippingOptions;
        yield return ShippingOptionId;
        yield return ExternalProductId;
        yield return ExternalVariantId;
    }
}
