﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class ContactInformation : ValueObject<ContactInformation>
{
    public string? FirstName { get; private set; }
    public string? LastName { get; private set; }
    public string? EmailAddress { get; private set; }
    public string? PhoneNumber { get; private set; }
    public bool? UsedOnlyForEntityFramework { get; set; }

    public static ContactInformation Create(string firstName, string lastName, string emailAddress, string phoneNumber)
    {
        if (string.IsNullOrWhiteSpace(firstName))
            throw new Exception("First Name cannot be null or whitespace.");

        if (string.IsNullOrWhiteSpace(lastName))
            throw new Exception("Last Name cannot be null or whitespace.");

        // TODO: Validate email address?
        if (string.IsNullOrWhiteSpace(emailAddress))
            throw new Exception("Email Address cannot be null or whitespace.");

        // TODO: Validate phone number?
        if (string.IsNullOrWhiteSpace(phoneNumber))
            throw new Exception("Phone Number cannot be null or whitespace.");

        return new ContactInformation(firstName, lastName, emailAddress, phoneNumber);
    }

    private ContactInformation(string firstName, string lastName, string emailAddress, string phoneNumber)
    {
        FirstName = firstName;
        LastName = lastName;
        EmailAddress = emailAddress;
        PhoneNumber = phoneNumber;
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return EmailAddress;
        yield return PhoneNumber;
        yield return LastName;
        yield return FirstName;
    }

    private ContactInformation() { }
}
