﻿namespace Sample.Stores.Domain.Stores;

public record CustomerReview(
    Guid StoreId,
    Guid OrderId,
    int Rating,
    string Comment,
    Guid CustomerId,
    string CustomerName,
    DateTime Date
);
