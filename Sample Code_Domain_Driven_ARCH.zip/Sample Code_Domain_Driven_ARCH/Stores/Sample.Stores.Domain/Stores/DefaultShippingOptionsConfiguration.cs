﻿namespace Sample.Stores.Domain.Stores;

public class DefaultShippingOptionsConfiguration
{
    public CountryShippingOptions US { get; init; }
    public CountryShippingOptions CA { get; init; }
}

public class CountryShippingOptions
{
    public decimal SmallPackageShippingCost { get; init; }
    public decimal MediumPackageShippingCost { get; init; }
    public decimal LargePackageShippingCost { get; init; }
    public decimal FreeShippingThreshold { get; init; }
    public decimal TrackingRequiredThreshold { get; init; }
}
