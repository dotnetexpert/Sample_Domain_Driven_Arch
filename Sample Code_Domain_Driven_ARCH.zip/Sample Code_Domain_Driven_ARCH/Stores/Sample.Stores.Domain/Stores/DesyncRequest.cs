﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Sample.Stores.Domain.Stores;

public class DesyncRequest
{
    [JsonPropertyName("email")]
    [Required]
    public string Email { get; set; }
}
