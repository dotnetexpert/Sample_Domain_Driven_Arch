﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public record ExternalProductId(int Value) : StronglyTypedId<int>(Value);
