﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public record ExternalVariantId(int Value) : StronglyTypedId<int>(Value);
