﻿namespace Sample.Stores.Domain.Stores;

public class GlobalShippingConfiguration
{
    public decimal MinimumLetterShippingCost { get; init; }
    public decimal MaximumLetterShippingCost { get; init; }
    public decimal MinimumBoxShippingCost { get; init; }
    public decimal MaximumBoxShippingCost { get; init; }
    public decimal MinimumLargePackageShippingCost { get; init; }
    public decimal MaximumLargePackageShippingCost { get; init; }
}
