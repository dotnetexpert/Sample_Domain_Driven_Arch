﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public interface IStoreRepository
{
    Task<Store> GetByIdAsync(StoreId id);
    Task<List<StoreId>> GetAllStoreIds();
    Task<Store> GetByTrackingIdAsync(Guid trackingId);
    Task<Store> GetStoreByDomainNameAndAPIKeyAsync(string storeDomainName, string apiKey);
    Task<Order> GetStoreWithOrderById(StoreId id, OrderId orderId);
    Task<Store> GetOrderMessages(OrderId OrderId, StoreId StoreId);
    Task<Store> GetWithOrdersAsync(StoreId id, OrderId orderId);
    Task<Order> GetOrderByExternalOrderIdAsync(ExternalOrderId externalOrderId, StoreId storeId);
    Task<Order> GetOrderByIdAsync(OrderId orderId);
    Task<List<Order>> GetOrdersByStoreIdAsync(StoreId storeId);
    void Update(Store store);
    void Add(Store store);
    void Add(ShippingOptions shippingOptions);
    Task SaveChangesAsync();
    Task<Store> GetWithStaffAsync(StoreId id);
    Task<Store> GetWithReviewsAsync(StoreId id);
    Task<Store> GetWithProductsAsync(StoreId id);
    Task<IEnumerable<Order>> GetOrderRatingList(StoreId id, SortingPaginationOptions sortingPaginationOptions);
    Task<Store> GetWithOrdersAndRefundsAsync(StoreId id);
    Task<RefundId> GetRefundIdAsync(StoreId id, OrderId orderId, decimal total);
    Task<Store> GetWithOrdersAndStores(StoreId id, OrderId orderId);
    Task<IEnumerable<Dictionary<string, string>>> GetStoreProductVariants(ProductCatalogId storeProductCatalogId);

    Task<IEnumerable<StoreProduct>> GetStoreProducts(IEnumerable<ProductCatalogId> productCatalogIds);
    Task<Dictionary<List<Store>, int>> GetStoresWithProductIdAsync(
        ProductCatalogId id,
        PaginationAndSortingOptions paginationOptions,
        string countryCode
    );
    Task<IEnumerable<StoreInboxItem>> GetStoreInbox(StoreId id);
    Task<ShippingOptions> GetShippingOptions(StoreId id);
    Task<ShippingOptions> GetShippingOptionsByCountry(StoreId id, string countryCode);
    Task<Store> GetStoreShippingOptionsAsync(StoreId id);
    Task<ShippingOptions> GetShippingOptions(StoreId id, string countryCode);
    Task<Store> GetStoreShippingOptions(StoreId id);
    Task<IEnumerable<OrderHistoryItem>> GetStoreOrderHistory(OrderId id, StoreId storeId);
    Task<List<Order>> GetStoreOrderHistory(StoreId storeId, string searchText, int page, int pageSize);
    Task<Store> GetStoreConfirmationAsync(string email, string confirmationCode);
    Task<Store> FindStoreByEmailAsync(string email);
    Task<Store> GetStoreAsync(StoreId id);
    Task<bool> IsDomainDuplicateAsync(string domainName);
    Task<bool> IsEmailDuplicateAsync(string email);
    Task<Store> GetStoreByIdAsync(StoreId storeId);
    Task<CartStoreData> GetDataForCart(StoreId id, StoreProductId storeProductId, string countryCode);
    Task<Store> GetDataForTradeInCart(StoreId storeId, StoreProductId storeProductId);
    Task<Store?> GetWithRegistrationAsync(StoreId id);
    Task<IEnumerable<StoreProduct>> GetProductsByCatalogIdAsync(StoreId storeId, ProductCatalogId productCatalogId);
    Task<Dictionary<Store, List<StoreProduct>>> GetStoreProductsByCatalogAndVariantsAsync(
        List<ProductCatalogId> productCatalogIds,
        IEnumerable<string> variantTypes
    );
    Task<IEnumerable<StoreProduct>> GetBuyListData(PaginationAndSortingOptions paginationOptions);
    Task<Store?> GetExistsButIsntActive(string domainName);
    Task<IEnumerable<StoreId>> GetIdListAsync();
    Task<List<StoreProduct>> GetProductsByIdListAsync(List<StoreProductId> ids);
    Task<Dictionary<Guid, decimal>> GetFreeShippingThresholdMapping(List<StoreId> ids);
    Task<StoreProduct> GetProductByExternalProductIdAsync(
        ExternalProductId externalProductId,
        ExternalVariantId externalVariantId,
        StoreId storeId
    );
    Task<int> GetTotalRatings(StoreId storeId);
    Task<StoreProduct> GetStoreWithProduct(StoreId storeId, StoreProductId storeProductId);
    Task<List<Store>> GetStoresWithShippingOptions(List<StoreId> storeId);

    Task<(int StoreCount, decimal LowestPrice)> GetStoreCountAndLowestPriceAsync(ProductCatalogId productCatalogId);
    Task<Dictionary<StoreId, List<ProductData>>> GetStoreProductsWithLeastPrice(
        bool keepCurrentConditions,
        string minimumCondition,
        Dictionary<ProductVariantId, int> productVariantQuantities,
        Dictionary<ProductCatalogId, int> productQuantities
    );

    Task<Dictionary<StoreId, List<ProductData>>> GetStoreProductsWithMinimumPackages(
        bool keepCurrentConditions,
        string minimumCondition,
        Dictionary<ProductVariantId, int> productVariantQuantities,
        Dictionary<ProductCatalogId, int> productQuantities
    );
    Task<List<Guid>> GetPaymentReceivableProductCatalogIdsAsync(List<Guid> productCatalogIds);
    Task<Store> GetWithShippingOptions(StoreId id);
}
