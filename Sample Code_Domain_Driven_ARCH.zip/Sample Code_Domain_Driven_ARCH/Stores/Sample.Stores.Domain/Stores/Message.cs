﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class Message : ValueObject<Message>
{
    public Guid FromId { get; private set; }
    public string FromName { get; private set; }
    public string Subject { get; private set; }
    public string Body { get; private set; }
    public bool IsRead { get; private set; }
    public DateTime Date { get; private set; } = DateTime.UtcNow;

    public static Result<Message> Create(Guid fromId, string fromName, string subject, string body)
    {
        if (Guid.Empty == fromId)
            Result.Failure<Review>(Errors.General.EmptyGuid());

        if (string.IsNullOrWhiteSpace(fromName))
            Result.Failure<Review>(Errors.General.NullOrWhiteSpaceString(fromName));

        if (string.IsNullOrWhiteSpace(subject))
            Result.Failure<Review>(Errors.General.NullOrWhiteSpaceString(subject));

        if (string.IsNullOrWhiteSpace(body))
            Result.Failure<Review>(Errors.General.NullOrWhiteSpaceString(body));

        return new Message(fromId, fromName, subject, body);
    }

    public void MarkAsRead()
    {
        IsRead = true;
    }

    private Message(Guid fromId, string fromName, string subject, string body)
    {
        FromId = fromId;
        FromName = fromName;
        Subject = subject;
        Body = body;
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return FromId;
        yield return FromName;
        yield return Subject;
        yield return Body;
        yield return Date;
    }

    private Message() { }
}
