﻿namespace Sample.Stores.Domain.Stores;

public record MessageData(Guid FromId, string FromName, string Subject, string Body);
