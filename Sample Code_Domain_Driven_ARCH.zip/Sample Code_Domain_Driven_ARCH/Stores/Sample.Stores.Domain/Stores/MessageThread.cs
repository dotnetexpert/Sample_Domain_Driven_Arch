﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class MessageThread : ValueObject<MessageThread>
{
    public List<Message> Messages { get; private set; }
    public string StoreName { get; private set; }
    public Guid OrderId { get; private set; }

    public static Result<MessageThread> Create(List<Message> messages, string storeName, Guid orderId)
    {
        if (messages == null)
            return Result.Failure<MessageThread>(Errors.General.Null());

        if (string.IsNullOrWhiteSpace(storeName))
            return Result.Failure<MessageThread>(Errors.General.NullOrWhiteSpaceString(storeName));

        if (orderId == null)
            return Result.Failure<MessageThread>(Errors.General.Null());

        if (Guid.Empty == orderId)
            Result.Failure<MessageThread>(Errors.General.EmptyGuid());

        return Result.Success(new MessageThread(messages, storeName, orderId));
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Messages;
        yield return StoreName;
        yield return OrderId;
    }

    private MessageThread(List<Message> messages, string storeName, Guid orderId)
    {
        Messages = messages;
        StoreName = storeName;
        OrderId = orderId;
    }
}
