﻿using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Orders;

namespace Sample.Stores.Domain.Stores;

public class Order : Entity<OrderId>
{
    public StoreId StoreId { get; set; }
    public string StoreName { get; private set; }
    public string StoreEmail { get; private set; }
    public OrderId OrderId { get; private set; }
    public ShippingOptionId ShippingOptionId { get; private set; }
    public int? ExternalShippingOptionId { get; private set; }
    public Money ShippingCost { get; private set; }
    public Money ShippingTax { get; private set; }
    public OrderCustomer Customer { get; private set; }
    public OrderPaymentMethod PaymentMethod { get; private set; }
    public DateTime Date { get; private set; }
    public Address ShippingAddress { get; private set; }
    public Address BillingAddress { get; private set; }
    public Review Review { get; private set; }
    public OrderStatus OrderStatus { get; private set; } = OrderStatus.AwaitingShipment;
    public DateTime? ShippedAt { get; private set; }
    public DateTime? LastModified { get; private set; }
    public DateTime? MinimumShippingDate { get; private set; }
    public string? TrackingNumber { get; private set; }
    public ExternalOrderId? ExternalOrderId { get; private set; }

    public Money Amount
    {
        get { return Money.Of(_orderProducts.Sum(i => i.Price.Amount * i.Quantity), Currency.USDollar.Code); }
    }
    public Money Tax
    {
        get { return Money.Of(_orderProducts.Sum(i => i.Tax.Amount * i.Quantity), Currency.USDollar.Code); }
    }

    public Money Total
    {
        get { return Money.Of(Amount.Amount + Tax.Amount + ShippingCost.Amount + ShippingTax.Amount, Currency.USDollar.Code); }
    }

    public Money SubTotal
    {
        get { return Money.Of(_orderProducts.Sum(t => t.Price.Amount * t.Quantity), Currency.USDollar.Code); }
    }

    private readonly List<Refund> _refunds = new List<Refund>();
    public IReadOnlyCollection<Refund> Refunds => _refunds.AsReadOnly();

    private readonly List<OrderProduct> _orderProducts = new List<OrderProduct>();
    public IReadOnlyCollection<OrderProduct> OrderProducts => _orderProducts.AsReadOnly();

    private readonly List<Message> _messages = new List<Message>();
    public IReadOnlyCollection<Message> Messages => _messages.AsReadOnly();

    public static Result<Order> Create(PackageId packageId, StoreId storeId, OrderData orderData)
    {
        if (orderData.ShippingAddress == null)
            return Result.Failure<Order>(Errors.Order.ShippingAddressMissing());

        if (orderData.BillingAddress == null)
            return Result.Failure<Order>(Errors.Order.BillingAddressMissing());

        if (orderData.OrderProductData == null || !orderData.OrderProductData.Any())
            return Result.Failure<Order>(Errors.Order.OrderMissingStoreOrders());

        if (orderData.Customer == null)
            throw new Exception("Customer is required");

        var orderItems = orderData
            .OrderProductData.Select(o =>
                OrderProduct.Create(
                    o.StoreProductId,
                    o.ProductCatalogId,
                    o.ProductName,
                    o.CategoryId,
                    o.CateoryName,
                    o.UnitPrice,
                    o.Quantity,
                    o.UnitTax,
                    o.PackageType,
                    o.ProductImageUrl,
                    o.Variant,
                    o.isPreOrder,
                    o.releaseDate
                )
            )
            .ToList();

        var orderItemList = orderItems.Select(i => i.Value).ToList();

        return new Order(
            packageId,
            storeId,
            orderData.Customer,
            orderData.StoreOrderData.StoreName,
            orderData.StoreOrderData.StoreEmail,
            new(orderData.StoreOrderData.OrderId.Value),
            orderData.StoreOrderData.ShippingOptionId,
            orderData.StoreOrderData.ExternalShippingOptionId,
            orderData.StoreOrderData.ShippingCost,
            orderData.StoreOrderData.ShippingTax,
            orderData.PaymentMethod,
            orderData.BillingAddress,
            orderData.ShippingAddress,
            orderItemList,
            orderData.CreatedAt,
            orderData.StoreOrderData.ExternalOrderId,
            orderData.StoreOrderData.MinimumShippingDate
        );
    }

    private Order(
        PackageId packageId,
        StoreId storeId,
        OrderCustomer customer,
        string storeName,
        string storeEmail,
        OrderId orderId,
        ShippingOptionId shippingOptionId,
        int? externalShippingOptionId,
        Money shippingCost,
        Money shippingTax,
        OrderPaymentMethod orderPaymentMethod,
        Address shippingAddress,
        Address billlingAddress,
        List<OrderProduct> products,
        DateTime createdAt,
        ExternalOrderId? externalOrderId,
        DateTime? minimumShippingDate
    )
    {
        Id = new OrderId(packageId.Value);
        StoreId = storeId;
        StoreName = storeName;
        StoreEmail = storeEmail;
        OrderId = orderId;
        ShippingOptionId = shippingOptionId;
        ExternalShippingOptionId = externalShippingOptionId;
        ShippingCost = shippingCost;
        ShippingTax = shippingTax;
        Customer = customer;
        PaymentMethod = orderPaymentMethod;
        ShippingAddress = shippingAddress;
        BillingAddress = billlingAddress;
        _orderProducts = products;
        Date = createdAt;
        ExternalOrderId = externalOrderId;
        MinimumShippingDate = minimumShippingDate;
    }

    public void SetTrackingNumber(string trackingNumber)
    {
        TrackingNumber = trackingNumber;
        LastModified = DateTime.UtcNow;
    }

    public void SetExternalOrderId(ExternalOrderId externalOrderId)
    {
        ExternalOrderId = externalOrderId;
    }

    public void Ship(DateTime shippedOn)
    {
        OrderStatus = OrderStatus.Shipped;
        ShippedAt = shippedOn;
        LastModified = DateTime.UtcNow;
    }

    public Result CompleteRefund(RefundId refundId, OrdersRefundId ordersRefundId)
    {
        var refund = _refunds.FirstOrDefault(r => r.Id == refundId);

        if (refund is null)
            return Result.Failure(Errors.Refund.RefundNotFound(refundId.Value));

        refund.Complete(ordersRefundId);

        return Result.Success();
    }

    public Result ProcessFailedRefund(RefundId refundId, string errorDetails)
    {
        var refund = _refunds.FirstOrDefault(r => r.Id == refundId);

        if (refund is null)
            return Result.Failure(Errors.Refund.RefundNotFound(refundId.Value));

        refund.ProcessFailure(errorDetails);

        return Result.Success();
    }

    public Result<Refund> AddRefund(RefundData refund)
    {
        var result = Refund.Create(
            Id,
            refund.Amount,
            refund.Tax,
            refund.StoreId,
            refund.RefundDetails,
            Customer.CustomerId,
            Guid.Empty,
            null
        );

        if (result.IsFailure)
        {
            return result;
        }

        _refunds.Add(result.Value);

        return result;
    }

    public Result RecordMessage(MessageData messageData)
    {
        if (messageData == null)
        {
            return Result.Failure(Errors.Message.MessageDataConnotBeEmpty());
        }

        var result = Message.Create(messageData.FromId, messageData.FromName, messageData.Subject, messageData.Body);

        if (result.IsFailure)
            return result;

        _messages.Add(result.Value);

        return result;
    }

    public Result<Review> AddReview(ReviewData reviewData)
    {
        if (reviewData == null)
        {
            return Result.Failure<Review>(Errors.General.Null());
        }

        if (Review != null)
        {
            return Result.Failure<Review>(Errors.General.ObjectAlreadyExists());
        }

        var result = Review.Create(
            StoreId,
            new OrderId(reviewData.PackageId),
            reviewData.Rating,
            reviewData.Comment,
            reviewData.Customer,
            reviewData.Date
        );

        if (result.IsFailure)
            return result;

        Review = result.Value;

        return result;
    }

    public Result RemoveReview()
    {
        if (Review == null)
        {
            return Result.Failure(Errors.Order.ReviewNotFound());
        }

        Review = null;

        return Result.Success();
    }

    public Result UpdateReview(ReviewUpdatedData reviewData)
    {
        if (reviewData == null)
        {
            return Result.Failure<Review>(Errors.General.Null());
        }
        if (Review == null)
        {
            return Result.Failure(Errors.General.NotFound());
        }
        Review.UpdateReview(reviewData.Rating, reviewData.Comment, reviewData.Date);
        return Result.Success();
    }

    public void RecordMessage(Message message)
    {
        _messages.Add(message);
    }

    public void AddRefund(Refund refund)
    {
        _refunds.Add(refund);
    }

    public Result<Message> AddMessage(MessageData messageData)
    {
        var result = Message.Create(messageData.FromId, StoreName, messageData.Subject, messageData.Body);

        if (result.IsFailure)
            return result;

        _messages.Add(result.Value);

        return result;
    }

    private Order() { }
}
