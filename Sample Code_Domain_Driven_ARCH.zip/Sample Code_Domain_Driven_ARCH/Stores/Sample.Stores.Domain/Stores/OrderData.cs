﻿using MediatR;
using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Orders;

namespace Sample.Stores.Domain.Stores;

public record OrderData(
    OrderCustomer Customer,
    StoreOrderData StoreOrderData,
    OrderPaymentMethod PaymentMethod,
    List<OrderProductData> OrderProductData,
    Address BillingAddress,
    Address ShippingAddress,
    DateTime CreatedAt
) : IRequest<Result>;
