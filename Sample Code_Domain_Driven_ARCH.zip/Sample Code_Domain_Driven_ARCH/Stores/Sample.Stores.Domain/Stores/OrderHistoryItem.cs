﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class OrderHistoryItem : ValueObject<OrderHistoryItem>
{
    public Money Subtotal { get; private set; }
    public Money Shipping { get; private set; }
    public Money Tax { get; private set; }
    public Money SummaryTotal { get; private set; }
    public DateTime OrderDate { get; private set; }
    public string StoreName { get; private set; }
    public Guid OrderNumber { get; private set; }
    public decimal OrderRating { get; private set; }
    public string Comment { get; private set; }
    public DateTime? MinimumShippingDate { get; private set; }

    public ICollection<OrderProduct>? OrderProducts { get; private set; }

    private OrderHistoryItem(
        Money subtotal,
        Money shipping,
        Money tax,
        Money summaryTotal,
        DateTime orderDate,
        string storeName,
        Guid orderNumber,
        decimal orderRating,
        string comment,
        ICollection<OrderProduct>? orderProducts,
        DateTime? minimumShippingDate
    )
    {
        Subtotal = subtotal;
        Shipping = shipping;
        Tax = tax;
        SummaryTotal = summaryTotal;
        OrderDate = orderDate;
        StoreName = storeName;
        OrderNumber = orderNumber;
        OrderProducts = orderProducts;
        OrderRating = orderRating;
        Comment = comment;
        MinimumShippingDate = minimumShippingDate;
    }

    public static Result<OrderHistoryItem> Create(
        Money subtotal,
        Money shipping,
        Money tax,
        Money summaryTotal,
        DateTime orderDate,
        string storeName,
        Guid orderNumber,
        decimal orderRating,
        string comment,
        ICollection<OrderProduct>? orderProducts,
        DateTime? minimumShippingDate
    )
    {
        return Result.Success(
            new OrderHistoryItem(
                subtotal,
                shipping,
                tax,
                summaryTotal,
                orderDate,
                storeName,
                orderNumber,
                orderRating,
                comment,
                orderProducts,
                minimumShippingDate
            )
        );
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Subtotal;
        yield return Shipping;
        yield return Tax;
        yield return SummaryTotal;
        yield return OrderDate;
        yield return StoreName;
        yield return OrderNumber;
        yield return OrderProducts;
        yield return OrderRating;
        yield return Comment;
    }
}
