﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class OrderItem : ValueObject<OrderItem>
{
    public StoreProductId ProductId { get; private set; }
    public ProductCatalogId ProductCatalogId { get; set; }
    public string Image { get; set; }
    public string ProductName { get; private set; }
    public int Quantity { get; private set; }
    public Money CostPerItem { get; private set; }
    public Money UnitTax { get; private set; }
    public IDictionary<string, string> ProductVariant { get; private set; }
    public bool IsRefund { get; private set; }
    public DateTime RefundDate { get; private set; }
    public Money RefundAmount { get; private set; }
    public int PreviouslyRefundedQuantity { get; private set; }
    public bool IsPreOrder { get; private set; }
    public DateTime? ReleaseDate { get; private set; }

    private OrderItem(
        StoreProductId productId,
        ProductCatalogId productCatalogId,
        string image,
        string productName,
        IDictionary<string, string> productVariant,
        int quantity,
        Money costPerItem,
        Money unitTax,
        bool isRefund,
        DateTime refundDate,
        Money refundAmount,
        int previouslyRefundedQuantity,
        bool isPreOrder,
        DateTime? releaseDate
    )
    {
        ProductId = productId;
        ProductCatalogId = productCatalogId;
        Image = image;
        ProductName = productName;
        ProductVariant = productVariant;
        Quantity = quantity;
        CostPerItem = costPerItem;
        UnitTax = unitTax;
        IsRefund = isRefund;
        RefundDate = refundDate;
        RefundAmount = refundAmount;
        PreviouslyRefundedQuantity = previouslyRefundedQuantity;
        IsPreOrder = isPreOrder;
        ReleaseDate = releaseDate;
    }

    public static Result<OrderItem> Create(
        StoreProductId productId,
        ProductCatalogId productCatalogId,
        string image,
        string productName,
        IDictionary<string, string> productVariant,
        int quantity,
        Money costPerItem,
        Money unitTax,
        bool isRefund,
        DateTime refundDate,
        Money refundAmount,
        int previouslyRefundedQuantity,
        bool isPreOrder,
        DateTime? releaseDate
    )
    {
        return Result.Success(
            new OrderItem(
                productId,
                productCatalogId,
                image,
                productName,
                productVariant,
                quantity,
                costPerItem,
                unitTax,
                isRefund,
                refundDate,
                refundAmount,
                previouslyRefundedQuantity,
                isPreOrder,
                releaseDate
            )
        );
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return ProductId;
        yield return ProductCatalogId;
        yield return Image;
        yield return ProductName;
        yield return ProductVariant;
        yield return Quantity;
        yield return CostPerItem;
        yield return UnitTax;
        yield return IsRefund;
        yield return RefundDate;
        yield return RefundAmount;
        yield return IsPreOrder;
        yield return ReleaseDate;
    }
}
