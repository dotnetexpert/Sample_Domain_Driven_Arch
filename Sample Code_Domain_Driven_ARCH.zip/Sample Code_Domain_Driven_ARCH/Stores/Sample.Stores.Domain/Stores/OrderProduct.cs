﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class OrderProduct : ValueObject<OrderProduct>
{
    public StoreProductId ProductId { get; private set; }
    public ProductCatalogId ProductCatalogId { get; private set; }
    public string ProductName { get; private set; }
    public CategoryId CategoryId { get; private set; }
    public string CategoryName { get; private set; }
    public Money Price { get; private set; }
    public Money Tax { get; private set; }
    public int Quantity { get; private set; }
    public int ReturnedQuantity { get; private set; }
    public PackageType PackageType { get; private set; }
    public string ImageUrl { get; set; }
    public Dictionary<string, string> VariantType { get; private set; }
    public bool IsPreOrder { get; private set; }
    public DateTime? ReleaseDate { get; private set; }

    public static Result<OrderProduct> Create(
        StoreProductId storeProductId,
        ProductCatalogId productCatalogId,
        string productName,
        CategoryId categoryId,
        string categoryName,
        Money price,
        int quantity,
        Money tax,
        PackageType packageType,
        string imagaUrl,
        Dictionary<string, string> variantType,
        bool isPreOrder,
        DateTime? releaseDate
    )
    {
        if (quantity <= 0)
            return Result.Failure<OrderProduct>(Errors.General.QuantityGreaterThanZero(quantity));

        if (price == null)
            return Result.Failure<OrderProduct>(Errors.General.Null());

        if (price != null && price.Amount <= 0)
            return Result.Failure<OrderProduct>(Errors.General.MoneyAmountMustBeGreaterThanZero(price.Amount));

        if (tax == null)
            return Result.Failure<OrderProduct>(Errors.General.Null());

        if (tax != null && tax.Amount <= 0)
            return Result.Failure<OrderProduct>(Errors.General.MoneyAmountMustBeGreaterThanZero(tax.Amount));

        if (string.IsNullOrWhiteSpace(productName))
            return Result.Failure<OrderProduct>(Errors.General.NullOrWhiteSpaceString(productName));

        return new OrderProduct(
            storeProductId,
            productCatalogId,
            productName,
            categoryId,
            categoryName,
            price,
            quantity,
            tax,
            packageType,
            imagaUrl,
            variantType,
            isPreOrder,
            releaseDate
        );
    }

    public void SetTax(Money tax)
    {
        Tax = tax;
    }

    public Result ReturnProduct(int quantity)
    {
        if (quantity <= 0)
            return Result.Failure(Errors.General.QuantityGreaterThanZero(quantity));

        if (quantity > (Quantity - ReturnedQuantity))
            return Result.Failure(Errors.Order.ReturnQuantityExceedsOrderQuantity(ProductId.Value));

        ReturnedQuantity += quantity;

        return Result.Success();
    }

    private OrderProduct(
        StoreProductId storeProductId,
        ProductCatalogId productCatalogId,
        string productName,
        CategoryId categoryId,
        string categoryName,
        Money price,
        int quantity,
        Money tax,
        PackageType packageType,
        string imageUrl,
        Dictionary<string, string> variantType,
        bool isPreOrder,
        DateTime? releaseDate
    )
    {
        ProductId = storeProductId;
        ProductCatalogId = productCatalogId;
        ProductName = productName;
        CategoryId = categoryId;
        CategoryName = categoryName;
        Price = price;
        Quantity = quantity;
        Tax = tax;
        PackageType = packageType;
        ImageUrl = imageUrl;
        VariantType = variantType;
        IsPreOrder = isPreOrder;
        ReleaseDate = releaseDate;
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return ProductId;
        yield return Price;
        yield return ProductName;
        yield return CategoryId;
        yield return CategoryName;
        yield return Quantity;
        yield return PackageType;
        yield return ImageUrl;
        yield return VariantType;
        yield return IsPreOrder;
        yield return ReleaseDate;
    }

    private OrderProduct() { }
}
