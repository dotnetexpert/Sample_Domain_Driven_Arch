﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class OrderRating : ValueObject<OrderRating>
{
    public Guid OrderId { get; private set; }
    public DateTime DateOfOrder { get; private set; }
    public DateTime DateOfRating { get; private set; }
    public string Message { get; private set; }
    public string Username { get; private set; }
    public int Rating { get; private set; }

    private OrderRating(Guid orderId, DateTime dateOfOrder, DateTime dateOfRating, string message, string username, int rating)
    {
        OrderId = orderId;
        DateOfOrder = dateOfOrder;
        DateOfRating = dateOfRating;
        Message = message;
        Username = username;
        Rating = rating;
    }

    public static Result<OrderRating> Create(
        Guid orderId,
        DateTime dateOfOrder,
        DateTime dateOfRating,
        string message,
        string username,
        int rating
    )
    {
        if (orderId == Guid.Empty)
        {
            return Result.Failure<OrderRating>(Errors.Order.InvalidOrderId(orderId));
        }

        if (dateOfOrder == DateTime.MinValue)
        {
            return Result.Failure<OrderRating>(Errors.Order.InvalidDateOfOrder(dateOfOrder));
        }

        if (dateOfRating == DateTime.MinValue)
        {
            return Result.Failure<OrderRating>(Errors.Order.InvalidDateOfRating(dateOfRating));
        }

        if (string.IsNullOrWhiteSpace(message))
        {
            return Result.Failure<OrderRating>(Errors.Order.InvalidMessage(message));
        }

        if (string.IsNullOrWhiteSpace(username))
        {
            return Result.Failure<OrderRating>(Errors.Order.InvalidUsername(username));
        }

        if (rating < 1 || rating > 5)
        {
            return Result.Failure<OrderRating>(Errors.Order.InvalidRating(rating));
        }

        return Result.Success(new OrderRating(orderId, dateOfOrder, dateOfRating, message, username, rating));
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return OrderId;
        yield return DateOfOrder;
        yield return DateOfRating;
        yield return Message;
        yield return Username;
        yield return Rating;
    }
}
