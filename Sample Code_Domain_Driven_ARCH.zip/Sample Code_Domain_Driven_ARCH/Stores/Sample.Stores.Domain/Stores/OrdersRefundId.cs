﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public record OrdersRefundId(Guid Value) : StronglyTypedId<Guid>(Value);
