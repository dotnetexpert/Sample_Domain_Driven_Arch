﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class PackageSize : Enumeration<PackageSize>
{
    public static readonly PackageSize Small = new PackageSize(1, "Small");
    public static readonly PackageSize Medium = new PackageSize(2, "Medium");
    public static readonly PackageSize Large = new PackageSize(3, "Large");
    public static readonly PackageSize FreeShipping = new PackageSize(4, "FreeShipping");

    private PackageSize(int value, string name)
        : base(value, name) { }
}
