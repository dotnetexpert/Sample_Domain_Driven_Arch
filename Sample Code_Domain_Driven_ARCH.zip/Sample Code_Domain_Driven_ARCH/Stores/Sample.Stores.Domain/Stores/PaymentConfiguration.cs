﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class PaymentConfiguration : ValueObject<PaymentConfiguration>
{
    private PaymentConfiguration(string token, string accountNumberMask, string accountName)
    {
        Token = token;
        AccountNumberMask = accountNumberMask;
        AccountName = accountName;
    }

    public string Token { get; private set; }
    public string AccountNumberMask { get; private set; }
    public string AccountName { get; private set; }
    public bool UsedOnlyForEntityFramework { get; set; }

    internal static Result<PaymentConfiguration> Create(string token, string accountNumberMask, string accountName)
    {
        if (string.IsNullOrWhiteSpace(token))
            Result.Failure<Review>(Errors.General.NullOrWhiteSpaceString(token));

        if (string.IsNullOrWhiteSpace(accountNumberMask))
            Result.Failure<Review>(Errors.General.NullOrWhiteSpaceString(accountNumberMask));

        if (string.IsNullOrWhiteSpace(accountName))
            Result.Failure<Review>(Errors.General.NullOrWhiteSpaceString(accountName));

        return new PaymentConfiguration(token, accountNumberMask, accountName);
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Token;
        yield return AccountNumberMask;
        yield return AccountName;
    }

    private PaymentConfiguration() { }
}
