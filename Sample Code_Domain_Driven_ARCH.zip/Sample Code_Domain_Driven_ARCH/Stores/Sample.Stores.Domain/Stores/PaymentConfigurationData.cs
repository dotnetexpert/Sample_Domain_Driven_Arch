﻿namespace Sample.Stores.Domain.Stores;

public record PaymentConfigurationData(string Token, string AccountNumberMask, string AccountName);
