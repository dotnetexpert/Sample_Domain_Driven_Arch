﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class PaymentType : Enumeration<PaymentType>
{
    public static readonly PaymentType StoreCredit = new PaymentType(1, "Store Credit");
    public static readonly PaymentType BankAccount = new PaymentType(2, "Bank Account");

    private PaymentType(int value, string name)
        : base(value, name) { }
}
