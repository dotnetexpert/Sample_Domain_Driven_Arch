﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public record ProductData(
    StoreId StoreId,
    Guid Id,
    Guid ProductCatalogId,
    int Quantity,
    Guid ProductVariantId,
    Money Price,
    Dictionary<string, string> Variants
);
