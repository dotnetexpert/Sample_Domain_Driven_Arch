﻿namespace Sample.Stores.Domain.Stores;

public record ProductRefund(StoreProductId ProductId, int Quantity);
