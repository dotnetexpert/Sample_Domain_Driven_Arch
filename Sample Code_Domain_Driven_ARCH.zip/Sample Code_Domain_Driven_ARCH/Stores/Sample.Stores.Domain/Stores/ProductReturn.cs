﻿namespace Sample.Stores.Domain.Stores;

public record ProductReturn(StoreProductId ProductId, int Quantity);
