﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class ProductSearchResult : ValueObject<ProductSearchResult>
{
    public string StoreName { get; private set; }
    public StoreProduct StoreProduct { get; private set; }
    public int NumberOfStoresSelling { get; private set; }
    public decimal StoreRating { get; private set; }
    public int StoreSales { get; private set; }

    private ProductSearchResult(
        string storeName,
        StoreProduct storeProduct,
        int numberOfStoresSelling,
        decimal storeRating,
        int storeSales
    )
    {
        StoreName = storeName;
        StoreProduct = storeProduct;
        NumberOfStoresSelling = numberOfStoresSelling;
        StoreRating = storeRating;
        StoreSales = storeSales;
    }

    public static Result<ProductSearchResult> Create(
        string storeName,
        StoreProduct storeProduct,
        int numberOfStoresSelling,
        decimal storeRating,
        int storeSales
    )
    {
        return Result.Success(new ProductSearchResult(storeName, storeProduct, numberOfStoresSelling, storeRating, storeSales));
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return StoreName;
        yield return StoreProduct;
        yield return NumberOfStoresSelling;
        yield return StoreRating;
        yield return StoreSales;
    }
}
