﻿namespace Sample.Stores.Domain.Stores.ProductUpdate
{
    public record UpdateProductData(
        string Name,
        decimal Price,
        int Quantity,
        decimal? BuyPrice,
        Dictionary<string, string> Variants
    );
}
