﻿namespace Sample.Stores.Domain.Stores.ProductUpdate
{
    public record UpdateVariantData(string Name, Dictionary<string, string> Variants);
}
