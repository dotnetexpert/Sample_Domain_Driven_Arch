﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public record RefundData(OrderId OrderId, Money Amount, Money Tax, StoreId StoreId, List<RefundDetails> RefundDetails);
