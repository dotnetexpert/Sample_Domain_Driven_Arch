﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class RefundStatus : Enumeration<RefundStatus>
{
    public static readonly RefundStatus Pending = new RefundStatus(1, "Pending");
    public static readonly RefundStatus Completed = new RefundStatus(2, "Completed");
    public static readonly RefundStatus Failed = new RefundStatus(3, "Failed");

    private RefundStatus(int value, string name)
        : base(value, name) { }
}
