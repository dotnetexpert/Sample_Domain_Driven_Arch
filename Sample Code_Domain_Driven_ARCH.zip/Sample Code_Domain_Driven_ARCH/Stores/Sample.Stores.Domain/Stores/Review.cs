﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class Review : Entity<ReviewId>
{
    public StoreId StoreId { get; private set; }
    public OrderId OrderId { get; private set; }
    public int Rating { get; private set; }
    public string Comment { get; private set; }
    public ReviewCustomer Customer { get; set; }
    public DateTime Date { get; private set; }
    public Order Order { get; private set; }

    public void UpdateReview(int rating, string comment, DateTime date)
    {
        Rating = rating;
        Comment = comment;
        Date = date;
    }

    public static Result<Review> Create(
        StoreId storeId,
        OrderId orderId,
        int rating,
        string comment,
        ReviewCustomer customer,
        DateTime date
    )
    {
        if (rating < 1 || rating > 5)
            return Result.Failure<Review>(Errors.Review.InvalidRating(rating));

        if (string.IsNullOrWhiteSpace(comment))
            return Result.Failure<Review>(Errors.General.NullOrWhiteSpaceString(comment));

        if (customer == null || string.IsNullOrWhiteSpace(customer.Name))
            return Result.Failure<Review>(Errors.General.NullOrWhiteSpaceString(customer.Name));

        if (date == DateTime.MinValue)
            return Result.Failure<Review>(Errors.General.DateTimeMin());

        return new Review(storeId, orderId, rating, comment, customer, date);
    }

    private Review(StoreId storeId, OrderId orderId, int rating, string comment, ReviewCustomer customer, DateTime date)
    {
        Id = new ReviewId(Guid.NewGuid());
        StoreId = storeId;
        OrderId = orderId;
        Rating = rating;
        Comment = comment;
        Customer = customer;
        Date = date;
    }

    private Review() { }
}
