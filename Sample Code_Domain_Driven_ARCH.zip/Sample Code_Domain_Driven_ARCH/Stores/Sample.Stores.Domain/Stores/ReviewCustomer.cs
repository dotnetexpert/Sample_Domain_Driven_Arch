﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class ReviewCustomer : ValueObject<ReviewCustomer>
{
    public string Name { get; set; }
    public CustomerId CustomerId { get; set; }

    public static Result<ReviewCustomer> Create(string name, CustomerId customerId)
    {
        if (string.IsNullOrWhiteSpace(name))
            Result.Failure<ReviewCustomer>(Errors.General.NullOrWhiteSpaceString(name));

        return new ReviewCustomer(name, customerId);
    }

    private ReviewCustomer(string name, CustomerId customerId)
    {
        Name = name;
        CustomerId = customerId;
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return CustomerId;
        yield return Name;
    }

    private ReviewCustomer() { }
}
