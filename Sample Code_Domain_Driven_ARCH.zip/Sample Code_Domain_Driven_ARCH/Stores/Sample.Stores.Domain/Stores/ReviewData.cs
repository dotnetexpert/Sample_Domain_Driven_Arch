﻿namespace Sample.Stores.Domain.Stores;

public record ReviewData(Guid PackageId, int Rating, string Comment, ReviewCustomer Customer, DateTime Date);
