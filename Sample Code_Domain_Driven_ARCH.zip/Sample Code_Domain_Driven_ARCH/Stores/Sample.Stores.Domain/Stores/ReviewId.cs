﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public record ReviewId(Guid Value) : StronglyTypedId<Guid>(Value);
