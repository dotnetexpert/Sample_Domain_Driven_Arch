﻿namespace Sample.Stores.Domain.Stores;

public record ReviewUpdatedData(int Rating, string Comment, DateTime Date);
