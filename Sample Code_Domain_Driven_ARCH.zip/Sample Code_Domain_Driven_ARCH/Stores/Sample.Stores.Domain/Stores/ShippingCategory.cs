﻿namespace Sample.Stores.Domain.Stores;

public static class ShippingCategory
{
    public static string DetermineCategory(decimal totalWeight)
    {
        if (totalWeight < 3.5m)
        {
            return nameof(PackageSize.Small);
        }
        else if (totalWeight >= 3.5m && totalWeight < 13m)
        {
            return nameof(PackageSize.Medium);
        }
        else
        {
            return nameof(PackageSize.Large);
        }
    }
}
