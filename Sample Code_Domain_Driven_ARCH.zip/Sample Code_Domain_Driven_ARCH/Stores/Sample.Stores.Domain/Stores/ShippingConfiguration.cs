﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class ShippingConfiguration : ValueObject<ShippingConfiguration>
{
    private ShippingConfiguration(Money letterShippingCost, Money boxShippingCost, Money packageShippingCost)
    {
        LetterShippingCost = letterShippingCost;
        BoxShippingCost = boxShippingCost;
        LargePackageShippingCost = packageShippingCost;
    }

    public Money LetterShippingCost { get; private set; }
    public Money BoxShippingCost { get; private set; }
    public Money LargePackageShippingCost { get; private set; }
    public bool UsedOnlyForEntityFramework { get; set; }

    public static Result<ShippingConfiguration> Create(
        Money letterShippingCost,
        Money boxShippingCost,
        Money largePackageShippingCost,
        GlobalShippingConfiguration globalShippingConfiguration
    )
    {
        if (
            letterShippingCost == null
            || letterShippingCost.Amount < globalShippingConfiguration.MinimumLetterShippingCost
            || letterShippingCost.Amount >= globalShippingConfiguration.MaximumLetterShippingCost
        )
            return Result.Failure<ShippingConfiguration>(
                Errors.ShippingConfiguration.InvalidShippingCost(
                    letterShippingCost.Amount,
                    globalShippingConfiguration.MinimumLetterShippingCost,
                    globalShippingConfiguration.MaximumLetterShippingCost
                )
            );

        if (
            boxShippingCost == null
            || boxShippingCost.Amount < globalShippingConfiguration.MinimumBoxShippingCost
            || boxShippingCost.Amount >= globalShippingConfiguration.MaximumBoxShippingCost
        )
            return Result.Failure<ShippingConfiguration>(
                Errors.ShippingConfiguration.InvalidShippingCost(
                    boxShippingCost.Amount,
                    globalShippingConfiguration.MinimumBoxShippingCost,
                    globalShippingConfiguration.MaximumBoxShippingCost
                )
            );

        if (
            largePackageShippingCost == null
            || largePackageShippingCost.Amount < globalShippingConfiguration.MinimumLargePackageShippingCost
            || largePackageShippingCost.Amount >= globalShippingConfiguration.MaximumLargePackageShippingCost
        )
            return Result.Failure<ShippingConfiguration>(
                Errors.ShippingConfiguration.InvalidShippingCost(
                    largePackageShippingCost.Amount,
                    globalShippingConfiguration.MinimumLargePackageShippingCost,
                    globalShippingConfiguration.MaximumLargePackageShippingCost
                )
            );

        return new ShippingConfiguration(letterShippingCost, boxShippingCost, largePackageShippingCost);
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return LetterShippingCost;
        yield return BoxShippingCost;
        yield return LargePackageShippingCost;
    }

    private ShippingConfiguration() { }
}
