﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public record ShippingConfigurationData(Money LetterShippingCost, Money BoxShippingCost, Money LargePackageShippingCost);
