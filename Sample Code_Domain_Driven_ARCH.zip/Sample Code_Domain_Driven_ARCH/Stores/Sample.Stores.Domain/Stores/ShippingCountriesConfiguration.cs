﻿namespace Sample.Stores.Domain.Stores;

public class ShippingCountriesConfiguration
{
    public List<string> Countries { get; set; }
}
