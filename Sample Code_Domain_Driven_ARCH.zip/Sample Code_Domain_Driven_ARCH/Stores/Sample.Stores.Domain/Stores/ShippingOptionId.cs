﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public record ShippingOptionId(Guid Value) : StronglyTypedId<Guid>(Value);
