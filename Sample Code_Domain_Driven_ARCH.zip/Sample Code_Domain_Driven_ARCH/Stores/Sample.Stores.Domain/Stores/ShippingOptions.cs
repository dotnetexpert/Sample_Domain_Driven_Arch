﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class ShippingOptions : Entity<ShippingOptionId>
{
    public StoreId StoreId { get; private set; }
    public Money Small { get; private set; }
    public Money Medium { get; private set; }
    public Money Large { get; private set; }
    public int? SmallShippingOptionId { get; private set; }
    public int? MediumShippingOptionId { get; private set; }
    public int? LargeShippingOptionId { get; private set; }
    public int? TrackedShippingOptionId { get; private set; }
    public Money? FreeShippingThreshold { get; private set; }
    public Money TrackingRequiredThreshold { get; private set; }
    public string? CountryCode { get; private set; }

    public void SetShippingOptionIds(
        int? smallShippingOptionId,
        int? mediumShippingOptionId,
        int? largeShippingOptionId,
        int? trackedShippingId
    )
    {
        SmallShippingOptionId = smallShippingOptionId;
        MediumShippingOptionId = mediumShippingOptionId;
        LargeShippingOptionId = largeShippingOptionId;
        TrackedShippingOptionId = trackedShippingId;
    }

    public static Result<ShippingOptions> Create(
        StoreId storeId,
        Money small,
        Money medium,
        Money large,
        Money freeShippingThreshold,
        Money trackingRequiredThreshold,
        string countryCode
    )
    {
        if (freeShippingThreshold.Amount < 0m)
            Result.Failure<ShippingOptions>(Errors.General.MoneyAmountMustBeGreaterThanZero(freeShippingThreshold.Amount));

        return new ShippingOptions(storeId, small, medium, large, freeShippingThreshold, trackingRequiredThreshold, countryCode);
    }

    public void UpdateShippingOptions(
        Money small,
        Money medium,
        Money large,
        Money freeShippingThreshold,
        Money trackingRequiredThreshold
    )
    {
        Small = small;
        Medium = medium;
        Large = large;
        FreeShippingThreshold = freeShippingThreshold;
        TrackingRequiredThreshold = trackingRequiredThreshold;
    }

    public Dictionary<Money, int?> CalculateShippingCost(
        decimal totalWeight,
        ShippingOptions shippingOptions,
        decimal totalPackageCost,
        decimal freeShippingThreshold
    )
    {
        if (totalWeight < ShippingSize.Small)
        {
            if (freeShippingThreshold <= totalPackageCost)
            {
                return new Dictionary<Money, int?>
                {
                    { Money.Of(0, shippingOptions.Small.Currency), shippingOptions.SmallShippingOptionId },
                };
            }
            else
            {
                return new Dictionary<Money, int?>
                {
                    {
                        Money.Of(shippingOptions.Small.Amount, shippingOptions.Small.Currency),
                        shippingOptions.SmallShippingOptionId
                    },
                };
            }
        }
        else if (totalWeight < ShippingSize.Medium)
        {
            if (freeShippingThreshold <= totalPackageCost)
            {
                return new Dictionary<Money, int?>
                {
                    { Money.Of(0, shippingOptions.Medium.Currency), shippingOptions.MediumShippingOptionId },
                };
            }
            else
            {
                return new Dictionary<Money, int?>
                {
                    {
                        Money.Of(shippingOptions.Medium.Amount, shippingOptions.Medium.Currency),
                        shippingOptions.MediumShippingOptionId
                    },
                };
            }
        }
        else
        {
            if (freeShippingThreshold <= totalPackageCost)
            {
                return new Dictionary<Money, int?>
                {
                    { Money.Of(0, shippingOptions.Large.Currency), shippingOptions.LargeShippingOptionId },
                };
            }
            else
            {
                return new Dictionary<Money, int?>
                {
                    {
                        Money.Of(shippingOptions.Large.Amount, shippingOptions.Large.Currency),
                        shippingOptions.LargeShippingOptionId
                    },
                };
            }
        }
    }

    private ShippingOptions(
        StoreId storeId,
        Money small,
        Money medium,
        Money large,
        Money freeShippingThreshold,
        Money trackingRequiredThreshold,
        string countryCode
    )
    {
        Id = new ShippingOptionId(Guid.NewGuid());
        StoreId = storeId;
        Small = small;
        Medium = medium;
        Large = large;
        FreeShippingThreshold = freeShippingThreshold;
        TrackingRequiredThreshold = trackingRequiredThreshold;
        CountryCode = countryCode;
    }

    private ShippingOptions() { }
}
