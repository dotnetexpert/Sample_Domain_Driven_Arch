﻿namespace Sample.Stores.Domain.Stores;

public static class ShippingSize
{
    public const decimal Small = 0.99m;
    public const decimal Medium = 4.99m;
    public const decimal Large = 5.00m;
}
