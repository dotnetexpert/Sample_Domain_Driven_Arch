﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class StaffMember : Entity<StaffMemberId>
{
    public UserId UserId { get; set; }
    public StoreId StoreId { get; set; }
    public string FirstName { get; private set; }
    public string LastName { get; private set; }
    public string EmailAddress { get; private set; }

    private StaffMember(UserId userId, StoreId storeId, string firstName, string lastName, string emailAddress)
    {
        Id = new StaffMemberId(Guid.NewGuid());
        UserId = userId;
        StoreId = storeId;
        FirstName = firstName;
        LastName = lastName;

        // enforce uniqueness in Store.cs
        EmailAddress = emailAddress;
    }

    public void SetName(string firstName, string lastName)
    {
        FirstName = firstName;
        LastName = lastName;
    }

    public void SetEmailAddress(string emailAddress)
    {
        EmailAddress = emailAddress;
    }

    public static Result<StaffMember> Create(
        UserId userId,
        StoreId storeId,
        string firstName,
        string lastName,
        string emailAddress
    )
    {
        if (string.IsNullOrWhiteSpace(firstName))
            Result.Failure<StaffMember>(Errors.General.NullOrWhiteSpaceString(firstName));

        if (string.IsNullOrWhiteSpace(lastName))
            Result.Failure<StaffMember>(Errors.General.NullOrWhiteSpaceString(lastName));

        if (string.IsNullOrWhiteSpace(emailAddress))
            Result.Failure<StaffMember>(Errors.General.NullOrWhiteSpaceString(emailAddress));

        return new StaffMember(userId, storeId, firstName, lastName, emailAddress);
    }

    private StaffMember() { }
}
