﻿namespace Sample.Stores.Domain.Stores;

public record StaffMemberData(UserId UserId, string FirstName, string LastName, string EmailAddress);
