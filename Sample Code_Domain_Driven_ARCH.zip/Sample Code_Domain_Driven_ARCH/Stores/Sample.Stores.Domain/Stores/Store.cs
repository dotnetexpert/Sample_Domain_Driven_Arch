﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class Store : AggregateRoot<StoreId>
{
    public string Name { get; private set; }
    public string DomainName { get; private set; }
    public bool IsActive { get; private set; }
    public Address Address { get; private set; }
    public ContactInformation ContactInformation { get; private set; }
    public bool IsOnboarded { get; private set; }
    public bool IsPaymentsReceivable { get; private set; }
    public Guid TrackingId { get; private set; }
    public decimal Rating
    {
        get
        {
            return _orders.Any(r => r.Review != null)
                ? (decimal)_orders.Select(o => o.Review).Where(r => r != null).Average(r => r.Rating)
                : 0;
        }
    }
    public ShippingConfiguration? ShippingConfiguration { get; private set; }
    public PaymentConfiguration? PaymentConfiguration { get; private set; }
    public StoreRegistration Registration { get; private set; }

    private readonly List<StoreProduct> _products = new List<StoreProduct>();
    public IReadOnlyCollection<StoreProduct> Products => _products.AsReadOnly();

    private readonly List<Order> _orders = new List<Order>();
    public IReadOnlyCollection<Order> Orders => _orders.AsReadOnly();

    private readonly List<StaffMember> _staff = new List<StaffMember>();
    public IReadOnlyCollection<StaffMember> Staff => _staff.AsReadOnly();

    private readonly List<ShippingOptions> _shippingOptions = new List<ShippingOptions>();
    public IReadOnlyCollection<ShippingOptions> ShippingOptions => _shippingOptions.AsReadOnly();

    public static Result<Store> CreateFromData(StoreData storeData)
    {
        if (string.IsNullOrWhiteSpace(storeData.Name))
            return Result.Failure<Store>(Errors.General.NullOrWhiteSpaceString(storeData.Name));

        if (storeData.Address == null)
            return Result.Failure<Store>(Errors.General.Null());

        if (storeData.ContactInformation == null)
            return Result.Failure<Store>(Errors.General.Null());

        return new Store(
            storeData.Name,
            storeData.DomainName,
            storeData.Email,
            storeData.ApiKey,
            storeData.Address,
            storeData.ContactInformation,
            storeData.ShippingConfiguration,
            storeData.PaymentConfiguration
        );
    }

    public static Result<Store> Create(
        string name,
        string domainName,
        string email,
        string apiKey,
        DefaultShippingOptionsConfiguration defaultShippingOptions,
        ShippingCountriesConfiguration shippingCountries
    )
    {
        if (string.IsNullOrWhiteSpace(name))
            return Result.Failure<Store>(Errors.General.NullOrWhiteSpaceString(name));

        if (string.IsNullOrWhiteSpace(domainName))
            return Result.Failure<Store>(Errors.General.NullOrWhiteSpaceString(domainName));

        if (string.IsNullOrWhiteSpace(email))
            return Result.Failure<Store>(Errors.General.NullOrWhiteSpaceString(email));

        if (string.IsNullOrWhiteSpace(apiKey))
            return Result.Failure<Store>(Errors.General.NullOrWhiteSpaceString(apiKey));

        var registrationResult = StoreRegistration.Create(email, apiKey);

        if (registrationResult.IsFailure)
            return Result.Failure<Store>(registrationResult.Error);

        var store = new Store(name, domainName, email, apiKey);

        foreach (var countryCode in shippingCountries.Countries.ToList())
        {
            CountryShippingOptions countryShippingOptions = null;

            if (countryCode == "US")
            {
                countryShippingOptions = defaultShippingOptions.US;
            }
            else if (countryCode == "CA")
            {
                countryShippingOptions = defaultShippingOptions.CA;
            }

            if (countryShippingOptions != null)
            {
                var shippingOptions = new List<ShippingOptions>
                {
                    Stores
                        .ShippingOptions.Create(
                            store.Id,
                            Money.Of(countryShippingOptions.SmallPackageShippingCost, Currency.USDollar.Code),
                            Money.Of(countryShippingOptions.MediumPackageShippingCost, Currency.USDollar.Code),
                            Money.Of(countryShippingOptions.LargePackageShippingCost, Currency.USDollar.Code),
                            Money.Of(countryShippingOptions.FreeShippingThreshold, Currency.USDollar.Code),
                            Money.Of(countryShippingOptions.TrackingRequiredThreshold, Currency.USDollar.Code),
                            countryCode
                        )
                        .Value,
                };

                store._shippingOptions.AddRange(shippingOptions);
            }
        }

        return Result.Success(store);
    }

    public void UpdateOnboardedStatus(bool status)
    {
        IsOnboarded = status;
    }

    public void UpdateIsPaymentsReceivable(bool status)
    {
        IsPaymentsReceivable = status;
    }

    public Result DisableStore(Store existingStore)
    {
        existingStore.SetInactive();

        return Result.Success();
    }

    public void SetInactive()
    {
        IsActive = false;
        Registration.SetRegistrationStatus(StoreRegistrationStatus.Desync);
    }

    public Result<StoreRegistration> Reregister(string? emailAddress = null)
    {
        if (emailAddress != null)
        {
            Registration.SetEmailAddress(emailAddress);
        }

        IsActive = true;

        return Registration.SetRegistrationStatus(StoreRegistrationStatus.HandshakeInitialized);
    }

    public Result AddStaffMember(StaffMemberData staffMemberData)
    {
        var existingStaffMember = _staff.FirstOrDefault(s =>
            s.UserId == staffMemberData.UserId
            && s.FirstName == staffMemberData.FirstName
            && s.LastName == staffMemberData.LastName
            && s.EmailAddress == staffMemberData.EmailAddress
        );

        if (existingStaffMember != null)
        {
            return Result.Failure(Errors.Store.StaffMemberExists());
        }

        if (Staff.Any(s => s.EmailAddress == staffMemberData.EmailAddress))
        {
            return Result.Failure(Errors.Store.UniqueStaffMemberEmailAddress(staffMemberData.EmailAddress));
        }

        var result = StaffMember.Create(
            staffMemberData.UserId,
            Id,
            staffMemberData.FirstName,
            staffMemberData.LastName,
            staffMemberData.EmailAddress
        );

        if (result.IsFailure)
            return result;

        _staff.Add(result.Value);

        return result;
    }

    public Result RemoveStaffMember(StaffMemberId id)
    {
        var existingStaffMember = _staff.FirstOrDefault(s => s.Id == id);

        if (existingStaffMember == null)
        {
            return Result.Failure(Errors.Store.StaffMemberMissing(id.Value));
        }

        _staff.Remove(existingStaffMember);

        return Result.Success();
    }

    public Result UpdateStaffMember(StaffMemberId id, StaffMemberData staffMemberData)
    {
        var existingStaffMember = _staff.FirstOrDefault(r => r.Id == id);

        if (existingStaffMember == null)
        {
            return Result.Failure(Errors.General.NotFound(id.Value));
        }

        if (Staff.Any(s => s.EmailAddress == staffMemberData.EmailAddress))
        {
            return Result.Failure(Errors.Store.UniqueStaffMemberEmailAddress(staffMemberData.EmailAddress));
        }

        existingStaffMember.SetName(staffMemberData.FirstName, staffMemberData.LastName);
        existingStaffMember.SetEmailAddress(staffMemberData.EmailAddress);

        return Result.Success();
    }

    public Result<Order> CreateOrder(OrderData orderData)
    {
        var result = Order.Create(new(Guid.NewGuid()), new(Guid.NewGuid()), orderData);

        if (result.IsFailure)
        {
            return result;
        }

        foreach (var orderProduct in orderData.OrderProductData)
        {
            var productToUpdate = _products.FirstOrDefault(p => p.Id == orderProduct.StoreProductId);

            if (productToUpdate is null)
                return Result.Failure<Order>(Errors.Store.ProductNotFound(orderProduct.StoreProductId.Value));
        }

        _orders.Add(result.Value);

        return Result.Success(result.Value);
    }

    public void AddProductsToInventory(IEnumerable<StoreProduct> products)
    {
        _products.AddRange(products);
    }

    public void AddProductToInventory(StoreProduct product)
    {
        _products.Add(product);
    }

    public void UpdateProductInventory(UpdateProductInventoryData productData)
    {
        var existingProduct = _products.FirstOrDefault(p => p.Id == productData.ProductId);

        existingProduct.SetPrice(productData.UnitPrice);
        existingProduct.SetQuantity(productData.Quantity);
    }

    public Result<ShippingConfiguration> SetShippingConfiguration(
        ShippingConfigurationData shippingConfiguration,
        GlobalShippingConfiguration globalShippingConfiguration
    )
    {
        var result = ShippingConfiguration.Create(
            shippingConfiguration.LetterShippingCost,
            shippingConfiguration.BoxShippingCost,
            shippingConfiguration.LargePackageShippingCost,
            globalShippingConfiguration
        );

        if (result.IsFailure)
            return result;

        ShippingConfiguration = result.Value;

        return result;
    }

    public Result SetPaymentConfiguration(PaymentConfigurationData paymentConfiguration)
    {
        var result = PaymentConfiguration.Create(
            paymentConfiguration.Token,
            paymentConfiguration.AccountNumberMask,
            paymentConfiguration.AccountName
        );

        if (result.IsFailure)
            return result;

        PaymentConfiguration = result.Value;

        return result;
    }

    public Result<Refund> AddRefund(RefundData refund)
    {
        var order = _orders.FirstOrDefault(o => o.Id == refund.OrderId);

        if (order == null)
        {
            return Result.Failure<Refund>(Errors.General.NotFound(refund.OrderId.Value));
        }

        return order.AddRefund(refund);
    }

    public Result ReturnProducts(OrderId orderId, List<ProductReturn> returns)
    {
        var order = _orders.FirstOrDefault(o => o.Id == orderId);

        if (order == null)
        {
            return Result.Failure(Errors.General.NotFound(orderId.Value));
        }

        foreach (var product in returns)
        {
            var productToReturn = order.OrderProducts.FirstOrDefault(p => p.ProductId == product.ProductId);

            if (productToReturn == null)
                return Result.Failure(Errors.Store.ProductNotFound(product.ProductId.Value));
        }

        return Result.Success();
    }

    public Result CompleteRefund(OrderId id, RefundId refundId, OrdersRefundId ordersRefundId)
    {
        var order = _orders.FirstOrDefault(o => o.Id == id);

        if (order == null)
        {
            return Result.Failure(Errors.General.NotFound(id.Value));
        }

        return order.CompleteRefund(refundId, ordersRefundId);
    }

    public Result ProcessFailedRefund(OrderId id, RefundId refundId, string errorDetails)
    {
        var order = _orders.FirstOrDefault(o => o.Id == id);

        if (order == null)
        {
            return Result.Failure(Errors.General.NotFound(id.Value));
        }

        return order.ProcessFailedRefund(refundId, errorDetails);
    }

    public IEnumerable<StoreInboxItem> GetStoreInboxDetails(string storeName)
    {
        var inboxData = _orders
            .Select(o =>
            {
                var lastMessage = o.Messages.LastOrDefault();

                if (lastMessage == null)
                {
                    return new List<StoreInboxItem>();
                }
                else
                {
                    var inboxItemResult = StoreInboxItem.Create(message: lastMessage, storeName: storeName, orderId: o.Id.Value);
                    return inboxItemResult.IsSuccess
                        ? new List<StoreInboxItem> { inboxItemResult.Value }
                        : new List<StoreInboxItem>();
                }
            })
            .Where(item => item.Any());

        return inboxData.SelectMany(x => x).OrderByDescending(x => x.Message.Date);
    }

    public IEnumerable<OrderHistoryItem> GetOrderDetails(OrderId orderId, string storeName)
    {
        var orderSummaryData = _orders
            .Where(o => o.Id == orderId)
            .Select(o =>
            {
                var summaryResult = OrderHistoryItem.Create(
                    subtotal: o.SubTotal,
                    shipping: o.ShippingCost,
                    tax: o.Tax,
                    summaryTotal: o.Total,
                    orderDate: o.Date,
                    storeName: storeName,
                    orderNumber: o.Id.Value,
                    orderProducts: o.OrderProducts.ToList(),
                    orderRating: o.Review?.Rating ?? 0.0m,
                    comment: o.Review?.Comment,
                    minimumShippingDate: o.MinimumShippingDate
                );

                return summaryResult.IsSuccess ? summaryResult.Value : throw new Exception("Failed to fetch the order details");
            });

        return orderSummaryData;
    }

    public StoreProduct ProductDetails(StoreProductId productId)
    {
        return _products.FirstOrDefault(p => p.Id == productId);
    }

    public Result<IEnumerable<MessageThread>> GetOrderMessageThread(string storeName)
    {
        var orderMessageThreadData = _orders
            .OrderByDescending(o => o.Date)
            .Select(o =>
            {
                var orderMessages = o.Messages.OrderByDescending(message => message.Date).ToList();
                var messageThreadItemData = MessageThread.Create(
                    messages: orderMessages,
                    storeName: storeName,
                    orderId: o.Id.Value
                );

                return messageThreadItemData.IsSuccess ? messageThreadItemData.Value : null;
            })
            .Where(messageThreadItem => messageThreadItem != null);

        return Result.Success(orderMessageThreadData);
    }

    public void AddShippingOptions(ShippingOptions options)
    {
        _shippingOptions.Add(options);
    }

    private Store(
        string name,
        string domainName,
        string email,
        string apiKey,
        Address? address = null,
        ContactInformation contactInformation = null,
        ShippingConfiguration? shippingConfiguration = null,
        PaymentConfiguration? paymentConfiguration = null,
        bool isOnboarded = false
    )
    {
        Id = new StoreId(Guid.NewGuid());
        Name = name;
        DomainName = domainName;
        IsActive = true;
        Address = address;
        ContactInformation = contactInformation;
        ShippingConfiguration = shippingConfiguration;
        PaymentConfiguration = paymentConfiguration;
        Registration = StoreRegistration.Create(email, apiKey).Value;
        IsOnboarded = isOnboarded;
        TrackingId = Guid.NewGuid();
    }

    private Store() { }
}
