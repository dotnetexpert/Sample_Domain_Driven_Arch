﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public record StoreData(
    string Name,
    string DomainName,
    string Email,
    string ApiKey,
    Address Address,
    ContactInformation ContactInformation,
    ShippingConfiguration? ShippingConfiguration = null,
    PaymentConfiguration? PaymentConfiguration = null
);
