﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class StoreInboxItem : ValueObject<StoreInboxItem>
{
    public Message Message { get; private set; }
    public string StoreName { get; private set; }
    public Guid OrderId { get; private set; }

    public static Result<StoreInboxItem> Create(Message message, string storeName, Guid orderId)
    {
        return Result.Success(new StoreInboxItem(message, storeName, orderId));
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Message;
        yield return StoreName;
        yield return OrderId;
    }

    private StoreInboxItem(Message message, string storeName, Guid orderId)
    {
        Message = message;
        StoreName = storeName;
        OrderId = orderId;
    }
}
