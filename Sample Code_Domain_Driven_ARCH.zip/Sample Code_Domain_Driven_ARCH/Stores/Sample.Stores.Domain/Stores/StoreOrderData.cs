﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public record StoreOrderData(
    string StoreName,
    string StoreEmail,
    OrderId OrderId,
    ExternalOrderId ExternalOrderId,
    ShippingOptionId ShippingOptionId,
    int? ExternalShippingOptionId,
    Money ShippingCost,
    Money ShippingTax,
    DateTime? MinimumShippingDate
);
