﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class StoreOrderItem : ValueObject<StoreOrderItem>
{
    public int TotalSearchedOrders { get; private set; }
    public IEnumerable<StoreOrderSummary> StoreOrderSummary { get; private set; }

    public static Result<StoreOrderItem> Create(int totalSearchedOrders, IEnumerable<StoreOrderSummary> storeOrderSummary)
    {
        if (storeOrderSummary == null)
        {
            return Result.Success(new StoreOrderItem(totalSearchedOrders, new List<StoreOrderSummary>()));
        }

        if (!storeOrderSummary.Any())
        {
            return Result.Success(new StoreOrderItem(totalSearchedOrders, new List<StoreOrderSummary>()));
        }

        return Result.Success(new StoreOrderItem(totalSearchedOrders, storeOrderSummary));
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return TotalSearchedOrders;
        yield return StoreOrderSummary;
    }

    private StoreOrderItem(int totalSearchedOrders, IEnumerable<StoreOrderSummary> storeOrderSummary)
    {
        TotalSearchedOrders = totalSearchedOrders;
        StoreOrderSummary = storeOrderSummary;
    }
}
