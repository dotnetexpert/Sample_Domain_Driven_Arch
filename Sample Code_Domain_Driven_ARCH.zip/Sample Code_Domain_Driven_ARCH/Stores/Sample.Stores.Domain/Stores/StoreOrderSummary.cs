﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class StoreOrderSummary : ValueObject<StoreOrderSummary>
{
    public Guid StoreId { get; private set; }
    public string StoreName { get; private set; }
    public DateTime? OrderDate { get; private set; }
    public DateTime? ShipmentDate { get; private set; }
    public Guid OrderId { get; private set; }
    public Guid PackageId { get; private set; }
    public Money ShippingCost { get; private set; }
    public int? ExternalShippingOptionId { get; private set; }
    public Money Subtotal { get; private set; }
    public Money Tax { get; private set; }
    public Money Total { get; private set; }
    public IEnumerable<OrderItem> OrderItems { get; private set; }
    public int Rating { get; private set; }
    public string Comment { get; private set; }
    public Address BillingAddress { get; private set; }
    public Address ShippingAddress { get; private set; }
    public string CustomerName { get; private set; }
    public string PhoneNumber { get; private set; }
    public string TrackingNumber { get; private set; }
    public DateTime? MinimumShippingDate { get; private set; }

    private StoreOrderSummary(
        Money subtotal,
        Money shipping,
        int? externalShippingOptionId,
        Money tax,
        Money total,
        DateTime? orderDate,
        DateTime? shipmentDate,
        Guid orderId,
        Guid packageId,
        Guid storeId,
        string storeName,
        IEnumerable<OrderItem> orderItems,
        int orderRating,
        string comment,
        Address billingAddress,
        Address shippingAddress,
        string customerName,
        string phoneNumber,
        string trackingNumber,
        DateTime? minimumShippingDate
    )
    {
        Subtotal = subtotal;
        ShippingCost = shipping;
        ExternalShippingOptionId = externalShippingOptionId;
        Tax = tax;
        Total = total;
        OrderDate = orderDate;
        ShipmentDate = shipmentDate;
        OrderId = orderId;
        PackageId = packageId;
        StoreId = storeId;
        StoreName = storeName;
        OrderItems = orderItems;
        Rating = orderRating;
        Comment = comment;
        BillingAddress = billingAddress;
        ShippingAddress = shippingAddress;
        CustomerName = customerName;
        PhoneNumber = phoneNumber;
        TrackingNumber = trackingNumber;
        MinimumShippingDate = minimumShippingDate;
    }

    public static Result<StoreOrderSummary> Create(
        Money subtotal,
        Money shipping,
        int? externalShippingOptionId,
        Money tax,
        Money total,
        DateTime? orderDate,
        DateTime? shipmentDate,
        Guid orderId,
        Guid packageId,
        Guid storeId,
        string storeName,
        Address billingAddress,
        Address shippingAddress,
        string customerName,
        string phoneNumber,
        string trackingNumber,
        IEnumerable<OrderItem> orderItems,
        int rating,
        string comment,
        DateTime? minimumShippingDate
    )
    {
        if (subtotal == null)
            return Result.Failure<StoreOrderSummary>(Errors.SummaryItem.NullTax());

        if (subtotal != null && subtotal.Amount <= 0)
            return Result.Failure<StoreOrderSummary>(Errors.General.MoneyAmountMustBeGreaterThanZero(subtotal.Amount));

        if (shipping == null)
            return Result.Failure<StoreOrderSummary>(Errors.SummaryItem.NullTax());

        if (shipping != null && shipping.Amount < 0)
            return Result.Failure<StoreOrderSummary>(Errors.General.MoneyAmountMustBeGreaterThanZero(shipping.Amount));

        if (tax == null)
            return Result.Failure<StoreOrderSummary>(Errors.SummaryItem.NullTax());

        if (tax != null && tax.Amount <= 0)
            return Result.Failure<StoreOrderSummary>(Errors.General.MoneyAmountMustBeGreaterThanZero(tax.Amount));

        if (total == null)
            return Result.Failure<StoreOrderSummary>(Errors.SummaryItem.NullTax());

        if (total != null && total.Amount <= 0)
            return Result.Failure<StoreOrderSummary>(Errors.General.MoneyAmountMustBeGreaterThanZero(total.Amount));

        if (orderDate == default(DateTime))
            return Result.Failure<StoreOrderSummary>(Errors.StoreOrderSummary.NullDate());

        if (shipmentDate == default(DateTime))
            return Result.Failure<StoreOrderSummary>(Errors.StoreOrderSummary.NullDate());

        if (orderId == Guid.Empty)
            return Result.Failure<StoreOrderSummary>(Errors.General.EmptyGuid());

        if (storeId == Guid.Empty)
            return Result.Failure<StoreOrderSummary>(Errors.General.EmptyGuid());

        return Result.Success(
            new StoreOrderSummary(
                subtotal,
                shipping,
                externalShippingOptionId,
                tax,
                total,
                orderDate,
                shipmentDate,
                orderId,
                packageId,
                storeId,
                storeName,
                orderItems,
                rating,
                comment,
                billingAddress,
                shippingAddress,
                customerName,
                phoneNumber,
                trackingNumber,
                minimumShippingDate
            )
        );
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Subtotal;
        yield return ShippingCost;
        yield return ExternalShippingOptionId;
        yield return Tax;
        yield return Total;
        yield return OrderDate;
        yield return ShipmentDate;
        yield return OrderId;
        yield return PackageId;
        yield return StoreId;
        yield return StoreName;
        yield return OrderItems;
        yield return Rating;
        yield return Comment;
        yield return BillingAddress;
        yield return ShippingAddress;
        yield return CustomerName;
        yield return PhoneNumber;
        yield return TrackingNumber;
    }
}
