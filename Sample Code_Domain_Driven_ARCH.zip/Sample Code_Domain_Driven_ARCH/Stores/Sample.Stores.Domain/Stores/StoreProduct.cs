﻿using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Stores.ProductUpdate;

namespace Sample.Stores.Domain.Stores
{
    public class StoreProduct : Entity<StoreProductId>
    {
        public StoreId StoreId { get; set; }
        public ProductCatalogId ProductCatalogId { get; private set; }
        public ExternalProductId ExternalProductId { get; private set; }
        public ExternalVariantId ExternalVariantId { get; private set; }
        public ProductVariantId ProductVariantId { get; private set; }
        public string Name { get; private set; }
        public Money Price { get; private set; }
        public int Quantity { get; private set; }
        public Money? BuyPrice { get; private set; }
        public int BuyQuantity { get; private set; }
        public DateTime? LastModified { get; private set; }
        public Dictionary<string, string> VariantTypes { get; private set; }

        public void SetQuantity(int quantity)
        {
            Quantity = quantity;
        }

        public void SetBuyPrice(Money buyPrice)
        {
            BuyPrice = buyPrice;
        }

        public void SetBuyQuantity(int buyQuantity)
        {
            BuyQuantity = buyQuantity;
        }

        public void SetProductVariantId(ProductVariantId productVariantId)
        {
            ProductVariantId = productVariantId;
        }

        public void SetPrice(Money price)
        {
            Price = price;
        }

        public void SetName(string name)
        {
            Name = name;
        }

        public void SetVariantTypes(Dictionary<string, string> variantTypes)
        {
            VariantTypes = variantTypes;
        }

        public void AddVariantType(string key, string value)
        {
            VariantTypes.Add(key, value);
        }

        public void SetLastModifiedDate(DateTime lastModifiedDate)
        {
            LastModified = lastModifiedDate;
        }

        public static Result<StoreProduct> Create(
            ProductCatalogId productId,
            ExternalProductId externalProductId,
            ExternalVariantId externalVariantId,
            ProductVariantId productVariantId,
            StoreId storeId,
            string name,
            Money price,
            int quantity,
            Money? buyPrice,
            int buyQuantity,
            Dictionary<string, string> variantTypes
        )
        {
            if (productId.Value == Guid.Empty)
                Result.Failure<StoreProduct>(Errors.Store.InvalidProductCatalogId(productId.Value));

            if (externalProductId.Value <= 0)
                Result.Failure<StoreProduct>(Errors.Store.InvalidExternalProductCatalogId(externalProductId.Value));

            if (externalVariantId.Value <= 0)
                Result.Failure<StoreProduct>(Errors.Store.InvalidExternalVariantCatalogId(externalVariantId.Value));

            if (productVariantId.Value == Guid.Empty)
                Result.Failure<StoreProduct>(Errors.Store.InvalidProductVariantId(productVariantId.Value));

            if (string.IsNullOrWhiteSpace(name))
                Result.Failure<StoreProduct>(Errors.General.NullOrWhiteSpaceString(name));

            if (price.Amount <= 0m)
                Result.Failure<StoreProduct>(Errors.General.MoneyAmountMustBeGreaterThanZero(price.Amount));

            return new StoreProduct(
                productId,
                externalProductId,
                externalVariantId,
                productVariantId,
                storeId,
                name,
                price,
                quantity,
                buyPrice,
                buyQuantity,
                variantTypes
            );
        }

        private StoreProduct(
            ProductCatalogId productId,
            ExternalProductId externalProductId,
            ExternalVariantId externalVariantId,
            ProductVariantId productVariantId,
            StoreId storeId,
            string name,
            Money price,
            int quantity,
            Money? buyPrice,
            int buyQuantity,
            Dictionary<string, string> variantTypes
        )
        {
            Id = new StoreProductId(Guid.NewGuid());
            ProductCatalogId = productId;
            ExternalProductId = externalProductId;
            ExternalVariantId = externalVariantId;
            ProductVariantId = productVariantId;
            StoreId = storeId;
            Name = name;
            Price = price;
            Quantity = quantity;
            BuyPrice = buyPrice;
            BuyQuantity = buyQuantity;

            if (!variantTypes.ContainsKey("Language"))
            {
                variantTypes.Add("Language", "English");
            }

            VariantTypes = variantTypes;
        }

        public void UpdateProduct(UpdateProductData updateProductData, StoreProduct storeProduct, DateTime incomingUpdatedAt)
        {
            Id = storeProduct.Id;
            ProductCatalogId = storeProduct.ProductCatalogId;
            ExternalProductId = storeProduct.ExternalProductId;
            ExternalVariantId = storeProduct.ExternalVariantId;
            ProductVariantId = storeProduct.ProductVariantId;
            StoreId = storeProduct.StoreId;
            Name = updateProductData.Name;
            Price = Money.Of(updateProductData.Price, Currency.USDollar.Code);
            Quantity = updateProductData.Quantity;
            BuyPrice = updateProductData.BuyPrice.HasValue
                ? Money.Of(updateProductData.BuyPrice.Value, Currency.USDollar.Code)
                : null;
            BuyQuantity = storeProduct.BuyQuantity;
            VariantTypes = updateProductData
                .Variants.Where(d => !string.IsNullOrWhiteSpace(d.Key) && !string.IsNullOrWhiteSpace(d.Value))
                .ToDictionary(d => d.Key, d => d.Value);
            LastModified = incomingUpdatedAt;
        }

        private StoreProduct() { }
    }
}
