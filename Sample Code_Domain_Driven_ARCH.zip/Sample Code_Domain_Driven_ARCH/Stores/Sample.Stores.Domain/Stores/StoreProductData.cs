﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class StoreProductData : ValueObject<StoreSearchData>
{
    public int TotalItems { get; private set; }
    public List<StoreSearchData> StoreSearchData { get; private set; }

    private StoreProductData(int totalItems, List<StoreSearchData> storeSearchData)
    {
        TotalItems = totalItems;
        StoreSearchData = storeSearchData;
    }

    public static Result<StoreProductData> Create(int totalItems, List<StoreSearchData> storeSearchData)
    {
        return Result.Success(new StoreProductData(totalItems, storeSearchData));
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return TotalItems;
        yield return StoreSearchData;
    }
}
