﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public record StoreProductId(Guid Value) : StronglyTypedId<Guid>(Value);
