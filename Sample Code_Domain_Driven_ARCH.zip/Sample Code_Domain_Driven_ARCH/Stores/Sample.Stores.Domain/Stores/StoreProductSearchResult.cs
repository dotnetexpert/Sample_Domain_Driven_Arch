﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class StoreProductSearchResult : ValueObject<StoreProductSearchResult>
{
    public Guid ProductId { get; private set; }
    public string ProductName { get; private set; }
    public string Description { get; private set; }
    public Money Price { get; private set; }
    public StoreId StoreId { get; private set; }
    public string ImageUrl { get; private set; }
    public string CategoryName { get; private set; }
    public Guid CategoryId { get; private set; }
    public int AvailableQuantity { get; private set; }
    public bool IsPreOrder { get; private set; }
    public int NumberOfStoresSelling { get; private set; }
    public Money LowestPrice { get; private set; }

    private StoreProductSearchResult(
        Guid productId,
        string productName,
        string description,
        Money price,
        StoreId storeId,
        string imageUrl,
        string categoryName,
        Guid categoryId,
        int numberOfStoresSelling,
        int availableQuantity,
        bool isPreOrder,
        Money lowestPrice
    )
    {
        ProductId = productId;
        ProductName = productName;
        Description = description;
        Price = price;
        StoreId = storeId;
        ImageUrl = imageUrl;
        CategoryName = categoryName;
        CategoryId = categoryId;
        NumberOfStoresSelling = numberOfStoresSelling;
        AvailableQuantity = availableQuantity;
        IsPreOrder = isPreOrder;
        LowestPrice = lowestPrice;
    }

    public static Result<StoreProductSearchResult> Create(
        Guid productId,
        string productName,
        string description,
        Money price,
        StoreId storeId,
        string imageUrl,
        string categoryName,
        Guid categoryId,
        int numberOfStoresSelling,
        int availableQuantity,
        bool isPreOrder,
        Money lowestPrice
    )
    {
        return Result.Success(
            new StoreProductSearchResult(
                productId,
                productName,
                description,
                price,
                storeId,
                imageUrl,
                categoryName,
                categoryId,
                numberOfStoresSelling,
                availableQuantity,
                isPreOrder,
                lowestPrice
            )
        );
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return ProductId;
        yield return ProductName;
        yield return Description;
        yield return Price;
        yield return StoreId;
        yield return ImageUrl;
        yield return CategoryName;
        yield return CategoryId;
        yield return NumberOfStoresSelling;
        yield return AvailableQuantity;
        yield return IsPreOrder;
        yield return LowestPrice;
    }
}
