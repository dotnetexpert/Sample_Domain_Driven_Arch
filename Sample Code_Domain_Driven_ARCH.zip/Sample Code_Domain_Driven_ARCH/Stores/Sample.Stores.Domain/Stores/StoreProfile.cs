﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class StoreProfile : ValueObject<StoreProfile>
{
    public string Name { get; private set; }
    public Address Address { get; private set; }
    public string EmailAddress { get; private set; }
    public string PhoneNumber { get; private set; }

    public static Result<StoreProfile> Create(string name, Address address, string emailAddress, string phoneNumber)
    {
        if (string.IsNullOrWhiteSpace(name))
            return Result.Failure<StoreProfile>(Errors.Store.InvalidStoreName(name));

        if (string.IsNullOrWhiteSpace(emailAddress))
            return Result.Failure<StoreProfile>(Errors.Store.InvalidEmailAddress(emailAddress));

        if (string.IsNullOrWhiteSpace(phoneNumber))
            return Result.Failure<StoreProfile>(Errors.Store.InvalidPhoneNumber(phoneNumber));

        return Result.Success(new StoreProfile(name, address, emailAddress, phoneNumber));
    }

    private StoreProfile(string name, Address address, string emailAddress, string phoneNumber)
    {
        Name = name;
        Address = address;
        EmailAddress = emailAddress;
        PhoneNumber = phoneNumber;
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Name;
        yield return Address;
        yield return EmailAddress;
        yield return PhoneNumber;
    }
}
