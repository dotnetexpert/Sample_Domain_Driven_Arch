﻿using System.Text.Json.Serialization;
using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class StoreRegistration : ValueObject<StoreRegistration>
{
    private StoreRegistration(string email, string apiKey)
    {
        Status = StoreRegistrationStatus.HandshakeInitialized;
        ConfirmationCode = Guid.NewGuid().ToString();
        EmailAddress = email;
        ApiKey = apiKey;
    }

    public StoreRegistrationStatus Status { get; private set; }
    public string ConfirmationCode { get; private set; }
    public string EmailAddress { get; private set; }
    public string? Sub { get; private set; }

    [JsonIgnore]
    public string ApiKey { get; set; }

    public static Result<StoreRegistration> Create(string email, string apiKey)
    {
        if (string.IsNullOrWhiteSpace(email))
            Result.Failure<Review>(Errors.General.NullOrWhiteSpaceString(email));

        if (string.IsNullOrWhiteSpace(apiKey))
            Result.Failure<Review>(Errors.General.NullOrWhiteSpaceString(apiKey));

        return new StoreRegistration(email, apiKey);
    }

    public bool CanConfirmHandshake()
    {
        return Status == StoreRegistrationStatus.HandshakeInitialized;
    }

    public Result SetEmailAddress(string emailAddress)
    {
        if (string.IsNullOrEmpty(emailAddress))
        {
            return Result.Failure(Errors.General.NullOrWhiteSpaceString(emailAddress));
        }

        EmailAddress = emailAddress;

        return Result.Success();
    }

    public Result<StoreRegistration> SetRegistrationStatus(StoreRegistrationStatus newStatus)
    {
        if (
            (newStatus == StoreRegistrationStatus.AwaitingConfirmation && Status != StoreRegistrationStatus.HandshakeInitialized)
            || (newStatus == StoreRegistrationStatus.Confirmed && Status != StoreRegistrationStatus.AwaitingConfirmation)
            || (newStatus == StoreRegistrationStatus.SyncingInitialInventory && Status != StoreRegistrationStatus.Confirmed)
            || (
                newStatus == StoreRegistrationStatus.InventorySyncError
                && Status != StoreRegistrationStatus.SyncingInitialInventory
            )
        )
            return Result.Failure<StoreRegistration>(Errors.Store.InvalidRegistrationStatus(newStatus, Status));

        Status = newStatus;

        return Result.Success(this);
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return EmailAddress ?? string.Empty;
        yield return ConfirmationCode ?? string.Empty;
        yield return Status;
        yield return Sub;
    }

    private StoreRegistration() { }
}
