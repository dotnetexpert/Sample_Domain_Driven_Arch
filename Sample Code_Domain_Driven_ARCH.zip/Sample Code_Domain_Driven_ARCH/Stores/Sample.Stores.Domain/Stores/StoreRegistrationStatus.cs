﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class StoreRegistrationStatus : Enumeration<StoreRegistrationStatus>
{
    public static readonly StoreRegistrationStatus Complete = new StoreRegistrationStatus(1, "Complete");
    public static readonly StoreRegistrationStatus HandshakeInitialized = new StoreRegistrationStatus(2, "HandshakeInitialized");
    public static readonly StoreRegistrationStatus AwaitingConfirmation = new StoreRegistrationStatus(3, "Awaiting Confirmation");
    public static readonly StoreRegistrationStatus Confirmed = new StoreRegistrationStatus(4, "Confirmed");
    public static readonly StoreRegistrationStatus SyncingInitialInventory = new StoreRegistrationStatus(
        5,
        "Syncing Initial Inventory"
    );
    public static readonly StoreRegistrationStatus InventorySyncError = new StoreRegistrationStatus(6, "Iventory Sync Error");
    public static readonly StoreRegistrationStatus Desync = new StoreRegistrationStatus(7, "Desync");

    private StoreRegistrationStatus(int value, string name)
        : base(value, name) { }
}
