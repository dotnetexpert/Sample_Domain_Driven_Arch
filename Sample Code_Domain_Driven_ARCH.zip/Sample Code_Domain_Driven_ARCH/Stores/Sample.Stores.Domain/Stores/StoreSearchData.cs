﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class StoreSearchData : ValueObject<StoreSearchData>
{
    public string ProductName { get; private set; }
    public Money Price { get; private set; }
    public string Description { get; private set; }
    public Guid StoreId { get; private set; }
    public string StoreName { get; private set; }
    public string ImageUrl { get; private set; }
    public string CategoryName { get; private set; }
    public string ParentCategoryName { get; private set; }
    public Guid ParentCategoryId { get; private set; }
    public int StoreSales { get; private set; }
    public decimal StoreRating { get; private set; }
    public int AvailableQuantity { get; private set; }
    public Money ShippingCost { get; private set; }
    public Guid ProductId { get; private set; }
    public Guid ProductCatalogId { get; private set; }
    public Guid ProductVariantId { get; private set; }
    public int NumberOfStoresSelling { get; private set; }
    public bool IsPreOrder { get; private set; }
    public Dictionary<string, string> Variants { get; private set; }

    private StoreSearchData(
        string productName,
        Money price,
        string description,
        Guid storeId,
        string storeName,
        string imageUrl,
        string categoryName,
        string parentCategoryName,
        Guid parentCategoryId,
        int storeSales,
        decimal storeRating,
        int availableQuantity,
        Money shippingCost,
        Guid productId,
        Guid productCatalogId,
        Guid productVariantId,
        int numberOfStoresSelling,
        Dictionary<string, string> variants,
        bool isPreOrder
    )
    {
        ProductName = productName;
        Price = price;
        Description = description;
        StoreId = storeId;
        StoreName = storeName;
        ImageUrl = imageUrl;
        CategoryName = categoryName;
        ParentCategoryName = parentCategoryName;
        ParentCategoryId = parentCategoryId;
        StoreSales = storeSales;
        StoreRating = storeRating;
        AvailableQuantity = availableQuantity;
        ShippingCost = shippingCost;
        ProductId = productId;
        ProductCatalogId = productCatalogId;
        ProductVariantId = productVariantId;
        NumberOfStoresSelling = numberOfStoresSelling;
        Variants = variants;
        IsPreOrder = isPreOrder;
    }

    public static Result<StoreSearchData> Create(
        string productName,
        Money price,
        string description,
        Guid storeId,
        string storeName,
        string imageUrl,
        string categoryName,
        string parentCategoryName,
        Guid parentCategoryId,
        int storeSales,
        decimal storeRating,
        int availableQuantity,
        Money shippingCost,
        Guid productId,
        Guid productCatalogId,
        Guid productVariantId,
        int numberOfStoresSelling,
        bool isPreOrder,
        Dictionary<string, string> variants
    )
    {
        return Result.Success(
            new StoreSearchData(
                productName,
                price,
                description,
                storeId,
                storeName,
                imageUrl,
                categoryName,
                parentCategoryName,
                parentCategoryId,
                storeSales,
                storeRating,
                availableQuantity,
                shippingCost,
                productId,
                productCatalogId,
                productVariantId,
                numberOfStoresSelling,
                variants,
                isPreOrder
            )
        );
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return ProductName;
        yield return Price;
        yield return Description;
        yield return StoreId;
        yield return StoreName;
        yield return ImageUrl;
        yield return CategoryName;
        yield return ParentCategoryName;
        yield return ParentCategoryId;
        yield return StoreSales;
        yield return StoreRating;
        yield return AvailableQuantity;
        yield return ShippingCost;
        yield return ProductId;
        yield return ProductCatalogId;
        yield return NumberOfStoresSelling;
        yield return Variants;
        yield return IsPreOrder;
    }
}
