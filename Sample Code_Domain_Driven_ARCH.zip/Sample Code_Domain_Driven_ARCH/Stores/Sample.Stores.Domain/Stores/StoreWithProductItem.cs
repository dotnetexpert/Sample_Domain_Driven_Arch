﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public class StoreWithProductItem : ValueObject<StoreWithProductItem>
{
    public string StoreName { get; private set; }
    public decimal StoreRating { get; private set; }
    public string ProductName { get; private set; }
    public Money Price { get; private set; }
    public int ProductQuantity { get; private set; }
    public int StoreSales { get; private set; }
    public Guid StoreId { get; private set; }
    public Money ShippingCost { get; private set; }
    public Money TotalPrice { get; private set; }
    public Guid ProductId { get; private set; }
    public Guid ProductCatalogId { get; private set; }
    public Guid ProductVariantId { get; private set; }
    public Dictionary<string, string> Variants { get; private set; }

    private StoreWithProductItem(
        string storeName,
        decimal storeRating,
        string productName,
        Money price,
        int productQuantity,
        int storeSales,
        Guid storeId,
        Money shippingCost,
        Money totalPrice,
        Guid productId,
        Guid productCatalogId,
        Guid productVariantId,
        Dictionary<string, string> variants
    )
    {
        StoreName = storeName;
        StoreRating = storeRating;
        ProductName = productName;
        Price = price;
        ProductQuantity = productQuantity;
        StoreSales = storeSales;
        StoreId = storeId;
        ShippingCost = shippingCost;
        TotalPrice = totalPrice;
        ProductId = productId;
        ProductCatalogId = productCatalogId;
        ProductVariantId = productVariantId;
        Variants = variants;
    }

    public static Result<StoreWithProductItem> Create(
        string StoreName,
        decimal StoreRating,
        string ProductName,
        Money Price,
        int ProductQuantity,
        int storeSales,
        Guid storeId,
        Money shippingCost,
        Money totalPrice,
        Guid productId,
        Guid productCatalogId,
        Guid productVariantId,
        Dictionary<string, string> variants
    )
    {
        return Result.Success(
            new StoreWithProductItem(
                StoreName,
                StoreRating,
                ProductName,
                Price,
                ProductQuantity,
                storeSales,
                storeId,
                shippingCost,
                totalPrice,
                productId,
                productCatalogId,
                productVariantId,
                variants
            )
        );
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return StoreName;
        yield return StoreRating;
        yield return ProductName;
        yield return Price;
        yield return ProductQuantity;
        yield return StoreSales;
        yield return StoreId;
        yield return ShippingCost;
        yield return TotalPrice;
        yield return ProductId;
        yield return ProductCatalogId;
        yield return Variants;
    }
}
