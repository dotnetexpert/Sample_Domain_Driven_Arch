﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public record class UpdateProductInventoryData(StoreProductId ProductId, string ProductName, int Quantity, Money UnitPrice);
