﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public record UpdateShippingOptionsData(
    StoreId StoreId,
    Money Small,
    Money Medium,
    Money Large,
    Money? FreeShippingThreshold,
    Money TrackingRequiredThreshold,
    string? CountryCode
);
