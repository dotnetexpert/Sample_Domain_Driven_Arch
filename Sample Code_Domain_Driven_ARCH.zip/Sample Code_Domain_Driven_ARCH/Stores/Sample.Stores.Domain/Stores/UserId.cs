﻿using Sample.Stores.Domain.Core;

namespace Sample.Stores.Domain.Stores;

public record UserId(Guid Value) : StronglyTypedId<Guid>(Value);
