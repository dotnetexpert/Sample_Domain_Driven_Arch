﻿using System.Text.Json.Serialization;

namespace Sample.Stores.Infrastructure.Auth0;

public class TokenResponse
{
    [JsonPropertyName("access_token")]
    public string AccessToken { get; set; }
}
