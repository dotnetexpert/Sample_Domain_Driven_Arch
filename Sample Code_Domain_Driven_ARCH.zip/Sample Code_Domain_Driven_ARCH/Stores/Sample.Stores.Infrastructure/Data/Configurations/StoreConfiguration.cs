﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using Sample.Stores.Domain.Stores;

namespace Sample.Stores.Infrastructure.Data.Configurations;

public class StoreConfiguration : IEntityTypeConfiguration<Store>
{
    public void Configure(EntityTypeBuilder<Store> builder)
    {
        builder.HasKey(p => p.Id);

        builder.Property(p => p.Id).HasConversion(id => id.Value, value => new StoreId(value));

        builder.Property(p => p.Name).HasMaxLength(100).IsRequired();

        builder.Property(p => p.DomainName).HasMaxLength(100).IsRequired();

        builder.Property(p => p.IsActive).IsRequired();

        builder.OwnsOne(
            p => p.Address,
            p =>
            {
                p.Property(p => p.Address1).HasColumnName("Address1").IsRequired(false);

                p.Property(p => p.Address2).HasColumnName("Address2").IsRequired(false);

                p.Property(p => p.City).HasColumnName("City").IsRequired(false);

                p.Property(p => p.ZipCode).HasColumnName("ZipCode").IsRequired(false);

                p.Property(p => p.State).HasColumnName("State").IsRequired(false);

                p.Property(p => p.Country).HasColumnName("Country").IsRequired(false);
            }
        );

        builder.OwnsOne(
            p => p.Registration,
            p =>
            {
                p.Property(r => r.Status).HasConversion(r => r.Value, r => StoreRegistrationStatus.FromValue(r));
            }
        );

        builder.OwnsOne(
            p => p.ShippingConfiguration,
            p =>
            {
                p.OwnsOne(
                    p => p.LetterShippingCost,
                    p =>
                    {
                        p.Property(p => p.Amount).HasColumnName("LetterShippingCostAmount").HasPrecision(11, 2).IsRequired();

                        p.Property(p => p.Currency).HasColumnName("LetterShippingCostCurrencyCode").HasMaxLength(3).IsRequired();
                    }
                );

                p.OwnsOne(
                    p => p.BoxShippingCost,
                    p =>
                    {
                        p.Property(p => p.Amount).HasColumnName("BoxShippingCostAmount").HasPrecision(11, 2).IsRequired();

                        p.Property(p => p.Currency).HasColumnName("BoxShippingCostCurrencyCode").HasMaxLength(3).IsRequired();
                    }
                );

                p.OwnsOne(
                    p => p.LargePackageShippingCost,
                    p =>
                    {
                        p.Property(p => p.Amount)
                            .HasColumnName("LargePackageShippingCostAmount")
                            .HasPrecision(11, 2)
                            .IsRequired();

                        p.Property(p => p.Currency)
                            .HasColumnName("LargePackageShippingCostCurrencyCode")
                            .HasMaxLength(3)
                            .IsRequired();
                    }
                );
            }
        );

        builder.OwnsOne(p => p.PaymentConfiguration);

        builder.OwnsOne(p => p.ContactInformation);

        builder.HasMany(s => s.ShippingOptions).WithOne().HasForeignKey(so => so.StoreId);
    }
}
