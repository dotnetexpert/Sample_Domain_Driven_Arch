﻿using System.Reflection;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Sample.Stores.Domain.Stores;

namespace Sample.Stores.Infrastructure.Data;

public class StoreContext : DbContext
{
    private readonly IConfiguration _configuration;
#pragma warning disable CS8618 // Required by Entity Framework
    public StoreContext(DbContextOptions<StoreContext> options)
        : base(options) { }

    public StoreContext(DbContextOptions<StoreContext> options, IConfiguration configuration)
        : base(options)
    {
        _configuration = configuration;
    }

    public DbSet<Store> Stores { get; set; }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);
        builder.ApplyConfigurationsFromAssembly(Assembly.GetExecutingAssembly());
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseNpgsql(_configuration.GetConnectionString("StoresConnectionString"));
    }
}
