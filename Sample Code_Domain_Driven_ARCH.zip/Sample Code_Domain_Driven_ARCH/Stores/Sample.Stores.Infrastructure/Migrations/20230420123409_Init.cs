﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Sample.Stores.Infrastructure.Migrations;

/// <inheritdoc />
public partial class Init : Migration
{
    /// <inheritdoc />
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(
            name: "Stores",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                Name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
                Address1 = table.Column<string>(type: "text", nullable: false),
                Address2 = table.Column<string>(type: "text", nullable: true),
                City = table.Column<string>(type: "text", nullable: false),
                State = table.Column<string>(type: "text", nullable: false),
                ZipCode = table.Column<string>(type: "text", nullable: false),
                Country = table.Column<string>(type: "text", nullable: false),
                ContactInformation_FirstName = table.Column<string>(type: "text", nullable: false),
                ContactInformation_LastName = table.Column<string>(type: "text", nullable: false),
                ContactInformation_EmailAddress = table.Column<string>(type: "text", nullable: false),
                ContactInformation_PhoneNumber = table.Column<string>(type: "text", nullable: false),
                ContactInformation_UsedOnlyForEntityFramework = table.Column<bool>(type: "boolean", nullable: false),
                LetterShippingCostAmount = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: true),
                LetterShippingCostCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: true),
                BoxShippingCostAmount = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: true),
                BoxShippingCostCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: true),
                LargePackageShippingCostAmount = table.Column<decimal>(
                    type: "numeric(11,2)",
                    precision: 11,
                    scale: 2,
                    nullable: true
                ),
                LargePackageShippingCostCurrencyCode = table.Column<string>(
                    type: "character varying(3)",
                    maxLength: 3,
                    nullable: true
                ),
                ShippingConfiguration_UsedOnlyForEntityFramework = table.Column<bool>(type: "boolean", nullable: true),
                PaymentConfiguration_Token = table.Column<string>(type: "text", nullable: true),
                PaymentConfiguration_AccountNumberMask = table.Column<string>(type: "text", nullable: true),
                PaymentConfiguration_AccountName = table.Column<string>(type: "text", nullable: true),
                PaymentConfiguration_UsedOnlyForEntityFramework = table.Column<bool>(type: "boolean", nullable: true),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Stores", x => x.Id);
            }
        );

        migrationBuilder.CreateTable(
            name: "Order",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                Tax = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: false),
                TaxCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                StoreId = table.Column<Guid>(type: "uuid", nullable: false),
                ShippingCost = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: false),
                ShippingCostCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                Date = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                CustomerName = table.Column<string>(type: "text", nullable: false),
                CustomerId = table.Column<Guid>(type: "uuid", nullable: false),
                ShippingAddress1 = table.Column<string>(type: "text", nullable: false),
                ShippingAddress2 = table.Column<string>(type: "text", nullable: false),
                ShippingCity = table.Column<string>(type: "text", nullable: false),
                ShippingState = table.Column<string>(type: "text", nullable: false),
                ShippingZipCode = table.Column<string>(type: "text", nullable: false),
                ShippingCountry = table.Column<string>(type: "text", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Order", x => x.Id);
                table.ForeignKey(
                    name: "FK_Order_Stores_StoreId",
                    column: x => x.StoreId,
                    principalTable: "Stores",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Cascade
                );
            }
        );

        migrationBuilder.CreateTable(
            name: "Review",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                StoreId = table.Column<Guid>(type: "uuid", nullable: false),
                Rating = table.Column<int>(type: "integer", nullable: false),
                Comment = table.Column<string>(type: "character varying(400)", maxLength: 400, nullable: false),
                CustomerName = table.Column<string>(type: "text", nullable: false),
                CustomerId = table.Column<Guid>(type: "uuid", nullable: false),
                Date = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Review", x => x.Id);
                table.ForeignKey(
                    name: "FK_Review_Stores_StoreId",
                    column: x => x.StoreId,
                    principalTable: "Stores",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Cascade
                );
            }
        );

        migrationBuilder.CreateTable(
            name: "StaffMember",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                UserId = table.Column<Guid>(type: "uuid", nullable: false),
                StoreId = table.Column<Guid>(type: "uuid", nullable: false),
                FirstName = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                LastName = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                EmailAddress = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_StaffMember", x => x.Id);
                table.ForeignKey(
                    name: "FK_StaffMember_Stores_StoreId",
                    column: x => x.StoreId,
                    principalTable: "Stores",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Cascade
                );
            }
        );

        migrationBuilder.CreateTable(
            name: "StoreProduct",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                StoreId = table.Column<Guid>(type: "uuid", nullable: false),
                ProductCatalogId = table.Column<Guid>(type: "uuid", nullable: false),
                Name = table.Column<string>(type: "text", nullable: false),
                Price = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: false),
                PriceCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                Quantity = table.Column<int>(type: "integer", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_StoreProduct", x => x.Id);
                table.ForeignKey(
                    name: "FK_StoreProduct_Stores_StoreId",
                    column: x => x.StoreId,
                    principalTable: "Stores",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Cascade
                );
            }
        );

        migrationBuilder.CreateTable(
            name: "Message",
            columns: table => new
            {
                OrderId = table.Column<Guid>(type: "uuid", nullable: false),
                Id = table
                    .Column<int>(type: "integer", nullable: false)
                    .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                FromId = table.Column<Guid>(type: "uuid", nullable: false),
                FromName = table.Column<string>(type: "text", nullable: false),
                Subject = table.Column<string>(type: "text", nullable: false),
                Body = table.Column<string>(type: "text", nullable: false),
                Date = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Message", x => new { x.OrderId, x.Id });
                table.ForeignKey(
                    name: "FK_Message_Order_OrderId",
                    column: x => x.OrderId,
                    principalTable: "Order",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Cascade
                );
            }
        );

        migrationBuilder.CreateTable(
            name: "OrderLineItem",
            columns: table => new
            {
                OrderId = table.Column<Guid>(type: "uuid", nullable: false),
                Id = table
                    .Column<int>(type: "integer", nullable: false)
                    .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                ProductId = table.Column<Guid>(type: "uuid", nullable: false),
                ProductName = table.Column<string>(type: "text", nullable: false),
                Price = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: false),
                PriceCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                Quantity = table.Column<int>(type: "integer", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_OrderLineItem", x => new { x.OrderId, x.Id });
                table.ForeignKey(
                    name: "FK_OrderLineItem_Order_OrderId",
                    column: x => x.OrderId,
                    principalTable: "Order",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Cascade
                );
            }
        );

        migrationBuilder.CreateTable(
            name: "Refund",
            columns: table => new
            {
                Id = table.Column<Guid>(type: "uuid", nullable: false),
                OrderId = table.Column<Guid>(type: "uuid", nullable: false),
                RefundAmount = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: false),
                AmountCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                ShippingCost = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: false),
                ShippingCostCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                Tax = table.Column<decimal>(type: "numeric(11,2)", precision: 11, scale: 2, nullable: false),
                TaxCurrencyCode = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                Date = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
            },
            constraints: table =>
            {
                table.PrimaryKey("PK_Refund", x => x.Id);
                table.ForeignKey(
                    name: "FK_Refund_Order_OrderId",
                    column: x => x.OrderId,
                    principalTable: "Order",
                    principalColumn: "Id",
                    onDelete: ReferentialAction.Cascade
                );
            }
        );

        migrationBuilder.CreateIndex(name: "IX_Order_StoreId", table: "Order", column: "StoreId");

        migrationBuilder.CreateIndex(name: "IX_Refund_OrderId", table: "Refund", column: "OrderId");

        migrationBuilder.CreateIndex(name: "IX_Review_StoreId", table: "Review", column: "StoreId");

        migrationBuilder.CreateIndex(name: "IX_StaffMember_StoreId", table: "StaffMember", column: "StoreId");

        migrationBuilder.CreateIndex(name: "IX_StoreProduct_StoreId", table: "StoreProduct", column: "StoreId");
    }

    /// <inheritdoc />
    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(name: "Message");

        migrationBuilder.DropTable(name: "OrderLineItem");

        migrationBuilder.DropTable(name: "Refund");

        migrationBuilder.DropTable(name: "Review");

        migrationBuilder.DropTable(name: "StaffMember");

        migrationBuilder.DropTable(name: "StoreProduct");

        migrationBuilder.DropTable(name: "Order");

        migrationBuilder.DropTable(name: "Stores");
    }
}
