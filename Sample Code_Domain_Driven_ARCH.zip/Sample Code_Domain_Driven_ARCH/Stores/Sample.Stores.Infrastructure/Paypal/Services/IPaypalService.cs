﻿using System.Threading.Tasks;
using Sample.Stores.Infrastructure.Paypal.Models;

namespace Sample.Stores.Infrastructure.Paypal.Services;

public interface IPaypalService
{
    Task<MerchantIntegrationResponse> GetMerchantIntegrationAsync(string merchantId);
}
