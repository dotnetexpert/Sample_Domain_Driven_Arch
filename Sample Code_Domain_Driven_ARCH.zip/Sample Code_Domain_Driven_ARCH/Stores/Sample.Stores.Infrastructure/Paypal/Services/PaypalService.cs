﻿using System;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using RestSharp;
using Sample.CrossCutting.Infrastructure.Models;
using Sample.Stores.Infrastructure.Paypal.Models;

namespace Sample.Stores.Infrastructure.Paypal.Services;

public class PaypalService : IPaypalService
{
    private readonly ILogger<PaypalService> _logger;
    private readonly PaypalConfiguration _configuration;
    private readonly PaypalOnboardingConfiguration _onboardingConfiguration;

    public PaypalService(
        ILogger<PaypalService> logger,
        IOptions<PaypalConfiguration> configuration,
        IOptions<PaypalOnboardingConfiguration> onboardingConfiguration
    )
    {
        _logger = logger;
        _configuration = configuration.Value;
        _onboardingConfiguration = onboardingConfiguration.Value;
    }

    public async Task<AuthToken> GetAuthTokenAsync()
    {
        var client = new RestClient(_configuration.BaseUrl);
        var request = new RestRequest("/v1/oauth2/token", Method.Post);

        request.AddHeader("Content-Type", "application/x-www-form-urlencoded");
        request.AddParameter("application/x-www-form-urlencoded", $"grant_type=client_credentials", ParameterType.RequestBody);

        var encodedAuthentication = Base64Encode($"{_configuration.ClientId}:{_configuration.ClientSecret}");

        request.AddHeader("Authorization", $"Basic {encodedAuthentication}");

        var response = await client.ExecuteAsync<AuthToken>(request);

        if (!response.IsSuccessStatusCode)
        {
            _logger.LogError($"Error authenticating to paypal with encodedAuthentication: {encodedAuthentication}");
            throw new Exception($"Error retrieving authentication token: {response.ErrorException.Message}");
        }

        return response.Data;
    }
}
