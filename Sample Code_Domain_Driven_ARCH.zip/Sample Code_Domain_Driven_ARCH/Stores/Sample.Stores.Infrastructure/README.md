﻿## EF Commands

Run inside the main services folder. For example, the Stores domain would run this from ./Stores
* dotnet ef migrations add CustomerChanges --startup-project=./../Sample.API --verbose --project=./Sample.Customers.Infrastructure -c=CustomerContext
* dotnet ef database update --startup-project=./../Sample.API --verbose --project=./Sample.Customers.Infrastructure -c=CustomerContext