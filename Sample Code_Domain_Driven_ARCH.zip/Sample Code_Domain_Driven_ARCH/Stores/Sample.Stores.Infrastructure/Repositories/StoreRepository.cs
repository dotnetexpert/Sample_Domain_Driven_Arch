﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MassTransit.Initializers;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Sample.Stores.Domain.Core;
using Sample.Stores.Domain.Stores;
using Sample.Stores.Infrastructure.Data;

namespace Sample.Stores.Infrastructure.Repositories;

public class StoreRepository : IStoreRepository
{
    private readonly StoreContext _context;
    ILogger<StoreRepository> _logger;

    public StoreRepository(StoreContext context, ILogger<StoreRepository> logger)
    {
        _context = context;
        _logger = logger;
    }

    public async Task<List<Guid>> GetPaymentReceivableProductCatalogIdsAsync(List<Guid> productCatalogIds)
    {
        var paymentReceivableIds = _context
            .Stores.Where(s => s.IsPaymentsReceivable)
            .SelectMany(s => s.Products.Select(p => new { StoreId = s.Id, ProductCatalogId = p.ProductCatalogId }))
            .AsEnumerable()
            .Where(sp => productCatalogIds.Contains(sp.ProductCatalogId.Value))
            .Select(sp => sp.ProductCatalogId.Value)
            .Distinct()
            .ToList();

        return paymentReceivableIds;
    }

    public async Task<List<StoreProduct>> GetProductViaProductCatalogIdsAsync(List<ProductCatalogId> productCatalogIds)
    {
        var storeProductCounts = await _context
            .Stores.Select(s => new
            {
                StoreId = s.Id,
                ProductCount = s.Products.Count(p => productCatalogIds.Contains(p.ProductCatalogId)),
                Products = s.Products.Where(p => productCatalogIds.Contains(p.ProductCatalogId)),
            })
            .Where(s => s.ProductCount > 0)
            .OrderByDescending(s => s.ProductCount)
            .ToListAsync();

        var bestStore = storeProductCounts.FirstOrDefault();

        return bestStore?.Products.ToList() ?? new List<StoreProduct>();
    }

    public async Task<Store> GetByIdAsync(StoreId id)
    {
        return await _context.Stores.FindAsync(id);
    }

    public async Task<Order> GetStoreWithOrderById(StoreId storeId, OrderId orderId)
    {
        var storeWithOrders = await _context
            .Stores.Include(store => store.Orders.Where(order => order.OrderId == orderId && order.StoreId == storeId))
            .ThenInclude(order => order.Refunds)
            .Include(store => store.Orders.Where(order => order.OrderId == orderId && order.StoreId == storeId))
            .ThenInclude(order => order.OrderProducts)
            .FirstOrDefaultAsync(s => s.Id == storeId);

        return storeWithOrders.Orders.FirstOrDefault(o => o.OrderId == orderId);
    }

    public async Task<IEnumerable<StoreId>> GetIdListAsync()
    {
        return await _context.Stores.Where(s => s.IsActive).Select(s => s.Id).ToListAsync();
    }

    public async Task<Store> GetOrderMessages(OrderId orderId, StoreId storeId)
    {
        var storeWithOrder = await _context
            .Stores.Where(store => store.Id == storeId)
            .Include(store => store.Orders.Where(order => order.Id == orderId))
            .ThenInclude(order => order.Messages)
            .FirstOrDefaultAsync();

        if (storeWithOrder == null)
        {
            throw new Exception($"Store with orderId {orderId} not found");
        }

        return storeWithOrder;
    }

    public async Task<Store> GetWithOrdersAsync(StoreId id, OrderId orderId)
    {
        return await _context.Stores.Include(o => o.Orders.Where(o => o.Id == orderId)).FirstOrDefaultAsync(c => c.Id == id);
    }

    public async Task<Store> GetStoreByIdAsync(StoreId storeId)
    {
        var existingStore = await _context
            .Stores.Include(store => store.Orders)
            .ThenInclude(o => o.Review)
            .FirstOrDefaultAsync(store => store.Id == storeId);

        return existingStore;
    }

    public async Task<Store> GetWithOrdersAndRefundsAsync(StoreId id)
    {
        return await _context.Stores.Include(s => s.Orders).ThenInclude(s => s.Refunds).FirstOrDefaultAsync(s => s.Id == id);
    }

    public async Task<Store> GetWithProductsAsync(StoreId id)
    {
        return await _context.Stores.Include(s => s.Products).FirstOrDefaultAsync(s => s.Id == id);
    }

    public async Task<Store> GetStoreAsync(StoreId id)
    {
        return await _context.Stores.FirstOrDefaultAsync(s => s.Id == id);
    }

    public async Task<Store> GetWithStaffAsync(StoreId id)
    {
        return await _context.Stores.Include(s => s.Staff).FirstOrDefaultAsync(s => s.Id == id);
    }

    public async Task<Store> GetWithReviewsAsync(StoreId id)
    {
        return await _context.Stores.Include(s => s.Orders).ThenInclude(s => s.Review).FirstOrDefaultAsync(s => s.Id == id);
    }

    public async Task<RefundId> GetRefundIdAsync(StoreId id, OrderId orderId, decimal total)
    {
        var store = await GetWithOrdersAndRefundsAsync(id);

        var order = store.Orders.FirstOrDefault(o => o.Id == orderId);

        if (order == null)
            return null;

        var refund = order.Refunds.FirstOrDefault(r => r.Total.Amount == total);

        if (refund == null)
            return null;

        return refund.Id;
    }

    public void Update(Store store)
    {
        _context.Entry(store).State = EntityState.Modified;
    }

    public void Update(StoreProduct storeProduct)
    {
        _context.Entry(storeProduct).State = EntityState.Modified;
    }

    public void Add(Store store)
    {
        _context.Add(store);
    }

    public void Add(StoreProduct storeProduct)
    {
        _context.Add(storeProduct);
    }

    public void Add(ShippingOptions shippingOptions)
    {
        _context.Add(shippingOptions);
    }

    public async Task<Store?> GetExistsButIsntActive(string domainName)
    {
        return await _context.Stores.FirstOrDefaultAsync(s => s.DomainName.ToUpper() == domainName.ToUpper() && !s.IsActive);
    }

    public async Task SaveChangesAsync()
    {
        await _context.SaveChangesAsync();
    }

    public async Task<Store> GetWithOrdersAndStores(StoreId id, OrderId orderId)
    {
        return await _context
            .Stores.Include(o => o.Orders.Where(o => o.Id == orderId))
            .ThenInclude(c => c.Customer)
            .FirstOrDefaultAsync(c => c.Id == id);
    }

    public async Task<int> GetTotalRatings(StoreId storeId)
    {
        var query = _context.Stores.Where(store => store.Id == storeId).SelectMany(store => store.Orders);
        var result = await query.Include(order => order.Review).Where(order => order.Review != null).CountAsync();

        return result;
    }

    public async Task<IEnumerable<Order>> GetOrderRatingList(StoreId storeId, SortingPaginationOptions sortingPaginationOptions)
    {
        int startIndex = (sortingPaginationOptions.Page - 1) * sortingPaginationOptions.PageSize;
        var query = _context.Stores.Where(store => store.Id == storeId).SelectMany(store => store.Orders);

        if (sortingPaginationOptions.SortByName.HasValue)
        {
            query = sortingPaginationOptions.SortByName.Value
                ? query.OrderBy(order => order.Review.Customer.Name)
                : query.OrderByDescending(order => order.Review.Customer.Name);
        }

        if (sortingPaginationOptions.SortByDate.HasValue)
        {
            query = sortingPaginationOptions.SortByDate.Value
                ? query.OrderBy(order => order.Review.Date)
                : query.OrderByDescending(order => order.Review.Date);
        }

        if (sortingPaginationOptions.SortByRating.HasValue)
        {
            query = sortingPaginationOptions.SortByRating.Value
                ? query.OrderBy(order => order.Review.Rating)
                : query.OrderByDescending(order => order.Review.Rating);
        }

        var result = await query
            .Include(order => order.Review)
            .Where(order => order.Review != null)
            .Skip(startIndex)
            .Take(sortingPaginationOptions.PageSize)
            .ToListAsync();

        return result ?? Enumerable.Empty<Order>();
    }

    public async Task<CartStoreData> GetDataForCart(StoreId storeId, StoreProductId storeProductId, string countryCode)
    {
        var store = await _context
            .Stores.Include(s => s.Products.Where(p => p.Id == storeProductId))
            .Include(s => s.ShippingOptions.Where(p => p.CountryCode == countryCode))
            .Where(o => o.Id == storeId)
            .FirstOrDefaultAsync();

        if (store == null)
        {
            throw new Exception($"Store with ID {storeId} not found.");
        }

        if (store.Products.FirstOrDefault() == null)
        {
            throw new Exception($"Store does not have product with store product id: {storeProductId.Value}");
        }

        var storeProduct = store.Products.First();

        var shippingOptions = store.ShippingOptions.FirstOrDefault();

        if (shippingOptions is null)
        {
            throw new Exception($"Store {store.Id} does not have configured shipping options");
        }

        return CartStoreData
            .Create(
                store.Id,
                store.Name,
                store.DomainName,
                store.Registration.EmailAddress,
                storeProduct.Quantity,
                storeProduct.Id,
                storeProduct.Price,
                storeProduct.ProductCatalogId,
                storeProduct.Name,
                shippingOptions,
                storeProduct.ExternalProductId,
                storeProduct.ExternalVariantId
            )
            .Value;
    }

    public async Task<IEnumerable<StoreProduct>> GetStoreProducts(IEnumerable<ProductCatalogId> productIds)
    {
        var storeProducts = await _context
            .Stores.Where(store => store.IsOnboarded == true)
            .Include(store => store.Products)
            .SelectMany(store => store.Products.Where(product => productIds.Contains(product.ProductCatalogId)))
            .ToListAsync();

        return storeProducts;
    }

    public async Task<Dictionary<List<Store>, int>> GetStoresWithProductIdAsync(
        ProductCatalogId productCatalogId,
        PaginationAndSortingOptions paginationOptions,
        string countryCode
    )
    {
        var query = _context
            .Stores.Where(store =>
                store.IsOnboarded == true
                && store.Products.Any(p => p.ProductCatalogId == productCatalogId && p.Quantity > 0 && p.Price.Amount > 0)
            )
            .AsNoTracking()
            .Include(store => store.Orders)
            .ThenInclude(order => order.Review)
            .Include(store =>
                store.Products.Where(p => p.ProductCatalogId == productCatalogId && p.Quantity > 0 && p.Price.Amount > 0)
            )
            .Include(store => store.ShippingOptions.Where(p => p.CountryCode == (countryCode ?? "US")))
            .AsQueryable();

        if (!string.IsNullOrEmpty(paginationOptions.SearchText))
        {
            var searchTextLower = paginationOptions.SearchText.ToLower();
            query = query.Where(s => s.Name.ToLower().Contains(searchTextLower));
        }

        var storeData = await query.ToListAsync();
        var totalItemCount = await query.Select(s => s.Products.Count(p => p.ProductCatalogId == productCatalogId)).ToListAsync();

        return new Dictionary<List<Store>, int> { { storeData, totalItemCount.Sum() } };
    }

    public async Task<IEnumerable<StoreInboxItem>> GetStoreInbox(StoreId id)
    {
        var storeWithOrderData = await _context
            .Stores.Include(o => o.Orders)
            .ThenInclude(o => o.Messages)
            .FirstOrDefaultAsync(c => c.Id == id);

        if (storeWithOrderData == null)
        {
            throw new Exception("Invalid store id");
        }

        var storeName = storeWithOrderData.Name;

        return storeWithOrderData.GetStoreInboxDetails(storeName);
    }

    public async Task<IEnumerable<OrderHistoryItem>> GetStoreOrderHistory(OrderId id, StoreId storeId)
    {
        var storeWithOrders = await _context
            .Stores.Include(s => s.Orders)
            .ThenInclude(s => s.Review)
            .Include(o => o.Orders)
            .ThenInclude(o => o.OrderProducts)
            .FirstOrDefaultAsync(c => c.Id == storeId);

        if (storeWithOrders == null)
        {
            throw new Exception("Invalid Customer id");
        }

        return storeWithOrders.GetOrderDetails(id, storeWithOrders.Name);
    }

    public async Task<Store> GetStoreConfirmationAsync(string email, string confirmationCode)
    {
        var result = await _context
            .Stores.Include(s => s.Registration)
            .Include(o => o.ShippingOptions)
            .Where(s =>
                s.Registration != null
                && s.Registration.EmailAddress == email
                && s.Registration.ConfirmationCode == confirmationCode
                && (s.Registration.Sub == null || s.Registration.Sub == string.Empty)
            )
            .FirstOrDefaultAsync();

        return result;
    }

    public async Task<Store?> GetWithRegistrationAsync(StoreId id)
    {
        return await _context.Stores.Include(s => s.Registration).FirstOrDefaultAsync(s => s.Id == id);
    }

    public async Task<Store> FindStoreByEmailAsync(string emailAddress)
    {
        return await _context
            .Stores.Include(s => s.Registration)
            .Where(s => s.Registration.EmailAddress == emailAddress)
            .FirstOrDefaultAsync();
    }

    public async Task<bool> IsDomainDuplicateAsync(string domainName)
    {
        return _context.Stores.Any(s => s.DomainName.ToUpper() == domainName.ToUpper());
    }

    public async Task<bool> IsEmailDuplicateAsync(string emailAddress)
    {
        return _context.Stores.Any(s => s.Registration.EmailAddress == emailAddress);
    }

    public async Task<List<Order>> GetStoreOrderHistory(StoreId storeId, string searchText, int page = 1, int pageSize = 10)
    {
        var storeWithOrdersQuery = _context
            .Stores.Include(s => s.Orders)
            .ThenInclude(s => s.OrderProducts)
            .Include(s => s.Orders)
            .ThenInclude(o => o.Refunds)
            .Include(s => s.Orders)
            .ThenInclude(s => s.Review)
            .Include(s => s.Products)
            .Where(s => s.Id == storeId)
            .SelectMany(s => s.Orders);

        if (!string.IsNullOrEmpty(searchText))
        {
            var productSearchQuery = storeWithOrdersQuery.Where(o =>
                o.OrderProducts.Any(op => op.ProductName.ToLower().Contains(searchText.ToLower()))
            );

            if (!productSearchQuery.Any())
            {
                Guid searchTextGuid;
                var isGuid = Guid.TryParse(searchText, out searchTextGuid);

                if (isGuid)
                {
                    storeWithOrdersQuery = storeWithOrdersQuery.Where(o => o.OrderId == new OrderId(searchTextGuid));
                }
                else
                {
                    return new List<Order>();
                }
            }
            else
            {
                storeWithOrdersQuery = productSearchQuery;
            }
        }

        return await storeWithOrdersQuery.OrderByDescending(d => d.Date).Skip((page - 1) * pageSize).Take(pageSize).ToListAsync();
    }

    public async Task<ShippingOptions> GetShippingOptions(StoreId id)
    {
        var storeWithShippingOptions = await _context
            .Stores.Where(s => s.Id == id)
            .Include(s => s.ShippingOptions)
            .FirstOrDefaultAsync();

        if (storeWithShippingOptions == null)
        {
            throw new Exception("No Store found for this StoreId");
        }

        var shippingOptions = storeWithShippingOptions.ShippingOptions.FirstOrDefault();

        if (shippingOptions == null)
        {
            throw new Exception("No ShippingOptions found for this StoreId");
        }

        return shippingOptions;
    }

    public async Task<ShippingOptions> GetShippingOptionsByCountry(StoreId id, string countryCode)
    {
        var shippingOption = await _context
            .Stores.Where(s => s.Id == id)
            .Include(s => s.ShippingOptions)
            .SelectMany(s => s.ShippingOptions)
            .Where(so => so.CountryCode == countryCode)
            .FirstOrDefaultAsync();

        if (shippingOption == null)
        {
            throw new Exception($"No ShippingOptions found for StoreId {id} and Country {countryCode}");
        }

        return shippingOption;
    }

    public async Task<ShippingOptions> GetShippingOptions(StoreId id, string countryCode)
    {
        var storeWithShippingOptions = await _context
            .Stores.Where(s => s.Id == id)
            .Include(s => s.ShippingOptions.Where(s => s.CountryCode == countryCode))
            .FirstOrDefaultAsync();

        if (storeWithShippingOptions == null)
        {
            throw new Exception("No Store found for this StoreId");
        }

        var shippingOptions = storeWithShippingOptions.ShippingOptions.FirstOrDefault();

        return shippingOptions;
    }

    public async Task<Store> GetWithShippingOptions(StoreId id)
    {
        return await _context.Stores.Include(s => s.ShippingOptions).FirstOrDefaultAsync(s => s.Id == id);
    }

    public async Task<List<Store>> GetStoresWithShippingOptions(List<StoreId> storeIds)
    {
        return await _context.Stores.Include(s => s.ShippingOptions).Where(s => storeIds.Contains(s.Id)).ToListAsync();
    }

    public async Task<IEnumerable<Dictionary<string, string>>> GetStoreProductVariants(ProductCatalogId storeProductCatalogId)
    {
        var storeProductDataList = await _context
            .Stores.Include(s => s.Products.Where(sp => sp.ProductCatalogId == storeProductCatalogId))
            .Where(s => s.Products.Any(sp => sp.ProductCatalogId == storeProductCatalogId))
            .ToListAsync();

        var distinctProductVariants = storeProductDataList
            .SelectMany(s =>
                s.Products.Where(sp => sp.ProductCatalogId == storeProductCatalogId)
                    .SelectMany(product =>
                        product.VariantTypes.Select(vt => new Dictionary<string, string> { { vt.Key, vt.Value } })
                    )
            )
            .GroupBy(dict => new { Key = dict.Keys.First(), Value = dict.Values.First() })
            .Select(group => group.First())
            .ToList();

        return distinctProductVariants;
    }

    public async Task<IEnumerable<StoreProduct>> GetProductsByCatalogIdAsync(StoreId storeId, ProductCatalogId productCatalogId)
    {
        var products = await _context
            .Stores.SelectMany(store => store.Products)
            .Where(product => product.ProductCatalogId == productCatalogId && product.StoreId == storeId)
            .ToListAsync();

        if (products == null)
        {
            _logger.LogError($"No products found for StoreId: {storeId} and ProductCatalogId: {productCatalogId}");
        }

        return products;
    }

    public async Task<Dictionary<Store, List<StoreProduct>>> GetStoreProductsByCatalogAndVariantsAsync(
        List<ProductCatalogId> productCatalogIds,
        IEnumerable<string> variantTypes
    )
    {
        var storeProductMap = new Dictionary<Store, List<StoreProduct>>();
        var products = await _context
            .Stores.SelectMany(store => store.Products)
            .Where(product => productCatalogIds.Contains(product.ProductCatalogId))
            .ToListAsync();

        var filteredProducts = products.Where(p => p.VariantTypes.Any(vt => variantTypes.Contains(vt.Value))).ToList();

        var leastPriceProducts = filteredProducts
            .GroupBy(p => p.ProductCatalogId)
            .Select(g => g.OrderBy(p => p.Price.Amount).FirstOrDefault())
            .ToList();

        var productsByStore = leastPriceProducts.GroupBy(p => p.StoreId).ToDictionary(g => g.Key, g => g.ToList());

        foreach (var storeId in productsByStore.Keys)
        {
            var store = await _context.Stores.Include(s => s.ShippingOptions).FirstOrDefaultAsync(s => s.Id == storeId);

            if (store != null)
            {
                storeProductMap.Add(store, productsByStore[storeId]);
            }
        }

        return storeProductMap;
    }

    public async Task<IEnumerable<StoreProduct>> GetBuyListData(PaginationAndSortingOptions paginationAndSortingOptions)
    {
        var searchText = paginationAndSortingOptions.SearchText.ToLower();
        var query = _context.Stores.Include(store => store.Products).AsQueryable();
        var page = paginationAndSortingOptions.Page;
        var pageSize = paginationAndSortingOptions.PageSize;

        if (!string.IsNullOrEmpty(searchText))
        {
            var buyListProducts = query
                .SelectMany(store =>
                    store.Products.Where(product => product.Name.ToLower().Contains(searchText) && product.BuyQuantity > 0)
                )
                .ToList();

            if (paginationAndSortingOptions.SortByName == true)
            {
                buyListProducts = buyListProducts.OrderBy(product => product.Name).ToList();
            }
            else if (paginationAndSortingOptions.SortByItemPriceAscending.HasValue)
            {
                if (paginationAndSortingOptions.SortByItemPriceAscending == true)
                {
                    buyListProducts = buyListProducts.OrderBy(product => product.BuyPrice.Amount).ToList();
                }
                else
                {
                    buyListProducts = buyListProducts.OrderByDescending(product => product.BuyPrice.Amount).ToList();
                }
            }

            if (
                !paginationAndSortingOptions.SortByName.HasValue && !paginationAndSortingOptions.SortByItemPriceAscending.HasValue
            )
            {
                buyListProducts = buyListProducts.OrderByDescending(product => product.BuyQuantity).ToList();
            }

            buyListProducts = buyListProducts.Skip((page - 1) * pageSize).Take(pageSize).ToList();

            return buyListProducts;
        }

        return Enumerable.Empty<StoreProduct>();
    }

    public async Task<Store> GetDataForTradeInCart(StoreId storeId, StoreProductId storeProductId)
    {
        var store = await _context
            .Stores.Include(s => s.Products.Where(p => p.Id == storeProductId))
            .Where(o => o.Id == storeId)
            .FirstOrDefaultAsync();

        if (store == null)
        {
            throw new Exception($"Store with ID {storeId} not found.");
        }

        return store;
    }

    public async Task<List<StoreProduct>> GetProductsByIdListAsync(List<StoreProductId> productIds)
    {
        var products = await _context
            .Stores.SelectMany(store => store.Products)
            .Where(product => productIds.Contains(product.Id))
            .ToListAsync();

        return products;
    }

    public async Task<StoreProduct> GetProductByExternalProductIdAsync(
        ExternalProductId externalProductId,
        ExternalVariantId externalVariantId,
        StoreId storeId
    )
    {
        var store = await _context
            .Stores.Include(store =>
                store.Products.Where(sp => sp.ExternalProductId == externalProductId && sp.ExternalVariantId == externalVariantId)
            )
            .FirstOrDefaultAsync(store => store.Id == storeId);

        var storeProduct = store?.Products.FirstOrDefault(sp =>
            sp.ExternalProductId == externalProductId && sp.ExternalVariantId == externalVariantId
        );

        return storeProduct;
    }

    public async Task<Store> GetByTrackingIdAsync(Guid trackingId)
    {
        return await _context.Stores.Where(store => store.TrackingId == trackingId).FirstOrDefaultAsync();
    }

    public async Task<Store> GetStoreByDomainNameAndAPIKeyAsync(string storeDomainName, string apiKey)
    {
        return await _context
            .Stores.Where(s => s.DomainName == storeDomainName && s.Registration.ApiKey == apiKey)
            .FirstOrDefaultAsync();
    }

    public async Task<Order> GetOrderByExternalOrderIdAsync(ExternalOrderId externalOrderId, StoreId storeId)
    {
        var order = await _context
            .Stores.SelectMany(store => store.Orders)
            .FirstOrDefaultAsync(o => o.ExternalOrderId == externalOrderId && o.StoreId == storeId);

        return order;
    }

    public async Task<Order> GetOrderByIdAsync(OrderId Id)
    {
        var storeWithOrders = await _context
            .Stores.Include(store => store.Orders.Where(order => order.Id == Id))
            .FirstOrDefaultAsync(s => s.Orders.Count > 0);

        return storeWithOrders.Orders.FirstOrDefault(o => o.Id == Id);
    }

    public async Task<List<Order>> GetOrdersByStoreIdAsync(StoreId storeId)
    {
        var orders = await _context
            .Stores.Where(s => s.Id == storeId)
            .SelectMany(s => s.Orders)
            .Include(o => o.OrderProducts)
            .ToListAsync();

        return orders;
    }

    public async Task<Dictionary<Guid, decimal>> GetFreeShippingThresholdMapping(List<StoreId> storeIds)
    {
        var stores = await _context
            .Stores.Include(store => store.ShippingOptions)
            .Where(store => storeIds.Contains(store.Id))
            .ToListAsync();

        var mapping = stores.ToDictionary(
            store => store.Id.Value,
            store => store.ShippingOptions.FirstOrDefault()?.FreeShippingThreshold?.Amount ?? 0m
        );

        return mapping;
    }

    public async Task<StoreProduct> GetStoreWithProduct(StoreId storeId, StoreProductId storeProductId)
    {
        var store = await _context
            .Stores.Include(s => s.Products.Where(p => p.Id == storeProductId))
            .Where(o => o.Id == storeId)
            .FirstOrDefaultAsync();

        return store.Products.FirstOrDefault();
    }

    public async Task<(int StoreCount, decimal LowestPrice)> GetStoreCountAndLowestPriceAsync(ProductCatalogId productCatalogId)
    {
        var storesWithProducts = await _context
            .Stores.Include(store => store.Products.Where(product => product.ProductCatalogId == productCatalogId))
            .Where(store => store.Products.Any(product => product.ProductCatalogId == productCatalogId))
            .ToListAsync();

        var lowestPrice = storesWithProducts.SelectMany(p => p.Products).Min(p => p.Price.Amount);

        return (storesWithProducts.Count(), lowestPrice);
    }

    public async Task<List<StoreId>> GetAllStoreIds()
    {
        return await _context.Stores.Where(s => s.IsActive).Select(p => p.Id).ToListAsync();
    }

    public async Task<Dictionary<StoreId, List<ProductData>>> GetStoreProductsWithLeastPrice(
        bool keepCurrentConditions,
        string minimumCondition,
        Dictionary<ProductVariantId, int> productVariantQuantities,
        Dictionary<ProductCatalogId, int> productQuantities
    )
    {
        var selectedProducts = new List<ProductData>();
        var remainingQuantities = new Dictionary<ProductCatalogId, int>(productQuantities);
        var productCatalogIds = productQuantities.Keys.ToList();

        var storeProductsQuery = _context
            .Stores.Where(store => store.IsOnboarded)
            .SelectMany(store => store.Products.Where(product => productCatalogIds.Contains(product.ProductCatalogId)))
            .AsQueryable();

        var allProducts = await storeProductsQuery.ToListAsync();
        var desiredConditions = minimumCondition.Split(',');

        if (keepCurrentConditions)
        {
            var catalogVariantQuantities = new Dictionary<ProductCatalogId, Dictionary<string, int>>();

            foreach (var (variantId, requiredQuantity) in productVariantQuantities)
            {
                var product = allProducts
                    .Where(p => p.ProductVariantId == variantId)
                    .Select(p => new { p.ProductCatalogId, VariantTypeKey = string.Join(",", p.VariantTypes) })
                    .FirstOrDefault();

                if (product == null)
                    continue;

                if (!catalogVariantQuantities.ContainsKey(product.ProductCatalogId))
                {
                    catalogVariantQuantities[product.ProductCatalogId] = new Dictionary<string, int>();
                }

                var variantDict = catalogVariantQuantities[product.ProductCatalogId];

                if (variantDict.ContainsKey(product.VariantTypeKey))
                {
                    variantDict[product.VariantTypeKey] += requiredQuantity;
                }
                else
                {
                    variantDict[product.VariantTypeKey] = requiredQuantity;
                }
            }

            var sortedProducts = allProducts.OrderBy(p => p.Price.Amount).ToList();

            foreach (var product in sortedProducts)
            {
                var variantTypeKey = string.Join(",", product.VariantTypes);

                if (catalogVariantQuantities.TryGetValue(product.ProductCatalogId, out var variantDict))
                {
                    if (variantDict.TryGetValue(variantTypeKey, out var requiredQuantity))
                    {
                        var quantityToTake = Math.Min(requiredQuantity, product.Quantity);

                        if (quantityToTake > 0)
                        {
                            selectedProducts.Add(
                                new ProductData(
                                    StoreId: new(product.StoreId.Value),
                                    Id: product.Id.Value,
                                    ProductCatalogId: product.ProductCatalogId.Value,
                                    Quantity: quantityToTake,
                                    ProductVariantId: product.ProductVariantId.Value,
                                    Price: Money.Of(product.Price.Amount, product.Price.Currency),
                                    Variants: product.VariantTypes
                                )
                            );

                            variantDict[variantTypeKey] -= quantityToTake;

                            if (variantDict[variantTypeKey] <= 0)
                            {
                                variantDict.Remove(variantTypeKey);
                            }

                            if (variantDict.Count == 0)
                            {
                                catalogVariantQuantities.Remove(product.ProductCatalogId);
                            }
                        }
                    }
                }
            }

            var productsByStore = selectedProducts
                .GroupBy(p => p.StoreId)
                .ToDictionary(g => g.Key, g => g.OrderBy(p => p.Price.Amount).ToList());

            var leastPriceProductsByStore = productsByStore
                .OrderBy(store => store.Value.FirstOrDefault()?.Price.Amount ?? decimal.MaxValue)
                .ToDictionary(store => store.Key, store => store.Value);

            return leastPriceProductsByStore;
        }

        foreach (var condition in desiredConditions)
        {
            var productsWithCondition = allProducts
                .Where(product =>
                    product.VariantTypes != null
                    && product.VariantTypes.TryGetValue("Condition", out var productCondition)
                    && productCondition == condition
                    && remainingQuantities.TryGetValue(product.ProductCatalogId, out var quantity)
                    && quantity > 0
                )
                .OrderBy(product => product.Price.Amount)
                .ToList();

            foreach (var product in productsWithCondition)
            {
                if (remainingQuantities[product.ProductCatalogId] > 0)
                {
                    var availableQuantity = remainingQuantities[product.ProductCatalogId];
                    var quantityToTake = Math.Min(availableQuantity, product.Quantity);

                    selectedProducts.Add(
                        new ProductData(
                            StoreId: new(product.StoreId.Value),
                            Id: product.Id.Value,
                            ProductCatalogId: product.ProductCatalogId.Value,
                            Quantity: quantityToTake,
                            ProductVariantId: product.ProductVariantId.Value,
                            Price: Money.Of(product.Price.Amount, product.Price.Currency),
                            Variants: product.VariantTypes
                        )
                    );

                    remainingQuantities[product.ProductCatalogId] -= quantityToTake;

                    if (!remainingQuantities.Values.Any(q => q > 0))
                    {
                        break;
                    }
                }
            }

            if (!remainingQuantities.Values.Any(quantity => quantity > 0))
            {
                break;
            }
        }

        var productsByStoreResult = selectedProducts
            .GroupBy(product => product.StoreId)
            .ToDictionary(group => group.Key, group => group.OrderBy(product => product.Price.Amount).ToList());

        var leastPriceProductsByStoreResult = productsByStoreResult
            .OrderBy(store => store.Value.FirstOrDefault()?.Price.Amount ?? decimal.MaxValue)
            .ToDictionary(store => store.Key, store => store.Value);

        return leastPriceProductsByStoreResult;
    }

    public async Task<Dictionary<StoreId, List<ProductData>>> GetStoreProductsWithMinimumPackages(
        bool keepCurrentConditions,
        string minimumCondition,
        Dictionary<ProductVariantId, int> productVariantQuantities,
        Dictionary<ProductCatalogId, int> productQuantities
    )
    {
        var productCatalogIds = productQuantities.Keys.ToList();
        var remainingQuantities = new Dictionary<ProductCatalogId, int>(productQuantities);
        var selectedProducts = new List<ProductData>();

        var desiredConditions = string.IsNullOrEmpty(minimumCondition) ? null : new HashSet<string>(minimumCondition.Split(','));

        var storeProductsQuery = _context
            .Stores.Where(store => store.IsOnboarded)
            .SelectMany(store => store.Products.Where(product => productCatalogIds.Contains(product.ProductCatalogId)))
            .AsQueryable();

        var storeProducts = await storeProductsQuery
            .GroupBy(product => product.StoreId)
            .ToDictionaryAsync(group => group.Key, group => group.ToList());

        foreach (var productCatalogId in productCatalogIds)
        {
            var requiredQuantity = remainingQuantities[productCatalogId];

            if (keepCurrentConditions)
            {
                var allProducts = storeProducts.SelectMany(store => store.Value).ToList();
                var catalogVariantQuantities = productVariantQuantities
                    .Select(vq => new
                    {
                        vq.Key,
                        Product = allProducts
                            .Where(p => p.ProductVariantId == vq.Key)
                            .Select(p => new { p.ProductCatalogId, VariantTypeKey = string.Join(",", p.VariantTypes) })
                            .FirstOrDefault(),
                        RequiredQuantity = vq.Value,
                    })
                    .Where(x => x.Product != null)
                    .GroupBy(x => x.Product.ProductCatalogId)
                    .ToDictionary(
                        g => g.Key,
                        g =>
                            g.GroupBy(x => x.Product.VariantTypeKey).ToDictionary(x => x.Key, x => x.Sum(v => v.RequiredQuantity))
                    );

                var sortedProducts = allProducts.OrderByDescending(p => p.Quantity).ToList();

                foreach (var product in sortedProducts)
                {
                    var variantTypeKey = string.Join(",", product.VariantTypes);

                    if (
                        catalogVariantQuantities.TryGetValue(product.ProductCatalogId, out var variantDict)
                        && variantDict.TryGetValue(variantTypeKey, out var requiredQuantityForVariant)
                    )
                    {
                        var quantityToTake = Math.Min(requiredQuantityForVariant, product.Quantity);

                        if (quantityToTake > 0)
                        {
                            selectedProducts.Add(
                                new ProductData(
                                    StoreId: new(product.StoreId.Value),
                                    Id: product.Id.Value,
                                    ProductCatalogId: product.ProductCatalogId.Value,
                                    Quantity: quantityToTake,
                                    ProductVariantId: product.ProductVariantId.Value,
                                    Price: Money.Of(product.Price.Amount, product.Price.Currency),
                                    Variants: product.VariantTypes
                                )
                            );

                            variantDict[variantTypeKey] -= quantityToTake;

                            if (variantDict[variantTypeKey] <= 0)
                            {
                                variantDict.Remove(variantTypeKey);
                            }

                            if (variantDict.Count == 0)
                            {
                                catalogVariantQuantities.Remove(product.ProductCatalogId);
                            }
                        }
                    }
                }

                var productsByStore = selectedProducts
                    .GroupBy(p => p.StoreId)
                    .ToDictionary(g => g.Key, g => g.OrderBy(p => p.Price.Amount).ToList());

                return productsByStore
                    .OrderBy(store => store.Value.FirstOrDefault()?.Price.Amount ?? decimal.MaxValue)
                    .ToDictionary(store => store.Key, store => store.Value);
            }

            desiredConditions = !string.IsNullOrEmpty(minimumCondition) ? new HashSet<string>(minimumCondition.Split(',')) : null;

            foreach (var condition in desiredConditions ?? Enumerable.Empty<string>())
            {
                var productsWithCondition = storeProducts
                    .SelectMany(storeProducts => storeProducts.Value)
                    .Where(p =>
                        p.ProductCatalogId == productCatalogId
                        && remainingQuantities[productCatalogId] > 0
                        && p.VariantTypes != null
                        && p.VariantTypes.TryGetValue("Condition", out var productCondition)
                        && productCondition == condition
                    )
                    .OrderBy(p => p.Price.Amount)
                    .ToList();

                foreach (var product in productsWithCondition)
                {
                    var availableQuantity = product.Quantity;
                    var quantityToTake = Math.Min(requiredQuantity, availableQuantity);

                    if (quantityToTake > 0)
                    {
                        selectedProducts.Add(
                            new ProductData(
                                StoreId: new(product.StoreId.Value),
                                Id: product.Id.Value,
                                ProductCatalogId: product.ProductCatalogId.Value,
                                Quantity: quantityToTake,
                                ProductVariantId: product.ProductVariantId.Value,
                                Price: Money.Of(product.Price.Amount, product.Price.Currency),
                                Variants: product.VariantTypes
                            )
                        );

                        remainingQuantities[productCatalogId] -= quantityToTake;
                        requiredQuantity -= quantityToTake;

                        if (requiredQuantity <= 0)
                        {
                            break;
                        }
                    }
                }

                if (requiredQuantity <= 0)
                {
                    break;
                }
            }

            if (requiredQuantity > 0)
            {
                var otherProducts = storeProducts
                    .SelectMany(storeProducts => storeProducts.Value)
                    .Where(p =>
                        p.ProductCatalogId == productCatalogId
                        && remainingQuantities[productCatalogId] > 0
                        && (
                            p.VariantTypes == null
                            || (
                                desiredConditions != null
                                && !desiredConditions.Contains(p.VariantTypes.GetValueOrDefault("Condition", ""))
                            )
                        )
                    )
                    .OrderBy(p => p.Price.Amount)
                    .ToList();

                foreach (var product in otherProducts)
                {
                    var availableQuantity = product.Quantity;
                    var quantityToTake = Math.Min(requiredQuantity, availableQuantity);

                    if (quantityToTake > 0)
                    {
                        selectedProducts.Add(
                            new ProductData(
                                StoreId: new(product.StoreId.Value),
                                Id: product.Id.Value,
                                ProductCatalogId: product.ProductCatalogId.Value,
                                Quantity: quantityToTake,
                                ProductVariantId: product.ProductVariantId.Value,
                                Price: Money.Of(product.Price.Amount, product.Price.Currency),
                                Variants: product.VariantTypes
                            )
                        );

                        remainingQuantities[productCatalogId] -= quantityToTake;
                        requiredQuantity -= quantityToTake;

                        if (requiredQuantity <= 0)
                        {
                            break;
                        }
                    }
                }
            }
        }

        var productsByStoreResult = selectedProducts
            .GroupBy(product => product.StoreId)
            .ToDictionary(group => group.Key, group => group.OrderBy(product => product.Price.Amount).ToList());

        var leastPriceProductsByStoreResult = productsByStoreResult
            .OrderBy(store => store.Value.FirstOrDefault()?.Price.Amount ?? decimal.MaxValue)
            .ToDictionary(store => store.Key, store => store.Value);

        return leastPriceProductsByStoreResult;
    }

    public async Task<Store> GetStoreShippingOptions(StoreId id)
    {
        return _context.Stores.Include(s => s.ShippingOptions).Where(s => s.Id == id).FirstOrDefault();
    }

    public async Task<Store> GetStoreShippingOptionsAsync(StoreId id)
    {
        return await _context.Stores.Include(s => s.ShippingOptions).Where(s => s.Id == id).FirstOrDefaultAsync();
    }
}
